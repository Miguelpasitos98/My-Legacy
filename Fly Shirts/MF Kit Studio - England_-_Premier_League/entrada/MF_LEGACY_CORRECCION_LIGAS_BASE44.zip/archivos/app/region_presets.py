"""Region filter for optional FotMob league scans. Catalog IDs are never guessed."""
from __future__ import annotations
import unicodedata

TARGET_REGIONS = ("Europa", "Sudamérica", "Norteamérica y Centroamérica", "Asia y Oceanía", "África y otras", "Internacionales")

def canon(x):
    return ''.join(c for c in unicodedata.normalize('NFKD', str(x or '').casefold()) if not unicodedata.combining(c)).strip()

EUROPE = {
 'england','spain','germany','italy','france','portugal','netherlands','belgium','turkey','scotland','austria','switzerland','greece','denmark','norway','sweden','poland','czech republic','czechia','croatia','serbia','ukraine','romania','russia','hungary','slovakia','slovenia','bulgaria','cyprus','ireland','northern ireland','wales','finland','iceland','israel','luxembourg','malta','albania','bosnia and herzegovina','montenegro','north macedonia','kosovo','georgia','armenia','azerbaijan','belarus','moldova','lithuania','latvia','estonia','faroe islands','gibraltar','kazakhstan'
}
SOUTH_AMERICA={'brazil','argentina','uruguay','colombia','chile','ecuador','paraguay','peru','venezuela','bolivia'}
NORTH_AMERICA={'united states','usa','canada','mexico','costa rica','honduras','guatemala','panama','el salvador','jamaica','nicaragua','haiti','dominican republic','trinidad and tobago','cuba'}
ASIA_OCEANIA={'saudi arabia','japan','south korea','korea republic','china','qatar','united arab emirates','uae','australia','new zealand','india','iran','iraq','uzbekistan','thailand','indonesia','malaysia','vietnam','bahrain','kuwait','oman','jordan','syria','lebanon','philippines','singapore','hong kong','taiwan','pakistan','bangladesh','nepal','myanmar','cambodia'}
CODES={'ENG':'Europa','ESP':'Europa','GER':'Europa','DEU':'Europa','ITA':'Europa','FRA':'Europa','POR':'Europa','NED':'Europa','BEL':'Europa','TUR':'Europa','SCO':'Europa','BRA':'Sudamérica','ARG':'Sudamérica','URU':'Sudamérica','COL':'Sudamérica','CHI':'Sudamérica','CHL':'Sudamérica','ECU':'Sudamérica','PAR':'Sudamérica','PER':'Sudamérica','VEN':'Sudamérica','BOL':'Sudamérica','USA':'Norteamérica y Centroamérica','CAN':'Norteamérica y Centroamérica','MEX':'Norteamérica y Centroamérica','JPN':'Asia y Oceanía','KOR':'Asia y Oceanía','AUS':'Asia y Oceanía','SAU':'Asia y Oceanía','CHN':'Asia y Oceanía'}
ALIASES={'turkiye':'turkey','bosnia-herzegovina':'bosnia and herzegovina','estados unidos':'united states','españa':'spain','alemania':'germany','brasil':'brazil','argentina':'argentina','francia':'france','inglaterra':'england','italia':'italy','mexico':'mexico','japon':'japan','corea del sur':'south korea'}

def region_for(league):
    name=canon(league.get('country'))
    name=ALIASES.get(name,name)
    if name in {'international','internacional','destacadas','popular','world','europe','south america','north america','asia','oceania'}:return 'Internacionales'
    if name in EUROPE:return 'Europa'
    if name in SOUTH_AMERICA:return 'Sudamérica'
    if name in NORTH_AMERICA:return 'Norteamérica y Centroamérica'
    if name in ASIA_OCEANIA:return 'Asia y Oceanía'
    # No ocultar ligas reales de FotMob por carecer de una región en el mapeo.
    # Los registros desconocidos permanecen visibles en «África y otras».
    return CODES.get(str(league.get('ccode') or '').upper(), 'África y otras')

def region_filter(leagues,regions=TARGET_REGIONS):
    selected=set(regions)
    return [x for x in leagues if region_for(x) in selected]
