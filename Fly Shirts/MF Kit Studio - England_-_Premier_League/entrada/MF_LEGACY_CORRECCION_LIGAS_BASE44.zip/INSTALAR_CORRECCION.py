# -*- coding: utf-8 -*-
"""Repara solo cuatro modulos de interfaz, haciendo copia de seguridad previa."""
from __future__ import annotations
import ast
from datetime import datetime
from pathlib import Path
import os
import shutil
import sys
import uuid

MODULES=("gui.py","player_window.py","league_gui.py","region_presets.py")

def run():
    if sys.version_info < (3,10):
        raise RuntimeError("Es necesario Python 3.10 o superior.")
    folder=Path(__file__).resolve().parent
    project=next((p for p in (folder,folder.parent) if (p/'INICIAR.pyw').is_file() and (p/'app').is_dir()),None)
    if project is None:
        raise RuntimeError("No se encuentra INICIAR.pyw. Copia todo el contenido de este parche en la carpeta original MF_Legacy_Studio_Unificado, junto a INICIAR.pyw, y ejecuta de nuevo INSTALAR_CORRECCION.bat.")
    replacements=[]
    for name in MODULES:
        source=folder/'archivos'/'app'/name
        target=project/'app'/name
        if not source.is_file() or not target.is_file():
            raise RuntimeError("Falta un archivo del parche o del programa: "+name)
        content=source.read_text(encoding='utf-8')
        ast.parse(content,filename=str(source))
        replacements.append((source,target,name))
    backup=project/'EXPORTACIONES'/('RESPALDO_UI_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    (backup/'app').mkdir(parents=True,exist_ok=False)
    # Respaldar la version instalada antes de escribir un solo archivo.
    for source,target,name in replacements:
        shutil.copy2(target,backup/'app'/name)
    changed=[]
    try:
        for source,target,name in replacements:
            tmp=target.with_name(target.name+'.mfpatch_'+uuid.uuid4().hex+'.tmp')
            try:
                shutil.copy2(source,tmp)
                os.replace(tmp,target)
            finally:
                if tmp.exists():tmp.unlink()
            changed.append((target,name))
    except Exception:
        for target,name in reversed(changed):
            shutil.copy2(backup/'app'/name,target)
        raise
    (backup/'LEEME_RESTAURACION.txt').write_text(
        'Para restaurar la version anterior, cierra MF Legacy y copia los cuatro archivos de esta carpeta app sobre los mismos cuatro archivos de la carpeta app del programa.\n',
        encoding='utf-8')
    print('CORRECCION INSTALADA. Reinicia MF Legacy Studio.\n')
    print('Programa: '+str(project))
    print('Copia de seguridad: '+str(backup))
    print('Archivos actualizados: '+', '.join(MODULES))
    print('No se han modificado los archivos de datos, perfiles, cachés ni exportaciones.')

if __name__=='__main__':
    try:run()
    except Exception as exc:
        print('ERROR: '+str(exc),file=sys.stderr)
        sys.exit(1)
