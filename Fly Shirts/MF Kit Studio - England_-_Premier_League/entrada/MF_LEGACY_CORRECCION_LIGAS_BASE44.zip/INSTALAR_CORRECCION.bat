@echo off
setlocal
cd /d "%~dp0"
echo.
echo MF LEGACY - CORRECCION DE LIGAS Y EXPORTACION BASE44
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 "%~dp0INSTALAR_CORRECCION.py"
  goto result
)
where python >nul 2>nul
if %errorlevel%==0 (
  python "%~dp0INSTALAR_CORRECCION.py"
  goto result
)
echo ERROR: Python no encontrado.
pause
exit /b 1
:result
if errorlevel 1 (
  echo.
  echo No se ha aplicado el parche. Revisa el error de arriba.
  pause
  exit /b 1
)
echo.
echo Listo. Abre MF Legacy Studio de nuevo.
pause
exit /b 0
