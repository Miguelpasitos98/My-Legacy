@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ========================================================
echo   MF LEGACY - REPARACION UNDERSTAT + EXPORTACIONES
 echo ========================================================
 echo.
where py >nul 2>nul
if not errorlevel 1 (
  py -3 INSTALAR_REPARACION.py
) else (
  python INSTALAR_REPARACION.py
)
if errorlevel 1 (
  echo.
  echo LA ACTUALIZACION NO SE HA INSTALADO. REVISA EL ERROR.
) else (
  echo.
  echo Listo. Cierra y vuelve a abrir MF Legacy Studio.
)
echo.
pause
