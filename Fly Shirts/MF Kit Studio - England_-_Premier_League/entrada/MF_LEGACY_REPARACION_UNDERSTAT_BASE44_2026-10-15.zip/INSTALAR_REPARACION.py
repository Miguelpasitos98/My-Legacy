"""MF LEGACY Studio: repair Understat team mapping and export by player name.

Modifies ONLY app/understat_bridge.py, app/base44_export.py and app/player_window.py.
Creates a restorable backup before writing; does not modify caches, stats or exports.
"""
from pathlib import Path
from datetime import datetime
import os, shutil, sys
from INSTALAR_EXPORTACION_PLAYERS import patch_exporter,patch_player_window

DEFAULT = Path(r'E:\Football Manager\MF_Legacy_Studio_Unificado')
LABEL = '# MF_LEGACY_UNDERSTAT_TEAM_FIX_V2'


def patch_understat(source: str) -> str:
    if LABEL in source:
        return source
    anchor = " 'borussiadortmund':'borussiadortmund',"
    if source.count(anchor)!=1:
        raise RuntimeError('Versión no reconocida de understat_bridge.py: no se cambió ningún archivo')
    aliases=""" 'borussiadortmund':'borussiadortmund',
 # Understat uses Tottenham; FotMob frequently uses Tottenham Hotspur.
 'tottenham':'tottenham','tottenhamhotspur':'tottenham','tottenhamhotspurfc':'tottenham',"""
    result=source.replace(anchor,aliases,1)
    needle = "def cache_file(root,pid,season,league,team):"
    if result.count(needle)!=1:
        raise RuntimeError('Estructura inesperada de understat_bridge.py: falta cache_file')
    extra='''# MF_LEGACY_UNDERSTAT_TEAM_FIX_V2
# Diagnose rejected records without guessing player identity or club assignment.
def explain_no_match(rows,player,team):
    exact=[r for r in rows if norm(r.get('player_name'))==norm(player)]
    if not exact:
        return 'El nombre exacto del jugador no figura en la respuesta de Understat'
    matching=[r for r in exact if same_team(r.get('team_title'),team)]
    if not matching:
        clubs=sorted({str(r.get('team_title') or '?') for r in exact})
        return 'Club no coincidente: FotMob '+str(team)+' / Understat '+', '.join(clubs[:4])
    if len(matching)>1:
        return 'Understat devuelve varias filas del mismo jugador y club: revisión necesaria'
    return 'Faltan minutos/xG válidos en Understat: no se inventan estadísticas'

'''
    result=result.replace(needle,extra+needle,1)
    old="report['pending'].append({'season':season,'competition':comp,'reason':'Jugador/equipo no coinciden de manera única'})"
    if result.count(old)!=1:
        raise RuntimeError('No se puede localizar el diagnóstico anterior de Understat')
    result=result.replace(old,"report['pending'].append({'season':season,'competition':comp,'reason':explain_no_match(rows,player_name,team)})",1)
    return result


def install(path=DEFAULT):
    path=Path(path).expanduser().resolve()
    if not (path/'INICIAR.pyw').is_file():
        raise RuntimeError('Carpeta no reconocida, comprueba la ruta: '+str(path))
    patches={
        'app/understat_bridge.py':patch_understat,
        'app/base44_export.py':patch_exporter,
        'app/player_window.py':patch_player_window,
    }
    originals={}
    changes={}
    for name,func in patches.items():
        file=path/name
        if not file.is_file():raise RuntimeError('Falta archivo: '+str(file))
        original=file.read_text(encoding='utf-8')
        edited=func(original)
        compile(edited,name,'exec')
        originals[name]=original
        if edited != original:changes[name]=edited
    if not changes:
        print('Ya está actualizado. No se han cambiado archivos.')
        return None
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=path/'RESPALDOS'/('REPARACION_KANE_UNDERSTAT_'+stamp)
    backup.mkdir(parents=True,exist_ok=False)
    for name in changes:
        file=backup/name
        file.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path/name,file)
    updated=[]
    try:
        for name,code in changes.items():
            target=path/name
            tmp=target.with_name(target.name+'.reparacion_tmp')
            tmp.write_text(code,encoding='utf-8')
            os.replace(tmp,target)
            updated.append(name)
    except Exception:
        for name in updated:shutil.copy2(backup/name,path/name)
        raise
    restore=backup/'RESTAURAR.py'
    restore.write_text('''from pathlib import Path
import shutil
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
for name in ["app/understat_bridge.py","app/base44_export.py","app/player_window.py"]:
    saved=HERE/name
    if saved.is_file():shutil.copy2(saved,ROOT/name)
print("Restauración aplicada. Reinicia MF Legacy Studio.")
input("Pulsa Enter para salir…")
''',encoding='utf-8')
    print('ACTUALIZACIÓN CORRECTA')
    print('Código modificado:',', '.join(changes))
    print('Copia de seguridad:', backup)
    print('Destino de exportación:',path/'EXPORTACIONES'/'Players')
    print('No se alteraron estadísticas, fuentes, cachés ni archivos exportados.')
    return backup

if __name__=='__main__':
    try:install(sys.argv[1] if len(sys.argv)>1 else DEFAULT)
    except Exception as e:
        print('ERROR: '+str(e));sys.exit(1)
