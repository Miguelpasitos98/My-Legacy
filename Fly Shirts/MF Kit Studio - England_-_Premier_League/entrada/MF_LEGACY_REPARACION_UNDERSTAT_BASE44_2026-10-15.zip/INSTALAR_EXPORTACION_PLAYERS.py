"""MF Legacy Studio: named player JSON exports under EXPORTACIONES/Players.

Only changes app/base44_export.py and app/player_window.py. Fully reversible.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
import os
import shutil
import sys

TARGET_DEFAULT = r'E:\Football Manager\MF_Legacy_Studio_Unificado'
MARK = '# MF_LEGACY_PLAYERS_EXPORT_V1'
HERE = Path(__file__).resolve().parent


def patch_exporter(original: str) -> str:
    if MARK in original:
        return original
    anchor = 'def export_player_batch(root,player_id,player_rows,folder):'
    if original.count(anchor) != 1:
        raise RuntimeError('base44_export.py: versión no reconocida; no se aplicó ningún cambio')
    head = original[:original.index(anchor)]
    tail = original[original.index(anchor):]
    # Exactly the final function in supported Studio versions.
    if not tail.startswith(anchor) or 'def ' in tail[len(anchor):]:
        raise RuntimeError('base44_export.py: estructura inesperada; no se aplicó ningún cambio')
    return head + r'''# MF_LEGACY_PLAYERS_EXPORT_V1
# Filename respects Unicode accents but strips characters illegal in Windows.
import re as _re_players


def _player_filename(name, player_id):
    value = str(name or '').strip()
    # Windows reserved symbols and control characters, including path separators.
    value = _re_players.sub(r'[<>:"/\\|?*\x00-\x1f]', ' ', value)
    value = ' '.join(value.split()).rstrip(' .')[:100].rstrip(' .')
    if not value or value.upper().split('.')[0] in {
        'CON', 'PRN', 'AUX', 'NUL', *('COM'+str(i) for i in range(1,10)),
        *('LPT'+str(i) for i in range(1,10))
    }:
        value = f'Jugador {player_id}'
    return value + '.json'


def _player_id_in_export(path):
    try:
        doc = json.loads(path.read_text(encoding='utf-8-sig'))
        pid = (doc.get('summary') or {}).get('fotmob_id')
        return str(pid or '')
    except (OSError, ValueError, TypeError, AttributeError):
        return ''


def export_player_batch(root, player_id, player_rows=None, folder=None, player_name=None):
    """Export one Base44-compatible JSON under EXPORTACIONES/Players.

    Re-exporting the same FotMob player refreshes the file atomically.
    A homonym with a different FotMob ID gets a suffix only when necessary.
    The optional folder exists for tests/legacy clients; GUI omits it.
    """
    pid = str(player_id).strip()
    out = create_player_batch(root, pid, player_rows)
    destination = Path(folder) if folder is not None else Path(root)/'EXPORTACIONES'/'Players'
    destination.mkdir(parents=True, exist_ok=True)
    # The GUI always passes the visible verified player name.
    if not player_name:
        for row in (player_rows or []):
            if str(row.get('fotmob_player_id') or '') == pid and row.get('player_name'):
                player_name = row['player_name']
                break
    if not player_name:
        for row in out.get('records', []):
            detail = row.get('data') or {}
            player_name = (detail.get('identity') or {}).get('name') or detail.get('player_name_at_snapshot')
            if player_name:
                break
    path = destination / _player_filename(player_name, pid)
    if path.exists() and _player_id_in_export(path) != pid:
        # Preserve other players' files, even if names match (or file is unknown).
        stem = path.stem
        path = destination / f'{stem} ({pid}).json'
        if path.exists() and _player_id_in_export(path) != pid:
            raise ValueError('Ya existe un archivo con el mismo nombre perteneciente a otro jugador: '+str(path))
    tmp = path.with_suffix(path.suffix+'.tmp')
    try:
        with tmp.open('w', encoding='utf-8') as fh:
            json.dump(out, fh, ensure_ascii=False, indent=2, allow_nan=False)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()
    return {'path':path,'summary':out['summary']}
'''


def patch_player_window(original: str) -> str:
    if MARK in original:
        return original
    start = '    def export_for_base44(self):'
    end = '    def export_stats(self):'
    if original.count(start) != 1 or original.count(end) != 1:
        raise RuntimeError('player_window.py: versión no reconocida; no se aplicó ningún cambio')
    begin = original.index(start)
    finish = original.index(end,begin)
    replacement = '''    def export_for_base44(self):
        """Export automatically to EXPORTACIONES/Players/Player Name.json."""
        # MF_LEGACY_PLAYERS_EXPORT_V1
        if self._busy:
            messagebox.showinfo('Exportación ocupada', 'Espera a que termine el proceso actual.', parent=self)
            return
        try:
            from .base44_export import export_player_batch
            result = export_player_batch(
                ROOT, self.pid, self.records,
                player_name=self.selected.get('player_name') or None,
            )
        except Exception as exc:
            messagebox.showerror('No se pudo exportar para Base44', str(exc), parent=self)
            return
        info = result['summary']
        advanced = info.get('advanced_metrics') or {}
        messagebox.showinfo('Jugador exportado para Base44',
            'Archivo: '+str(result['path'])+'\\n\\n'
            'Historiales con equipo identificado: '+str(info['fotmob_exportable'])+'\\n'
            'Pendientes de revisión: '+str(info['fotmob_pending_review'])+'\\n'
            'xG Chain: '+str(advanced.get('xg_chain', 0))+' competiciones\\n'
            'xG Buildup: '+str(advanced.get('xg_buildup', 0))+' competiciones\\n'
            'Duelos terrestres: '+str(advanced.get('ground_duels', 0))+' competiciones\\n\\n'
            'Puedes importar este JSON en Base44. Si el jugador ya existe, '
            'se añadirán únicamente las métricas nuevas compatibles; los conflictos quedan pendientes.',
            parent=self)

'''
    return original[:begin] + replacement + original[finish:]


def run(target: str | Path):
    target = Path(target).expanduser().resolve()
    if not (target/'INICIAR.pyw').is_file():
        raise RuntimeError('No se reconoce una instalación de MF Legacy Studio: '+str(target))
    changes = {
        'app/base44_export.py':patch_exporter,
        'app/player_window.py':patch_player_window,
    }
    new = {}
    for name, function in changes.items():
        path = target/name
        if not path.is_file():
            raise RuntimeError('Falta el archivo necesario: '+str(path))
        src = path.read_text(encoding='utf-8')
        new[name] = function(src)
        compile(new[name],name,'exec')
    changed = {k:v for k,v in new.items() if v != (target/k).read_text(encoding='utf-8')}
    if not changed:
        print('ACTUALIZACION YA INSTALADA: no hace falta cambiar nada.')
        return None
    backup = target/'RESPALDOS'/('PLAYERS_EXPORT_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    backup.mkdir(parents=True,exist_ok=False)
    written = []
    try:
        for name in changed:
            old = target/name
            dst = backup/name
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(old,dst)
        for name,data in changed.items():
            path=target/name
            tmp=path.with_name(path.name+'.players_patch.tmp')
            tmp.write_text(data,encoding='utf-8')
            os.replace(tmp,path)
            written.append(name)
    except Exception:
        for name in written:
            shutil.copy2(backup/name,target/name)
        raise
    (backup/'RESTAURAR.py').write_text('''from pathlib import Path
import shutil
here=Path(__file__).resolve().parent
root=here.parent.parent
for name in ('app/base44_export.py','app/player_window.py'):
    saved=here/name
    if saved.is_file():
        shutil.copy2(saved,root/name)
        print('Restaurado:',name)
''',encoding='utf-8')
    print('ACTUALIZACION COMPLETADA')
    print('Salida: ', target/'EXPORTACIONES'/'Players')
    print('Respaldo: ', backup)
    print('Sin modificar cachés, fuentes, estadísticas ni otros datos.')
    return backup

if __name__=='__main__':
    try:
        run(sys.argv[1] if len(sys.argv)>1 else TARGET_DEFAULT)
    except Exception as error:
        print('ACTUALIZACION CANCELADA:',error)
        raise SystemExit(1)
