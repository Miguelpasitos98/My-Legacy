@echo off
setlocal
cd /d "%~dp0"
where pyw >nul 2>nul
if %errorlevel%==0 (
  start "" pyw "%~dp0INICIAR.pyw"
  exit /b 0
)
where pythonw >nul 2>nul
if %errorlevel%==0 (
  start "" pythonw "%~dp0INICIAR.pyw"
  exit /b 0
)
where py >nul 2>nul
if %errorlevel%==0 (
  py "%~dp0INICIAR.pyw"
  if errorlevel 1 pause
  exit /b %errorlevel%
)
where python >nul 2>nul
if %errorlevel%==0 (
  python "%~dp0INICIAR.pyw"
  if errorlevel 1 pause
  exit /b %errorlevel%
)
echo.
echo NO SE HA ENCONTRADO PYTHON EN WINDOWS.
echo Instala Python 3.10 o posterior con Tkinter desde python.org.
echo Activa la opcion Add Python to PATH o utiliza el lanzador de Python.
echo.
pause
exit /b 1
