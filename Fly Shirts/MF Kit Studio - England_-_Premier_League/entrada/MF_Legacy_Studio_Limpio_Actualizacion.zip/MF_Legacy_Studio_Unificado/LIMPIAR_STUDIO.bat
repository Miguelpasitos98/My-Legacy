@echo off
setlocal
cd /d "%~dp0"
title MF LEGACY - Limpiar Studio

echo.
echo  MF LEGACY - LIMPIEZA SEGURA
echo  ----------------------------
echo  Se conservaran TODOS los datos, cachés, snapshots CraftedFC,
echo  exportaciones, configuraciones y respaldos anteriores.
echo.
if not exist "app\gui.py" (
 echo ERROR: Falta app\gui.py. Extrae primero todo el ZIP.
 pause
 exit /b 1
)
if not exist "datos\fotmob_bigfive_cache.json" (
 echo AVISO: No esta la cache FotMob en esta carpeta.
 echo Esta actualizacion se debe extraer SOBRE la instalacion actual,
 echo no dentro de una carpeta nueva vacia.
 pause
 exit /b 2
)
for %%F in (
 "ABRIR_EN_WINDOWS.bat"
 "ACTUALIZAR_HISTORIALES.bat"
 "ACTUALIZAR_MF_LEGACY.bat"
 "ACTUALIZAR_MF_LEGACY.py"
 "ACTUALIZAR_STUDIO.bat"
 "AMPLIAR_LIGAS.pyw"
 "aplicar.py"
 "CLI.py"
 "VERIFICAR_UNIFICADO.py"
 "GUIA_BASE44_ESTADISTICAS.txt"
 "GUIA_INSTALACION_Y_USO.txt"
 "GUIA_PRIMERO.txt"
 "LEEME_ACTUALIZACION.txt"
 "LEEME_ACTUALIZACION_LIGAS.txt"
 "LEEME_CORRECCION_EXPORTACION.txt"
 "LEEME_INSTALACION.txt"
 "LEEME_PASO_A_PASO.txt"
 "PROMPT_BASE44_ESTADISTICAS_V2.txt"
 "MANIFIESTO_VERSIONES.json"
 "ESTUDIO_DE_DATOS.md"
) do if exist "%%~F" del /q "%%~F" >nul 2>nul
if exist "app\studio_compat.py" del /q "app\studio_compat.py" >nul 2>nul
for %%D in (
 "actualizacion"
 "EJEMPLOS_FICTICIOS"
 "referencia_8_scripts"
) do if exist "%%~D\" rmdir /s /q "%%~D" >nul 2>nul
for /d %%D in ("app\__pycache__" "tests\__pycache__") do if exist "%%~D\" rmdir /s /q "%%~D" >nul 2>nul
if exist "tests\" rmdir /s /q "tests" >nul 2>nul
echo.
echo  LISTO. Se han quitado antiguos lanzadores, demos, pruebas,
echo  scripts de referencia y documentacion duplicada.
echo.
echo  Se conservan: datos, FUENTES, EXPORTACIONES, RESPALDOS.
echo  Inicia con ABRIR_STUDIO_UNIFICADO.bat
pause
