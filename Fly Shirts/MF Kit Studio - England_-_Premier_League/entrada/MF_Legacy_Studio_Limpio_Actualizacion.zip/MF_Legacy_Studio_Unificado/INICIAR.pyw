"""Lanzador estable de MF LEGACY · FotMob Stats Studio.

Si falla el inicio, conserva el error para que no desaparezca en Windows.
"""
from pathlib import Path
import traceback

try:
    from app.gui import main
    main()
except Exception:
    error = traceback.format_exc()
    try:
        path = Path(__file__).resolve().parent / "EXPORTACIONES" / "ERROR_INICIO.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(error, encoding="utf-8")
        location = str(path)
    except OSError:
        location = "No se ha podido escribir el registro de errores."
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("MF LEGACY · Error de inicio", "No se ha podido abrir FotMob Stats Studio.\n\n" + error[-1200:] + "\n\nRegistro: " + location, parent=root)
        root.destroy()
    except Exception:
        print(error)
    raise
