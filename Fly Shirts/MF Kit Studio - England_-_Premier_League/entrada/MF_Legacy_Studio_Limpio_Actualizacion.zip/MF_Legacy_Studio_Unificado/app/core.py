"""Motor de consulta y exportación de archivos históricos locales de FotMob.

No realiza conexiones de red ni intenta acceder a interfaces privadas.
Separa fuentes, identifica temporadas y evita inventar estadísticas ausentes.
"""
from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import re
import unicodedata
from typing import Any, Iterable
from .team_matches import for_basic_record

SCHEMA = "mf_legacy_player_season_stats_v1"
SOURCE = "FotMob (cache local proporcionada por el usuario)"
CSV_COLS = (
    "external_record_id", "base44_player_id", "fm26_uid", "fotmob_player_id",
    "player_name", "fotmob_team_id", "team_name", "league", "season",
    "appearances", "minutes", "team_matches", "rating", "market_value", "market_date",
    "source", "verification_status",
)


def _slug(value: Any) -> str:
    raw = unicodedata.normalize("NFKD", str(value or ""))
    raw = "".join(c for c in raw if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", "-", raw.casefold()).strip("-")


def _number(value: Any, *, integer: bool = False) -> int | float | None:
    if value is None or value == "" or isinstance(value, bool):
        return None
    try:
        n = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    if n != n or abs(n) == float("inf"):
        return None
    if integer:
        return int(n) if n >= 0 and n.is_integer() else None
    return n


def _identity(value: Any) -> str:
    return str(value).strip() if value is not None else ""


def load_cache(path: str | Path) -> dict:
    path = Path(path)
    with path.open(encoding="utf-8-sig") as handle:
        cache = json.load(handle)
    if not isinstance(cache, dict) or not cache:
        raise ValueError("La caché debe ser un objeto JSON no vacío con claves Liga|Temporada.")
    for key, block in cache.items():
        if not isinstance(block, dict) or not isinstance(block.get("players"), list):
            raise ValueError(f"Formato incorrecto en {key!r}: falta la lista players.")
        if not (block.get("league") and block.get("season")):
            raise ValueError(f"Formato incorrecto en {key!r}: faltan league/season.")
    return cache


def _read_csv_table(path: str | Path) -> tuple[set[str], list[dict[str, str]]]:
    """CSV de Excel (UTF-8 BOM, ; , o tabulador, encabezados normalizados).

    Nunca interpreta valores estadísticos como equivalencias de jugadores.
    """
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(8192)
        handle.seek(0)
        first = sample.splitlines()[0].strip() if sample.splitlines() else ""
        declared_separator = first[4:5] if first.casefold().startswith("sep=") else None
        if declared_separator in (";", ",", "\t"):
            next(handle, None)
            sep = declared_separator
        else:
            header = first
            sep = max((";", ",", "\t"), key=lambda c: header.count(c))
        reader = csv.DictReader(handle, delimiter=sep)
        fieldnames = {str(n or "").strip().casefold() for n in (reader.fieldnames or []) if n}
        rows = [{str(k or "").strip().casefold():
                 (v.strip() if isinstance(v, str) else "")
                 for k, v in row.items() if k} for row in reader]
    return fieldnames, rows


def classify_csv(path: str | Path) -> dict:
    """Identifica un CSV estadístico frente a uno de equivalencias, sin cambios.

    Devuelve IDs de jugadores únicamente como información para ayudar al usuario
    a abrir su ficha: *no* los vincula a FM26/Base44 automáticamente.
    """
    fields, rows = _read_csv_table(path)
    has_ids = ("fotmob_player_id" in fields and
               bool({"fm26_uid", "base44_player_id"} & fields))
    has_stats = (bool({"statistic", "statistic_id", "per90", "percentile"} & fields) or
                 ("season" in fields and bool({"competition", "league"} & fields)))
    kind = "statistics" if has_stats else "mapping" if has_ids else "unknown"
    ids = sorted({r.get("fotmob_player_id", "") for r in rows if r.get("fotmob_player_id", "")})
    return {"kind": kind, "player_ids": ids, "row_count": len(rows), "fields": fields}


def load_mapping(path: str | Path | None) -> dict[str, dict[str, str]]:
    """Vínculos explícitos y comprobados. No interpreta CSV de estadísticas."""
    if not path:
        return {}
    info = classify_csv(path)
    if info["kind"] == "statistics":
        raise ValueError(
            "Has seleccionado un CSV de estadísticas FotMob, no de equivalencias.\n"
            "No se ha perdido ningún dato ni se ha cambiado ningún vínculo.\n"
            "Abre la ficha del jugador y pulsa «EXPORTAR JUGADOR PARA BASE44»."
        )
    if info["kind"] != "mapping":
        raise ValueError(
            "Este CSV no es una plantilla de equivalencias. Se necesitan las "
            "columnas «fotmob_player_id» y «fm26_uid» o «base44_player_id».\n"
            "Para estadísticas utiliza «EXPORTAR JUGADOR PARA BASE44»; no este botón."
        )
    _, rows = _read_csv_table(path)
    out = {}
    for idx, row in enumerate(rows, 2):
        k = _identity(row.get("fotmob_player_id"))
        if not k:
            continue
        record = {
            "fm26_uid": _identity(row.get("fm26_uid")),
            "base44_player_id": _identity(row.get("base44_player_id")),
        }
        if not record["fm26_uid"] and not record["base44_player_id"]:
            continue  # Plantilla sin rellenar, nunca crea falsos vínculos.
        if k in out and out[k] != record:
            raise ValueError(f"ID FotMob duplicado con dos equivalencias distintas en fila {idx}: {k}")
        out[k] = record
    if not out:
        raise ValueError("No hay equivalencias verificadas. Las filas sin FM26 UID ni Base44 ID se omiten.")
    return out


def to_records(cache: dict, mapping: dict | None = None, team_match_cache: dict | None = None) -> list[dict]:
    mapping = mapping or {}
    records = []
    seen = {}
    for key, block in sorted(cache.items(), key=lambda item: (item[1]["season"], item[1]["league"])):
        season, league = str(block["season"]), str(block["league"])
        for idx, player in enumerate(block["players"], 1):
            if not isinstance(player, dict):
                raise ValueError(f"Jugador no válido en {key}, posición {idx}.")
            pid = _identity(player.get("player_id"))
            tid = _identity(player.get("team_id"))
            if not pid or not tid:
                raise ValueError(f"Jugador sin ID de FotMob o equipo en {key}, posición {idx}.")
            external_id = f"fotmob:{pid}:{tid}:{_slug(season)}:{_slug(league)}"
            if external_id in seen:
                if seen[external_id] != player:
                    raise ValueError(
                        f"Dos registros diferentes comparten la misma clave de temporada: {external_id}"
                    )
                continue
            seen[external_id] = player
            link = mapping.get(pid) or {}
            rec = {
                "external_record_id": external_id,
                "base44_player_id": link.get("base44_player_id", ""),
                "fm26_uid": link.get("fm26_uid", ""),
                "fotmob_player_id": pid,
                "player_name": str(player.get("name") or ""),
                "fotmob_team_id": tid,
                "fotmob_tournament_id": str(block.get("league_id") or ""),
                "team_name": str(player.get("team") or ""),
                "league": league,
                "season": season,
                "appearances": _number(player.get("matches"), integer=True),
                "minutes": _number(player.get("minutes")),
                "team_matches": _number(player.get("team_matches"), integer=True),
                "rating": _number(player.get("rating")),
                "market_value": _number(player.get("market_value")),
                "market_date": player.get("market_date") or None,
                "source": SOURCE,
                "verification_status": "cache_historica_no_verificada",
            }
            if rec.get("team_matches") is None and team_match_cache is not None:
                rec["team_matches"] = for_basic_record(rec, cache, team_match_cache)
            # Este material NO contiene goles, asistencias, titularidades, etc.
            # El esquema jamás añade esas métricas con valores inventados.
            records.append(rec)
    return records


def filter_records(records: Iterable[dict], *, league="", season="", team="", player="") -> list[dict]:
    lt, st, tt, pt = (_slug(x) for x in (league, season, team, player))
    out = []
    for r in records:
        if lt and lt != _slug(r["league"]):
            continue
        if st and st != _slug(r["season"]):
            continue
        if tt and tt not in _slug(r["team_name"]) and str(team) != r["fotmob_team_id"]:
            continue
        if pt and pt not in _slug(r["player_name"]) and str(player) != r["fotmob_player_id"] and str(player) != r["fm26_uid"]:
            continue
        out.append(r)
    return out


def summarize(records: list[dict]) -> dict:
    return {
        "records": len(records),
        "players": len({r["fotmob_player_id"] for r in records}),
        "teams": len({r["fotmob_team_id"] for r in records if r.get("fotmob_team_id")}),
        "leagues": sorted({r["league"] for r in records}),
        "seasons": sorted({r["season"] for r in records}),
        "with_base44_mapping": sum(bool(r["base44_player_id"]) for r in records),
        "with_fm26_mapping": sum(bool(r["fm26_uid"]) for r in records),
        "with_appearances": sum(r["appearances"] is not None for r in records),
        "with_minutes": sum(r["minutes"] is not None for r in records),
        "with_rating": sum(r["rating"] is not None for r in records),
        "with_team_matches": sum(r.get("team_matches") is not None for r in records),
        "with_market_value": sum(r["market_value"] is not None for r in records),
        "duplicate_external_ids": len(records) - len({r["external_record_id"] for r in records}),
    }


def _safe_csv_cell(value):
    # Evita interpretaciones de fórmulas al abrir CSV con Excel.
    if isinstance(value, str) and value.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + value
    return "" if value is None else value


def export_csv(records: list[dict], outpath: str | Path) -> Path:
    outpath = Path(outpath)
    outpath.parent.mkdir(parents=True, exist_ok=True)
    with outpath.open("w", newline="", encoding="utf-8-sig") as handle:
        w = csv.DictWriter(handle, fieldnames=CSV_COLS, delimiter=";", extrasaction="ignore")
        w.writeheader()
        for r in records:
            w.writerow({k: _safe_csv_cell(r.get(k)) for k in CSV_COLS})
    return outpath


def export_json(records: list[dict], outpath: str | Path) -> Path:
    outpath = Path(outpath)
    outpath.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema": SCHEMA,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "validated_for_direct_import": False,
        "license_note": "Verificar licencia y permiso de reutilización de los datos antes de publicarlos.",
        "description": "Vista de estadísticas disponible en la caché local; sin enriquecimiento inventado.",
        "summary": summarize(records),
        "records": records,
    }
    with outpath.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
    return outpath


def export_report(records: list[dict], outpath: str | Path) -> Path:
    outpath = Path(outpath)
    outpath.parent.mkdir(parents=True, exist_ok=True)
    with outpath.open("w", encoding="utf-8") as handle:
        json.dump(summarize(records), handle, indent=2, ensure_ascii=False)
    return outpath
