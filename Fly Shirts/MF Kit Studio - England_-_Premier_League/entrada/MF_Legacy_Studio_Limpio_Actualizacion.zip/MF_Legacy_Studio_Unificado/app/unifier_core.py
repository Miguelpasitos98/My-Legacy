#!/usr/bin/env python3
"""Unificador de snapshots locales FotMob Legacy Studio V2 + CraftedFC.
No hace peticiones web, no ejecuta código de los archivos fuente y nunca publica datos.
Uso: python unificar_fotmob_craftedfc.py --fotmob CARPETA_STUDIO --crafted CARPETA_EXPORTACION --output ARCHIVO.json
"""
from __future__ import annotations
import argparse
import hashlib
import json
from collections import defaultdict, Counter
from .history_sync import read_overlay, normalized_season
from datetime import datetime, timezone
from pathlib import Path

SCHEMA = "mf_legacy_unified_fotmob_craftedfc_v1"

def read_json(path):
    with Path(path).open(encoding='utf-8-sig') as f:
        return json.load(f)

def find_dataset(base, folder, prefix):
    """Admite conteos cambiantes: jugadores_14996.json, jugadores_16200.json, etc."""
    matches = sorted((Path(base) / folder).glob(prefix + "_*.json"))
    if len(matches) != 1:
        raise ValueError(f"Esperado un archivo {prefix}_*.json en {folder}; encontrados: {len(matches)}")
    return matches[0]

def sid(value):
    if value is None or value == '':
        return None
    s = str(value)
    if s.endswith('.0') and s[:-2].isdigit():
        s = s[:-2]
    return s

def canonical_payload(row):
    return {k:v for k,v in row.items() if k not in {'source','local_source_file'}}

def build(fotmob, crafted, progress_callback=None):
    """Construye datos unificados sin modificar las entradas."""
    def progress(pct, msg):
        if progress_callback is not None:
            progress_callback(pct, msg)

    fotmob, crafted=Path(fotmob),Path(crafted)
    progress(4, "Leyendo caché histórica de FotMob...")
    cache=read_json(fotmob/'datos/fotmob_bigfive_cache.json')
    cplayers=read_json(find_dataset(crafted,'datos_completos','jugadores'))
    cclubs=read_json(find_dataset(crafted,'datos_completos','clubes'))
    cleagues=read_json(find_dataset(crafted,'datos_completos','competiciones_clubes'))
    now=datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    progress(13, "Vinculando historiales por identificadores FotMob...")

    # Raw historical FotMob data is keyed by exact, stable FotMob player IDs, never names.
    historical=defaultdict(list)
    seen_history=set()
    team_inventory=defaultdict(lambda: {'names':set(),'seasons':set(),'leagues':set(),'player_season_records':0})
    periods=[]
    for key, block in sorted(cache.items()):
        periods.append({k:v for k,v in block.items() if k != 'players'} | {'player_records':len(block['players'])})
        for row in block['players']:
            pid=sid(row.get('player_id'))
            tid=sid(row.get('team_id'))
            if not pid or not tid: raise ValueError('Missing FotMob historical player/team id')
            pk=(pid, tid, str(block['season']),str(block['league']))
            if pk in seen_history:
                raise ValueError('Duplicate historical key: '+str(pk))
            seen_history.add(pk)
            historical[pid].append({
                'external_record_id': ':'.join(('fotmob',pid,tid,str(block['season']),str(block['league']))),
                'season':block['season'], 'competition':block['league'],
                'team_id':tid, 'team_name':row.get('team'),
                'fotmob_tournament_id':str(block.get('league_id') or ''),
                'player_name_at_snapshot':row.get('name'),
                'matches':row.get('matches'), 'minutes':row.get('minutes'),
                'fotmob_match_rating':row.get('rating'),
                'market_value_eur':row.get('market_value'),
                'market_value_as_of':row.get('market_date'),
                'source':'fotmob_historical_cache',
                'verification_status':'historical_cache_not_independently_verified',
            })
            t=team_inventory[tid]
            if row.get('team'):t['names'].add(row['team'])
            t['seasons'].add(block['season'])
            t['leagues'].add(block['league'])
            t['player_season_records']+=1
    # Individual profiles and cached per-competition statistics are additional
    # evidence. They are **not** rating.json rankings, and must not be promoted
    # to complete season totals or arbitrarily linked to a team.
    extras=read_overlay(fotmob)
    basic_keys=defaultdict(set)
    for pid,group in historical.items():
        for r in group:
            basic_keys[(pid,normalized_season(r['season']),str(r['competition']).casefold())].add(
                str(r.get('fotmob_tournament_id') or ''))
    extra_count=0
    ranking_metric_updates=0
    for item in extras:
        pid=sid(item.get('fotmob_player_id'))
        if not pid or not item.get('external_record_id'):continue
        comp=str(item.get('league') or '')
        season=normalized_season(item.get('season'))
        if not season or not comp:continue
        key=(pid,season,comp.casefold())
        # A ranking enriched from playerStats is still ONE historical row.
        # Only add its metrics to a verified matching ranking, never a second
        # season nor a replacement match total/rating.
        if item.get('verification_status')=='perfil_enriquecimiento_ranking':
            tid=str(item.get('fotmob_tournament_id') or '')
            team=sid(item.get('fotmob_team_id'))
            matches=[h for h in historical.get(pid,[]) if
                normalized_season(h.get('season'))==season and
                str(h.get('competition') or '').casefold()==comp.casefold() and
                (not tid or not h.get('fotmob_tournament_id') or str(h.get('fotmob_tournament_id'))==tid) and
                (not team or sid(h.get('team_id'))==team)]
            if len(matches)==1:
                matches[0]['metrics']=item.get('metrics') or []
                matches[0]['stats_detail_status']=item.get('detail_status')
                matches[0]['coverage_conflicts']=item.get('coverage_conflicts') or {}
                ranking_metric_updates+=1
            continue
        # Existing broad rankings always take precedence over a partial row.
        seen_tournaments=basic_keys.get(key,set())
        incoming_tournament=str(item.get('fotmob_tournament_id') or '')
        if seen_tournaments and (not incoming_tournament or '' in seen_tournaments or
                                 incoming_tournament in seen_tournaments):
            continue
        tid=sid(item.get('fotmob_team_id'))
        record={
            'external_record_id':item['external_record_id'],
            'season':season, 'competition':comp,
            'team_id':tid or None, 'team_name':item.get('team_name') or None,
            'player_name_at_snapshot':item.get('player_name') or None,
            'matches':item.get('appearances'), 'minutes':item.get('minutes'),
            'fotmob_match_rating':item.get('rating'),
            'market_value_eur':item.get('market_value'),
            'market_value_as_of':item.get('market_date'),
            'fotmob_tournament_id':item.get('fotmob_tournament_id') or None,
            'metrics':item.get('metrics') or [],
            'source':'fotmob_individual_profile_cache',
            'verification_status':'individual_profile_partial',
        }
        historical[pid].append(record)
        extra_count+=1
        if tid:
            t=team_inventory[tid]
            if item.get('team_name'):t['names'].add(item['team_name'])
            t['seasons'].add(season);t['leagues'].add(comp)
            t['player_season_records']+=1
    for v in historical.values():
        v.sort(key=lambda x:(str(x['season']),str(x['competition']),str(x.get('team_id') or '')))


    progress(28, "Resolviendo estadísticas detalladas y posibles conflictos...")
    # Statistical detail extracts (some overlapping review files). Deduplicate on key,
    # compare substantive fields, retain all source filenames, report non-identical conflicts.
    detailed={}; details_sources=defaultdict(set); detail_conflicts=[]
    detail_files=sorted((fotmob/'EXPORTACIONES').glob('ESTADISTICAS_FOTMOB_*REVISION.json'))
    for f in detail_files:
        source=read_json(f)
        for row in source.get('records',[]):
            key=row['external_record_id']
            details_sources[key].add(f.name)
            if key not in detailed:
                detailed[key]=dict(row)
                continue
            saved=detailed[key]
            for field, value in row.items():
                if field=='source':
                    continue  # The original extract filenames are preserved separately.
                if saved.get(field) is None and value is not None:
                    saved[field]=value  # complementary field, not a conflict
                elif value is None:
                    continue
                elif field not in saved:
                    saved[field]=value
                elif field=='local_source_file':
                    continue  # machine-dependent path, not statistical data
                elif saved[field]!=value:
                    detail_conflicts.append({
                        'external_record_id':key, 'source_file':f.name,
                        'field':field,'retained_value':saved[field],
                        'alternate_value':value,
                    })
    detail_by_player=defaultdict(list)
    for key,row in detailed.items():
        pid=sid(row.get('fotmob_player_id'))
        if not pid:continue
        normalized={k:v for k,v in row.items() if k not in {'local_source_file'}}
        normalized['extract_sources']=sorted(details_sources[key])
        normalized['source_stat_cache_filename']=Path(row['local_source_file']).name if row.get('local_source_file') else None
        detail_by_player[pid].append(normalized)
    for v in detail_by_player.values(): v.sort(key=lambda r:(str(r['season']),str(r['competition']),r['external_record_id']))

    progress(40, "Incorporando los perfiles y respuestas originales de FotMob...")
    # The full raw FotMob detailed responses and player profiles are retained separately
    # from the reviewed/normalized per-competition exports to avoid conflating them.
    raw_stat_by_player=defaultdict(list)
    for f in sorted((fotmob/'datos/estadisticas_fotmob').glob('*.json')):
        row=read_json(f)
        pid=sid(row.get('_mf_legacy_meta',{}).get('player_id')) or f.stem.split('_')[0]
        raw_stat_by_player[pid].append({'file':f.name,'data':row})
    profile_by_player={}
    for f in sorted((fotmob/'datos/perfiles_fotmob').glob('*.json')):
        row=read_json(f)
        pid=sid(row.get('id')) or f.stem
        profile_by_player[pid]={'source_file':f.name, 'data':row}

    # Review-only Base44 rows are retained but not imported or treated as validated.
    # La exportación histórica básica es opcional: el Studio no depende de
    # archivos de salida antiguos para volver a generar el JSON unificado.
    review_path=fotmob/'EXPORTACIONES/LOTE_ESTADISTICAS_BASE44_REVISION.json'
    review=read_json(review_path) if review_path.is_file() else {'records': []}
    review_by_player=defaultdict(list)
    for row in review.get('records',[]):
        pid=sid(row.get('fotmob_player_id'))
        if pid:review_by_player[pid].append(row)

    progress(49, "Cruzando jugadores de FotMob con CraftedFC...")
    crafted_by_player={sid(r['player_id']):r for r in cplayers}
    if len(crafted_by_player)!=len(cplayers): raise ValueError('Duplicated CraftedFC player ids')
    all_ids=sorted(set(crafted_by_player)|set(historical)|set(detail_by_player)|set(raw_stat_by_player)|set(profile_by_player)|set(review_by_player),key=lambda x:int(x) if x.isdecimal() else x)
    players=[]
    matched=0; unmatched_fotmob=0; unmatched_crafted=0
    for pid in all_ids:
        c=crafted_by_player.get(pid)
        hist=historical.get(pid,[])
        profile=profile_by_player.get(pid)
        reviewed=detail_by_player.get(pid,[])
        raw_stat=raw_stat_by_player.get(pid,[])
        extra=review_by_player.get(pid,[])
        has_f=bool(hist or profile or reviewed or raw_stat or extra)
        if c and has_f: matched+=1
        elif has_f:unmatched_fotmob+=1
        else:unmatched_crafted+=1
        name=(c or {}).get('player_name') or (hist[-1].get('player_name_at_snapshot') if hist else None) or (profile or {}).get('data',{}).get('name')
        players.append({
            'id':'fotmob-player:'+pid,
            'ids':{'fotmob_player_id':pid,'craftedfc_player_id':pid if c else None,'base44_player_id':None,'fm26_uid':None},
            'identity':{
                'name':name,
                'position':(c or {}).get('primary_position'),
                'archetype':(c or {}).get('primary_archetype'),
                'country_code':(c or {}).get('player_country'),
                'latest_club_in_craftedfc':(c or {}).get('display_team'),
            },
            'craftedfc_snapshot':c,
            'fotmob':{
                'season_competition_records':hist,
                'reviewed_detailed_stats':reviewed,
                'raw_detailed_cache_responses':raw_stat,
                'raw_player_profile':profile,
                'base44_review_only_rows':extra,
            },
            'data_quality':{
                'match_method':'exact_fotmob_player_id' if (c and has_f) else 'not_matched',
                'in_fotmob_historical_cache':bool(hist),
                'in_craftedfc_snapshot':c is not None,
                'historical_records':len(hist),
                'reviewed_stat_competitions':len(reviewed),
                'raw_stat_responses':len(raw_stat),
                'has_player_profile':bool(profile),
            }
        })

    progress(68, "Uniendo clubes por identificador exacto...")
    # Keep one row per team id. No guessing about historical club identity via name.
    cteams={sid(r['team_id']):r for r in cclubs}
    team_ids=sorted(set(cteams)|set(team_inventory),key=lambda x:int(x) if x.isdecimal() else x)
    teams=[]
    for tid in team_ids:
        inv=team_inventory.get(tid)
        c=cteams.get(tid)
        names=sorted(inv['names']) if inv else []
        teams.append({
            'id':'fotmob-team:'+tid,'fotmob_team_id':tid,
            'name':(c or {}).get('team_name') or (names[0] if names else None),
            'craftedfc_snapshot':c,
            'fotmob_history':{
                'observed_names':names,
                'seasons':sorted(inv['seasons']) if inv else [],
                'competitions':sorted(inv['leagues']) if inv else [],
                'player_season_records':inv['player_season_records'] if inv else 0,
            },
            'data_quality':{'match_method':'exact_fotmob_team_id' if c and inv else 'not_matched'}
        })

    progress(74, "Preparando ligas, metodologías y evidencias originales...")
    # Keep two competition catalogs distinct; name similarity alone is insufficient,
    # e.g. Serie A Brazil versus Serie A Italy or cup vs league.
    out={
        'schema':SCHEMA,
        'generated_utc':now,
        'validated_for_direct_base44_import':False,
        'important_notes':[
            'FotMob historical rows are historical cached league/season records; not an exhaustive or freshly verified player career.',
            'CraftedFC data are current consolidated snapshots and must not be assigned retrospectively to historic seasons.',
            'Do not sum percentiles, rates, ratings or market values across competitions.',
            'Missing values are null or absent, never fabricated zeros.',
            'The same numeric player_id and team_id represent shared FotMob identifiers; never merge by name.',
            'craftedfc_original_public_json preserves original public payloads as evidence, including some duplicates of normalized datasets; never treat those copies as new observations.',
            'Historical cache may omit goals, xG and other stats; use detailed caches only where provided.',
            'Inspect and comply with sources terms and reuse permissions before publishing or synchronizing to Base44.',
            'Existing Base44/FM26 identifiers are not assigned, and custom fields are not touched.',
        ],
        'sources':{
            'fotmob':{'source':'FotMob Legacy Studio Consolidado V2 local cache','input_format':'extracted archive folder', 'original_readme':'GUIA_PRIMERO.txt'},
            'craftedfc':{'source':'CraftedFC JSON export snapshot','snapshot_date':(read_json(crafted/'MANIFIESTO.json').get('snapshot') if (crafted/'MANIFIESTO.json').is_file() else None), 'input_format':'extracted export directory'}
        },
        'summary':{
            'players_total':len(players),
            'fotmob_historical_unique_players':len(historical),
            'craftedfc_players':len(cplayers),
            'players_exact_id_match':matched,
            'players_only_fotmob_sources':unmatched_fotmob,
            'players_only_craftedfc':unmatched_crafted,
            'fotmob_historical_records':sum(len(x) for x in historical.values()),
            'fotmob_ranking_records':len(seen_history),
            'fotmob_ranking_rows_enriched_with_metrics':ranking_metric_updates,
            'fotmob_profile_complete_rows_included':sum(1 for x in extras if x.get('verification_status')=='perfil_individual_verificado'),
            'fotmob_profile_partial_rows_included':sum(1 for x in extras if x.get('verification_status')=='perfil_individual_parcial'),
            'fotmob_historical_league_season_blocks':len(cache),
            'fotmob_profile_rows_included':extra_count,
            'fotmob_reviewed_detail_records':len(detailed),
            'fotmob_raw_stat_responses':sum(map(len,raw_stat_by_player.values())),
            'fotmob_full_player_profiles':len(profile_by_player),
            'review_only_base44_rows':len(review['records']),
            'review_detail_substantive_conflicts':len(detail_conflicts),
            'craftedfc_raw_public_json_responses':len(list((crafted/'json_originales_web').glob('*.json'))),
            'teams_total':len(teams),
            'craftedfc_teams':len(cclubs),
            'team_exact_id_match':len(set(cteams)&set(team_inventory)),
            'craftedfc_competitions':len(cleagues),
            'fotmob_historical_distinct_competition_names':len({b['league'] for b in cache.values()})
        },
        'players':players,
        'teams':teams,
        'competitions':{
            'craftedfc_ranked':cleagues,
            'craftedfc_league_indices':read_json(find_dataset(crafted,'datos_completos','indices_ligas')),
            'craftedfc_international_tournaments':read_json(find_dataset(crafted,'datos_completos','torneos_internacionales')),
            'fotmob_historical_competition_seasons':periods,
            'fotmob_league_directory_snapshot':read_json(fotmob/'datos/fotmob_league_directory.json'),
        },
        'fotmob_team_matches_cache':read_json(fotmob/'datos/team_matches_cache.json'),
        'craftedfc_methodology':{
            'archetype_weights':read_json(crafted/'metodologia/pesos_arquetipos.json'),
            'rating_pipeline':read_json(crafted/'metodologia/pipeline.json'),
        },
        'craftedfc_player_season_examples':read_json(crafted/'muestras/filas_temporada_de_perfiles.json'),
        'craftedfc_profiles_source_manifest':read_json(crafted/'FUENTES_PERFILES.json'),
        'craftedfc_original_public_json':{f.name:read_json(f) for f in sorted((crafted/'json_originales_web').glob('*.json'))},
        'data_quality':{'review_detail_conflicts':detail_conflicts, 'match_strategy':'exact_id_only'}
    }
    progress(85, "Comprobando integridad y relaciones entre fuentes...")
    assert out['summary']['players_total'] == out['summary']['players_exact_id_match']+out['summary']['players_only_fotmob_sources']+out['summary']['players_only_craftedfc']
    assert out['summary']['fotmob_historical_records']==sum(len(x['fotmob']['season_competition_records']) for x in players)
    assert out['summary']['craftedfc_players']==sum(x['craftedfc_snapshot'] is not None for x in players)
    progress(90, "Objeto unificado listo para escribir en disco.")
    return out

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--fotmob',type=Path,required=True,help='Extracted FotMob_Legacy_Studio_Consolidado_V2 folder')
    ap.add_argument('--crafted',type=Path,required=True,help='Extracted CraftedFC JSON export directory')
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    obj=build(args.fotmob,args.crafted)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('w',encoding='utf-8') as f:
        json.dump(obj,f,ensure_ascii=False,separators=(',',':'),allow_nan=False)
    print(json.dumps(obj['summary'],ensure_ascii=False,indent=2))
    print('Output:',args.output,'bytes',args.output.stat().st_size)
if __name__=='__main__':main()
