"""Auditable team-match counts per competition and season.

Safest source: the final 'played' column of one full league table.
Cup/group tables and partial fixtures are NOT treated as verified team totals.
"""
from __future__ import annotations

import json
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

FIVE_IDS = {"Premier League": 47, "LaLiga": 87, "Serie A": 55,
            "Bundesliga": 54, "Ligue 1": 53}
CUP_WORDS = ("cup", "copa", "coppa", "pokal", "trophy", "supercopa", "super cup",
             "champions", "europa", "conference", "world", "qualif", "playoff", "friendly")


def is_cup(name):
    normalized = re.sub(r"[^a-z]+", " ", str(name or "").casefold())
    return any(x in normalized for x in CUP_WORDS)


def completed_season(season, at=None):
    # Europe-style Jul-Jun season only. A calendar-year league is ambiguous.
    match = re.fullmatch(r"(\d{4})/(\d{4})", str(season or ""))
    if not match or int(match.group(2)) != int(match.group(1)) + 1:
        return False
    at = at or datetime.now(timezone.utc)
    return at.year > int(match.group(2)) or at.year == int(match.group(2)) and at.month >= 7


def _positive_int(value, *, limit=200):
    if isinstance(value, bool): return None
    try:
        num = float(value)
        if num.is_integer() and 0 < num <= limit: return int(num)
    except (TypeError, ValueError, OverflowError): pass
    return None


def _league_standings(payload):
    tables = payload.get("table") if isinstance(payload, dict) else None
    if isinstance(tables, dict): tables = [tables]
    if not isinstance(tables, list) or len(tables) != 1:
        return []
    container = tables[0]
    data = container.get("data", container) if isinstance(container, dict) else {}
    block = data.get("table") if isinstance(data, dict) else None
    full = block.get("all") if isinstance(block, dict) else None
    if not isinstance(full, list) or not full: return []
    return full


def _fixture_matches(payload):
    matches = payload.get("matches") if isinstance(payload, dict) else None
    if isinstance(matches, list): return matches
    if isinstance(matches, dict):
        for key in ("allMatches", "matches", "fixtures"):
            result = matches.get(key)
            if isinstance(result, list): return result
    for key in ("fixtures", "allMatches"):
        val = payload.get(key) if isinstance(payload, dict) else None
        if isinstance(val, list): return val
        if isinstance(val, dict) and isinstance(val.get("matches"), list): return val["matches"]
    return []


def extract_team_matches(payload, *, league_id, season, competition):
    """Return counts with explicit quality flags, never fake unknown values.

    For historical league table use single 'table.all' only. For cups, count
    distinct finished fixtures as candidates for review (not auto-exported).
    """
    if not isinstance(payload, dict): return []
    now = datetime.now(timezone.utc).isoformat()
    output = []
    if not is_cup(competition):
        standings = _league_standings(payload)
        if standings:
            for row in standings:
                if not isinstance(row, dict): continue
                team_id = _positive_int(row.get("id", row.get("teamId")), limit=1000000000)
                played = _positive_int(row.get("played", row.get("matchesPlayed")))
                if team_id is None or played is None: continue
                output.append({"league_id": int(league_id), "season": season, "competition": competition,
                               "team_id": team_id, "team_name": row.get("name", ""),
                               "team_matches": played,
                               "status": "verified_final_table" if completed_season(season) else "current_table_snapshot",
                               "source": "FotMob leagues.table.all.played", "fetched_utc": now})
            if output: return output

    # Finished fixture list may be partial, especially for cup elimination rounds.
    # Keep a review candidate, do NOT auto-attach the number to player stats.
    counts = {}
    seen = set()
    for match in _fixture_matches(payload):
        if not isinstance(match, dict): continue
        match_id = match.get("id", match.get("matchId"))
        status = match.get("status") or {}
        if not isinstance(status, dict) or status.get("finished") is not True or status.get("cancelled") is True or status.get("awarded") is True:
            continue
        if match_id in seen or match_id is None: continue
        seen.add(match_id)
        for side in ("home", "away"):
            team = match.get(side)
            if not isinstance(team, dict): continue
            tid = _positive_int(team.get("id", team.get("teamId")), limit=1000000000)
            if tid is not None:
                bucket = counts.setdefault(tid, {"team_id": tid, "team_name": str(team.get("name") or ""), "team_matches": 0})
                bucket["team_matches"] += 1
    for v in counts.values():
        output.append({"league_id": int(league_id), "season": season, "competition": competition,
                       **v, "status": "fixture_count_needs_review", "source": "FotMob completed matches visible (may be partial)",
                       "fetched_utc": now})
    return output


def lookup_team_matches(cached, league_id, season, team_id):
    if league_id in (None, "") or team_id in (None, ""): return None
    records = cached.get("entries", {}) if isinstance(cached, dict) else {}
    r = records.get(f"{league_id}|{season}|{team_id}")
    if not isinstance(r, dict) or r.get("status") not in {"verified_final_table", "confirmed_by_user"}: return None
    return _positive_int(r.get("team_matches"))


def read_team_matches(root):
    path = Path(root) / "datos" / "team_matches_cache.json"
    if not path.exists(): return {"schema": "mf_legacy_team_matches_v1", "entries": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        if isinstance(data, dict) and isinstance(data.get("entries"), dict): return data
    except (OSError, ValueError): pass
    return {"schema": "mf_legacy_team_matches_v1", "entries": {}}


def _normal_label(value):
    plain=unicodedata.normalize("NFKD",str(value or "")).casefold()
    return re.sub(r"[^a-z0-9]", "", "".join(ch for ch in plain if not unicodedata.combining(ch)))


def for_basic_record(row, blocks, cache):
    league = row.get("league") or row.get("competition")
    season = row.get("season")
    ident = FIVE_IDS.get(league)
    block = blocks.get(f"{league}|{season}", {}) if isinstance(blocks, dict) else {}
    if isinstance(block, dict): ident = block.get("league_id") or ident
    tid=row.get("fotmob_team_id")
    direct=lookup_team_matches(cache, ident, season, tid)
    if direct is not None:return direct
    # Historical cups may have no rating.json/cache block. Match only an
    # unambiguous FotMob team ID + normalized competition + season.
    if ident is not None or tid in (None, "") or not isinstance(cache,dict):return None
    candidates=[x for x in cache.get("entries",{}).values() if isinstance(x,dict)
                and str(x.get("team_id"))==str(tid) and x.get("season")==season
                and _normal_label(x.get("competition"))==_normal_label(league)
                and x.get("status") in {"verified_final_table","confirmed_by_user"}]
    if len(candidates)!=1:return None
    return _positive_int(candidates[0].get("team_matches"))


def export_team_match_audit(root, destination):
    """Export every discovered team-season-competition, including review flags."""
    import csv
    destination=Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    snapshot=read_team_matches(root)
    rows=sorted((r for r in snapshot.get('entries',{}).values() if isinstance(r,dict)),
                key=lambda r:(r.get('season',''),r.get('competition',''),r.get('team_name','')))
    json_path=destination/'PJ_EQUIPOS_POR_COMPETICION_REVISION.json'
    json_path.write_text(json.dumps({'schema':'mf_legacy_team_matches_audit_v1',
                                     'note':'Datos de clasificación final o conteos provisionales; revisar la columna status.',
                                     'records':rows},ensure_ascii=False,indent=2),encoding='utf-8')
    fields=('league_id','season','competition','team_id','team_name','team_matches','status','source','fetched_utc','verified_utc')
    csv_path=destination/'PJ_EQUIPOS_POR_COMPETICION_REVISION.csv'
    with csv_path.open('w',encoding='utf-8-sig',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields,delimiter=';',extrasaction='ignore')
        writer.writeheader()
        writer.writerows([{k: '' if row.get(k) is None else row.get(k,'') for k in fields} for row in rows])
    return json_path,csv_path,len(rows)
