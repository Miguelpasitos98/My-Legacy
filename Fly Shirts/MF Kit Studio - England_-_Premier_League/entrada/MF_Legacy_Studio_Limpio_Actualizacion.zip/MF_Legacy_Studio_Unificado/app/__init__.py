"""FotMob Legacy Studio: consulta offline y exportación."""
