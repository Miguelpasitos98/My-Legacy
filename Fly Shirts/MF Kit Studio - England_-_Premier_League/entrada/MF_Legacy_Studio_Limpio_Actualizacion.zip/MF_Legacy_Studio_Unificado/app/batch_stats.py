"""Planificación local de una exportación detallada de un único jugador.

Nunca consulta listas de jugadores ni otros perfiles; los IDs de competiciones
proceden únicamente del perfil confirmado de ese jugador.
"""
from __future__ import annotations
from collections import defaultdict
from .profile import aggregate_stats_seasons


def options_for_export(options):
    out=[]
    seen=set()
    for option in sorted(options,key=lambda o:(str(o.get('season','')),str(o.get('competition','')))):
        season_id=str(option.get('season_id') or '')
        if not season_id:
            continue
        key=(str(option.get('season','')),str(option.get('competition','')),season_id)
        if key in seen:continue
        seen.add(key)
        out.append(option)
    return out


def coverage_report(options,records,failures=None):
    failures=failures or []
    by_season=defaultdict(list)
    for option in options:by_season[option['season']].append(option)
    records_by_season=defaultdict(list)
    for rec in records:records_by_season[rec['season']].append(rec)
    report=[]
    for season,items in sorted(by_season.items(),reverse=True):
        expected={o['competition'] for o in items}
        received={r['competition'] for r in records_by_season.get(season,[])}
        missing=sorted(expected-received)
        report.append({'season':season,'competitions_available':sorted(expected),
                       'competitions_loaded':sorted(received),
                       'competitions_missing':missing,'complete':not missing,
                       'status':'Cobertura según perfil FotMob (no garantiza todas las competiciones disputadas)'})
    return {'seasons':report,'failures':failures,'subtotals':aggregate_stats_seasons(records)}
