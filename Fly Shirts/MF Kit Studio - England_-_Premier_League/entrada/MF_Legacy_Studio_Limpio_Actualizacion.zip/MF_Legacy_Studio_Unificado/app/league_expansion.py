"""Opt-in historical FotMob league discovery and local-cache enrichment.

No background requests occur during normal app startup. Network access is made
only after the user explicitly starts an update in the GUI/CLI. FotMob routes
are unofficial and can change; failures are reported, never silently replaced.
"""
from __future__ import annotations

import json
import gzip
import zlib
import os
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode, urljoin, urlparse
from urllib.request import Request, urlopen
from typing import Callable

from .team_matches import FIVE_IDS, extract_team_matches, lookup_team_matches

BASE = "https://www.fotmob.com/api/data/"
ALLOWED_HOSTS = {"www.fotmob.com", "fotmob.com", "data.fotmob.com", "pub.fotmob.com"}
SEASONS = tuple(f"{y}/{y+1}" for y in range(2016, 2026))
CALENDAR_SEASONS = tuple(str(y) for y in range(2016, 2027))
FALLBACK = [
    {"id": 47, "name": "Premier League", "country": "England", "ccode": "ENG"},
    {"id": 87, "name": "LaLiga", "country": "Spain", "ccode": "ESP"},
    {"id": 55, "name": "Serie A", "country": "Italy", "ccode": "ITA"},
    {"id": 54, "name": "Bundesliga", "country": "Germany", "ccode": "GER"},
    {"id": 53, "name": "Ligue 1", "country": "France", "ccode": "FRA"},
    {"id": 130, "name": "MLS", "country": "United States", "ccode": "USA"},
]


def season_slug(value):
    value = str(value or "").strip()
    match = re.search(r"(?<!\d)(\d{4})\s*[/\-]\s*(\d{2}|\d{4})(?!\d)", value)
    if not match:
        return value if re.fullmatch(r"(?:19|20)\d{2}", value) else ""
    y = int(match.group(1)); end = int(match.group(2))
    if end < 100:
        end = (y // 100) * 100 + end
        if end < y: end += 100
    return f"{y}/{end}"


def _clean_url(value):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("FotMob no devolvió una dirección de datos utilizable.")
    url = urljoin(BASE, value.strip())
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_HOSTS:
        raise ValueError("Dirección externa no permitida: la fuente debe ser FotMob.")
    return url


class FotMobHttp:
    def __init__(self, delay=1.1):
        self.delay = max(0.7, float(delay))
        self._last = 0.0
        self._lock = threading.Lock()

    @staticmethod
    def decode_json(raw, content_encoding=""):
        """Decode FotMob JSON with compressed responses, including gzip returned
        without a Content-Encoding header. Never interpret compressed bytes as UTF-8.
        """
        encoding = str(content_encoding or "").strip().lower()
        if encoding in {"gzip", "x-gzip"} or raw.startswith(b"\x1f\x8b"):
            raw = gzip.decompress(raw)
        elif encoding == "deflate":
            try:
                raw = zlib.decompress(raw)
            except zlib.error:
                raw = zlib.decompress(raw, -zlib.MAX_WBITS)
        if len(raw) > 18 * 1024 * 1024:
            raise ValueError("Respuesta descomprimida demasiado grande: no se procesó.")
        try:
            return json.loads(raw.decode("utf-8-sig"))
        except UnicodeDecodeError as exc:
            raise ValueError("FotMob devolvió datos no legibles como JSON UTF-8.") from exc

    def json(self, address):
        url = _clean_url(address)
        with self._lock:
            remaining = self.delay - (time.monotonic() - self._last)
            if remaining > 0: time.sleep(remaining)
            self._last = time.monotonic()
        request = Request(url, headers={
            "User-Agent": "MF-Legacy-Studio/1.0 (personal research; respectful requests)",
            "Accept": "application/json",
            "Accept-Encoding": "gzip, deflate, identity",
        })
        with urlopen(request, timeout=24) as response:
            if response.status != 200:
                raise ValueError(f"FotMob respondió {response.status}")
            raw = response.read(18 * 1024 * 1024 + 1)
            encoding = response.headers.get("Content-Encoding", "")
            if len(raw) > 18 * 1024 * 1024:
                raise ValueError("Respuesta demasiado grande: no se procesó.")
        return self.decode_json(raw, encoding)


def parse_directory(data):
    if not isinstance(data, dict):
        raise ValueError("El directorio de ligas no es un objeto JSON.")
    entries = []
    def add(item, country, ccode=""):
        if not isinstance(item, dict): return
        try: ident = int(item.get("id"))
        except (TypeError, ValueError): return
        name = str(item.get("name") or "").strip()
        if ident <= 0 or not name: return
        entries.append({"id": ident, "name": name, "country": country, "ccode": ccode})

    for group in data.get("countries") or []:
        if not isinstance(group, dict): continue
        country = str(group.get("name") or "País no identificado")
        code = str(group.get("ccode") or "")
        for league in group.get("leagues") or []:
            add(league, country, code)
    for bucket in ("international", "popular"):
        for item in data.get(bucket) or []:
            if not isinstance(item, dict): continue
            if isinstance(item.get("leagues"), list):
                for league in item["leagues"]: add(league, "Internacional", "INT")
            else: add(item, "Internacional" if bucket == "international" else "Destacadas", str(item.get("ccode") or ""))

    # Prefer named country over duplicate 'popular' listing; preserve all IDs.
    dedup = {}
    for entry in entries:
        old = dedup.get(entry["id"])
        if old is None or old["country"] in {"Destacadas", "Internacional"} and entry["country"] not in {"Destacadas", "Internacional"}:
            dedup[entry["id"]] = entry
    return sorted(dedup.values(), key=lambda d: (d["country"].casefold(), d["name"].casefold(), d["id"]))


def load_directory(root, *, online=False, http=None):
    root = Path(root)
    path = root / "datos" / "fotmob_league_directory.json"
    if online:
        payload = (http or FotMobHttp()).json(BASE + "allLeagues")
        leagues = parse_directory(payload)
        if not leagues: raise ValueError("El directorio de FotMob llegó vacío o cambió de formato.")
        path.parent.mkdir(parents=True, exist_ok=True)
        atomic_json(path, payload)
        return leagues
    if path.exists():
        try:
            leagues = parse_directory(json.loads(path.read_text(encoding="utf-8-sig")))
            if leagues: return leagues
        except (ValueError, OSError, json.JSONDecodeError): pass
    return list(FALLBACK)


def iter_dicts(obj):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values(): yield from iter_dicts(value)
    elif isinstance(obj, list):
        for value in obj: yield from iter_dicts(value)


def rating_url(payload):
    for node in iter_dicts(payload):
        value = node.get("fetchAllUrl")
        if isinstance(value, str) and re.search(r"rating\.json(?:[?#].*)?$", value):
            return _clean_url(value)
    return None


def parse_rating(payload):
    """Read FotMob rating.json using documented historical key variants.

    Do not fabricate unavailable rating, minutes, club or appearances.
    """
    found = {}
    for node in iter_dicts(payload):
        pid = node.get("ParticiantId", node.get("ParticipantId", node.get("PlayerId", node.get("playerId"))))
        name = node.get("ParticipantName", node.get("PlayerName", node.get("playerName")))
        tid = node.get("TeamId", node.get("teamId"))
        if pid is None or not isinstance(name, str) or not name.strip(): continue
        try: pid = int(pid)
        except (ValueError, TypeError): continue
        if pid < 1: continue
        try: tid = int(tid) if tid not in (None, "") else None
        except (ValueError, TypeError): tid = None
        if tid is None: continue  # Our local cache schema requires a real team ID
        def numeric(*names):
            for key in names:
                if node.get(key) is not None and node[key] != "":
                    try:
                        n = float(node[key])
                        return n if n == n and abs(n) != float("inf") else None
                    except (TypeError, ValueError, OverflowError): pass
            return None
        minutes = numeric("MinutesPlayed", "minutesPlayed", "Minutes", "minutes")
        matches = numeric("MatchesPlayed", "matchesPlayed", "Matches", "matches", "appearances")
        if matches is not None and (matches < 0 or not matches.is_integer()): matches = None
        rating = numeric("StatValue", "statValue", "rating", "value")
        record = {
            "player_id": pid, "name": name.strip(), "team_id": tid,
            "team": str(node.get("TeamName", node.get("teamName")) or ""),
            "minutes": minutes, "matches": int(matches) if matches is not None else None,
            "rating": rating, "market_value": None, "market_date": None,
        }
        previous = found.get((pid, tid))
        if previous is None or (record["minutes"] or -1) > (previous["minutes"] or -1):
            found[(pid, tid)] = record
    return list(found.values())


def season_matches(league_payload, requested):
    """Reject fallback to another available season (common with older years)."""
    requested = season_slug(requested)
    info = league_payload.get("details") if isinstance(league_payload, dict) else None
    if not isinstance(info, dict): return False
    chosen = info.get("selectedSeason", league_payload.get("selectedSeason"))
    if chosen is None: return False
    return season_slug(chosen) == requested


def atomic_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".new")
    with tmp.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.flush(); os.fsync(handle.fileno())
    os.replace(tmp, path)


def display_league(league, existing):
    name = league["name"]
    if name in existing:
        old_id = existing[name]
        if old_id != league["id"]:
            name += " (" + league["country"] + ")"
    return name


def collect(root, league_list, seasons, *, http=None, progress=None, stop=None, cache_file=None):
    """One opt-in incremental job per league-season; keep existing snapshots.

    A league may have a season but no rating.json: report rather than guess.
    """
    root = Path(root)
    http = http or FotMobHttp()
    cache_file = Path(cache_file or root / "datos" / "fotmob_bigfive_cache.json")
    base = json.loads(cache_file.read_text(encoding="utf-8-sig")) if cache_file.exists() else {}
    if not isinstance(base, dict): raise ValueError("La caché original no es un objeto JSON.")
    played_path = root / "datos" / "team_matches_cache.json"
    played = json.loads(played_path.read_text(encoding="utf-8-sig")) if played_path.exists() else {"schema":"mf_legacy_team_matches_v1","entries":{}}
    played.setdefault("entries", {})
    known = dict(FIVE_IDS)
    known.update({str(v.get("league", k.split("|")[0])): v.get("league_id") or FIVE_IDS.get(v.get("league")) for k, v in base.items() if isinstance(v, dict)})
    report = {"requested": 0, "updated": 0, "skipped": 0, "errors": [], "team_match_entries": 0}
    tasks = [(d, season) for d in league_list for season in seasons]
    report["requested"] = len(tasks)
    for pos, (league, season) in enumerate(tasks, 1):
        if stop is not None and stop.is_set(): break
        label = f"{league['country']} · {league['name']} · {season}"
        if progress: progress(pos, len(tasks), label)
        try:
            if season_slug(season) != season: raise ValueError("Temporada inválida.")
            ident = int(league["id"])
            name = display_league(league, known)
            key = f"{name}|{season}"
            # Keep a previous player/market snapshot exactly as it was recorded.
            is_existing = key in base
            payload = http.json(BASE + "leagues?" + urlencode({"id": ident, "season": season, "ccode3": str(league.get("ccode") or "USA")}))
            if not season_matches(payload, season):
                raise ValueError("FotMob no confirmó la temporada solicitada; puede estar fuera de cobertura histórica.")
            counted = extract_team_matches(payload, league_id=ident, season=season, competition=name)
            for item in counted:
                played["entries"][f"{ident}|{season}|{item['team_id']}"] = item
                report["team_match_entries"] += 1
            if not is_existing:
                url = rating_url(payload)
                if not url: raise ValueError("No hay ranking rating.json disponible para esta liga/temporada.")
                players = parse_rating(http.json(url))
                if not players: raise ValueError("El ranking no contenía IDs de jugador y club verificables.")
                for p in players:
                    match = lookup_team_matches(played, ident, season, p["team_id"])
                    if match is not None:
                        p["team_matches"] = match
                base[key] = {"league": name, "league_id": ident, "season": season,
                             "rank_count": len(players), "valued_count": 0, "coverage": 0,
                             "players": players, "metrics": {}, "source": "FotMob rating.json (revisión)"}
                known[name] = ident
                atomic_json(cache_file, base)
                report["updated"] += 1
            else:
                report["skipped"] += 1
            atomic_json(played_path, played)
        except Exception as err:
            report["errors"].append({"league": league["name"], "country": league["country"], "season": season, "error": str(err)[:200]})
            # Even if player ranking is unsupported, the verified match cache can help with later imports.
            if played["entries"]: atomic_json(played_path, played)
    return report


def verify_coverage(league_list, seasons, *, http=None, progress=None, stop=None):
    """Read-only coverage check: never touches player/team cache or downloads rankings.

    Only confirmed selectedSeason and an available rating URL qualify for player download.
    """
    http = http or FotMobHttp()
    entries=[]
    tasks=[(league,season) for league in league_list for season in seasons]
    for n,(league,season) in enumerate(tasks,1):
        if stop is not None and stop.is_set():break
        if progress: progress(n,len(tasks),f"VERIFICAR · {league['name']} · {season}")
        result={"id":league['id'],"country":league['country'],"competition":league['name'],"season":season,
                "verified_season":False,"rating_available":False,"status":"no_verificada"}
        try:
            if season_slug(season)!=season:raise ValueError("Temporada inválida")
            payload=http.json(BASE+"leagues?"+urlencode({"id":int(league['id']),"season":season,"ccode3":str(league.get('ccode') or 'USA')}))
            if not season_matches(payload,season):
                result['status']='temporada_no_confirmada'
            else:
                result['verified_season']=True
                result['rating_available']=bool(rating_url(payload))
                result['status']='ranking_disponible' if result['rating_available'] else 'sin_ranking_de_jugadores'
        except Exception as exc:
            result['status']='error_consulta';result['error']=str(exc)[:250]
        entries.append(result)
    return {"checked":len(entries),"requested":len(tasks),"stopped":len(entries)<len(tasks),"entries":entries,
            "ready":sum(e['status']=='ranking_disponible' for e in entries)}
