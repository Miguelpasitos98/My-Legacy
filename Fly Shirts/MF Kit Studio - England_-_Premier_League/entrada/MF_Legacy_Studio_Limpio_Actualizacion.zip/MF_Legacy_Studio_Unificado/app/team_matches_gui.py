"""Review/confirm team played counts, including cup fixture candidates."""
from __future__ import annotations

import tkinter as tk
from datetime import datetime, timezone
from pathlib import Path
from tkinter import messagebox, ttk

from .league_expansion import atomic_json
from .team_matches import read_team_matches


class TeamMatchesWindow(tk.Toplevel):
    def __init__(self, parent, root, on_change):
        super().__init__(parent)
        self.root=Path(root);self.on_change=on_change
        self.title("MF LEGACY | PJ equipo por competición · revisión")
        self.geometry("1070x660");self.minsize(850,500)
        self.configure(bg="#121e32")
        self.cache=read_team_matches(root)
        self.entries=self.cache.get("entries",{})
        self.search=tk.StringVar();self.new_value=tk.StringVar()
        self._build();self.refresh()

    def _button(self,parent,title,cmd):
        return tk.Button(parent,text=title,command=cmd,font=("Segoe UI",10,"bold"),fg="white",bg="#23589c",
                         relief="flat",padx=10,pady=7)

    def _build(self):
        head=tk.Frame(self,bg="#163358",padx=20,pady=12);head.pack(fill="x")
        tk.Label(head,text="PJ del equipo · por competición y temporada",font=("Segoe UI",14,"bold"),fg="white",bg="#163358").pack(anchor="w")
        tk.Label(head,text="Clasificación final = dato reutilizable. Copas y temporadas en curso = cifra preliminar hasta que la confirmes.",font=("Segoe UI",9),fg="#cee0f5",bg="#163358").pack(anchor="w")
        row=tk.Frame(self,bg="#121e32",padx=16,pady=10);row.pack(fill="x")
        tk.Label(row,text="Buscar liga, equipo o temporada:",bg="#121e32",fg="white").pack(side="left")
        tk.Entry(row,textvariable=self.search,font=("Segoe UI",10),bg="#233855",fg="white",insertbackground="white",relief="flat",width=47).pack(side="left",padx=12,ipady=4)
        self.search.trace_add("write",lambda *_:self.refresh())
        body=tk.Frame(self,bg="#121e32",padx=15);body.pack(fill="both",expand=True)
        cols=("competition","season","team","count","status","source")
        self.tree=ttk.Treeview(body,columns=cols,show="headings",selectmode="browse")
        for key,label,size in (("competition","COMPETICIÓN",235),("season","TEMPORADA",105),
                               ("team","EQUIPO",185),("count","PJ EQUIPO",95),
                               ("status","COBERTURA",180),("source","ORIGEN",190)):
            self.tree.heading(key,text=label);self.tree.column(key,width=size,stretch=key in {"competition","team","source"})
        scroll=ttk.Scrollbar(body,command=self.tree.yview);self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right",fill="y");self.tree.pack(side="left",fill="both",expand=True)
        self.tree.bind("<<TreeviewSelect>>",self.select)
        foot=tk.Frame(self,bg="#163358",padx=15,pady=12);foot.pack(fill="x")
        tk.Label(foot,text="Valor comprobado:",bg="#163358",fg="white").pack(side="left")
        tk.Entry(foot,textvariable=self.new_value,width=7).pack(side="left",padx=(7,14))
        self._button(foot,"Confirmar valor seleccionado",self.confirm).pack(side="left")
        self._button(foot,"Cerrar",self.destroy).pack(side="right")
        self.status=tk.StringVar(value="")
        tk.Label(foot,textvariable=self.status,bg="#163358",fg="#cfe2f6",font=("Segoe UI",9)).pack(side="right",padx=15)

    def refresh(self):
        q=self.search.get().casefold().strip()
        self.tree.delete(*self.tree.get_children())
        rows=sorted(self.entries.items(),key=lambda x:(x[1].get("season",""),x[1].get("competition",""),x[1].get("team_name","")),reverse=True)
        for key,row in rows:
            hay=" ".join(str(row.get(k,"")) for k in ("competition","season","team_name","team_id"))
            if q and q not in hay.casefold():continue
            self.tree.insert("","end",iid=key,values=(row.get("competition"),row.get("season"),row.get("team_name"),
                row.get("team_matches"),row.get("status"),row.get("source")))
        if hasattr(self,"status"):self.status.set(f"{len(self.tree.get_children())} equipos")

    def select(self,event=None):
        selected=self.tree.selection()
        if selected:self.new_value.set(str(self.entries[selected[0]].get("team_matches","")))

    def confirm(self):
        selected=self.tree.selection()
        if not selected:return messagebox.showinfo("Selecciona un equipo","Selecciona primero una fila.",parent=self)
        key=selected[0];item=self.entries[key]
        try:
            n=int(self.new_value.get())
            if not 1<=n<=200:raise ValueError()
        except ValueError:
            return messagebox.showwarning("Valor inválido","Indica un número entero entre 1 y 200.",parent=self)
        warning=(f"CONFIRMAR POR REVISIÓN HUMANA\n\n{item.get('team_name')}\n{item.get('competition')} · {item.get('season')}\n\n"
                 f"Partidos del equipo: {n}\n\nLa lista de partidos visibles puede ser incompleta. Solo confirma si has verificado el número REAL de partidos disputados hasta la fecha de las estadísticas del jugador.\n\n¿Guardar como verificado manualmente?")
        if not messagebox.askyesno("Confirmación",warning,parent=self):return
        item["team_matches"]=n
        item["status"]="confirmed_by_user"
        item["source"]="Verificación explícita del usuario; no es verificación automática de FotMob"
        item["verified_utc"]=datetime.now(timezone.utc).isoformat()
        atomic_json(self.root/"datos"/"team_matches_cache.json",self.cache)
        self.refresh();self.on_change()
        messagebox.showinfo("Guardado","PJ equipo verificados para este club, temporada y competición.",parent=self)
