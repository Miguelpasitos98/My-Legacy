"""Ventana de exportación conjunta FotMob / CraftedFC (sin dependencias externas).
No consulta sitios web ni altera datos externos; procesa archivos JSON locales.
"""
from __future__ import annotations

import hashlib
import json
import os
import queue
import shutil
import stat
import tempfile
import threading
import traceback
import zipfile
from datetime import datetime
from pathlib import Path, PurePosixPath
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .unifier_core import build, find_dataset

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CRAFTED = ROOT / "FUENTES" / "CRAFTEDFC"
DEFAULT_OUTPUT = ROOT / "EXPORTACIONES" / "UNIFICADAS"
PREFS = ROOT / "config_unificado.json"
BG, PANEL, PANEL2, TEXT, MUTED, BLUE, GREEN = "#0c1324", "#141f35", "#1b2a45", "#f2f6fd", "#a8bcd4", "#1d85e5", "#35b789"


def validate_fotmob(path: Path) -> None:
    required = ["datos/fotmob_bigfive_cache.json", "datos/team_matches_cache.json", "datos/fotmob_league_directory.json"]
    missing = [x for x in required if not (path / x).is_file()]
    if missing:
        raise ValueError("Carpeta FotMob incompleta. Faltan:\n" + "\n".join(missing))


def validate_crafted(path: Path) -> None:
    required = ["metodologia/pesos_arquetipos.json", "metodologia/pipeline.json", "muestras/filas_temporada_de_perfiles.json", "FUENTES_PERFILES.json", "json_originales_web"]
    missing = [x for x in required if not (path / x).exists()]
    for prefix in ("jugadores", "clubes", "competiciones_clubes", "indices_ligas", "torneos_internacionales"):
        try:
            find_dataset(path, "datos_completos", prefix)
        except ValueError:
            missing.append(f"datos_completos/{prefix}_*.json (un solo archivo)")
    if missing:
        raise ValueError("El origen CraftedFC no tiene el formato de la exportación compatible. Faltan:\n" + "\n".join(missing))


def find_snapshot_dir(path: Path) -> Path:
    """Localiza un snapshot compatible aunque el ZIP contenga una carpeta envolvente."""
    if len(list((path / "datos_completos").glob("jugadores_*.json"))) == 1:
        validate_crafted(path)
        return path
    matches = [p.parent.parent for p in path.rglob("datos_completos/jugadores_*.json")]
    if len(matches) != 1:
        raise ValueError(f"Se esperaban 1 snapshot CraftedFC compatible; encontrados: {len(matches)}")
    validate_crafted(matches[0])
    return matches[0]


def secure_extract_zip(zip_path: Path, dest: Path):
    """Extrae solo ficheros regulares, bloqueando rutas peligrosas y ZIP bombs simples."""
    max_files = 2000
    max_total = 350 * 1024 * 1024
    extracted = 0
    total_unpacked = 0
    with zipfile.ZipFile(zip_path, "r") as arc:
        infos = arc.infolist()
        if len(infos) > max_files:
            raise ValueError("Demasiados archivos en el ZIP.")
        if sum(i.file_size for i in infos) > max_total:
            raise ValueError("ZIP demasiado grande una vez descomprimido (límite 350 MB).")
        for info in infos:
            name = info.filename.replace("\\", "/")
            pure = PurePosixPath(name)
            if pure.is_absolute() or any(p in ("..", "") or ":" in p for p in pure.parts):
                raise ValueError("El ZIP contiene una ruta peligrosa: " + info.filename)
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise ValueError("El ZIP contiene enlaces simbólicos no admitidos.")
            destination = dest.joinpath(*pure.parts)
            if info.is_dir():
                destination.mkdir(parents=True, exist_ok=True)
                continue
            if mode and not (stat.S_ISREG(mode) or stat.S_IFMT(mode) == 0):
                raise ValueError("Tipo de archivo no admitido en ZIP.")
            destination.parent.mkdir(parents=True, exist_ok=True)
            with arc.open(info) as rf, destination.open("wb") as wf:
                while chunk := rf.read(1024 * 1024):
                    total_unpacked += len(chunk)
                    if total_unpacked > max_total:
                        raise ValueError("Superado límite de extracción.")
                    wf.write(chunk)
            extracted += 1
    return extracted


def import_snapshot(zip_path: Path, target: Path):
    """Importa de forma transaccional. Mantiene respaldo y revierte ante errores."""
    target.parent.mkdir(parents=True, exist_ok=True)
    backups = ROOT / "RESPALDOS"
    old = None
    staging_parent = Path(tempfile.mkdtemp(prefix="craftedfc_import_", dir=str(target.parent)))
    tmp_snapshot = target.parent / (".CRAFTEDFC_NUEVO_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    try:
        secure_extract_zip(zip_path, staging_parent)
        found = find_snapshot_dir(staging_parent)
        shutil.copytree(found, tmp_snapshot)
        # Validación de integridad mínima ANTES de tocar el snapshot actual.
        players = json.loads(find_dataset(tmp_snapshot, "datos_completos", "jugadores").read_text(encoding="utf-8"))
        teams = json.loads(find_dataset(tmp_snapshot, "datos_completos", "clubes").read_text(encoding="utf-8"))
        if not isinstance(players, list) or not players or not isinstance(teams, list) or not teams:
            raise ValueError("El snapshot importado no contiene jugadores/clubes válidos.")
        if target.exists():
            backups.mkdir(parents=True, exist_ok=True)
            old = backups / ("CRAFTEDFC_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
            target.rename(old)
        try:
            tmp_snapshot.rename(target)
        except Exception:
            if old is not None and not target.exists():
                old.rename(target)
            raise
        return {"players": len(players), "teams": len(teams), "backup": str(old) if old else None}
    finally:
        if tmp_snapshot.exists():
            shutil.rmtree(tmp_snapshot, ignore_errors=True)
        if staging_parent.exists():
            shutil.rmtree(staging_parent, ignore_errors=True)


def write_json_atomic(path: Path, data: dict, progress):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".temporal")
    try:
        progress(92, "Escribiendo el JSON unificado (sin alterar las fuentes)...")
        with temporary.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            handle.flush()
            os.fsync(handle.fileno())
        progress(97, "Verificando el archivo y generando su huella SHA-256...")
        digest = hashlib.sha256()
        with temporary.open("rb") as handle:
            while chunk := handle.read(4 * 1024 * 1024):
                digest.update(chunk)
        if temporary.stat().st_size < 2:
            raise RuntimeError("El JSON producido es inesperadamente pequeño.")
        if path.exists():
            raise FileExistsError("El nombre de salida ya existe; no se sobrescribe: " + str(path))
        os.replace(temporary, path)
        progress(100, "Exportación completada y guardada correctamente.")
        return digest.hexdigest()
    finally:
        if temporary.exists():
            temporary.unlink()


class UnifiedWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("MF LEGACY | FotMob + CraftedFC · Exportación Unificada")
        self.geometry("890x760")
        self.minsize(790, 680)
        self.configure(bg=BG)
        self.fotmob = tk.StringVar(value=str(ROOT))
        self.crafted = tk.StringVar(value=str(DEFAULT_CRAFTED))
        self.output = tk.StringVar(value=str(DEFAULT_OUTPUT))
        self.status = tk.StringVar(value="Listo para generar un JSON unificado desde los datos locales.")
        self.counter = tk.StringVar(value="FotMob histórico + CraftedFC (snapshot incluido)")
        self.progress = tk.IntVar(value=0)
        fixed = DEFAULT_OUTPUT / "MF_Legacy_FotMob_CraftedFC_UNIFICADO.json"
        existing_exports = sorted(DEFAULT_OUTPUT.glob("MF_Legacy_FotMob_CraftedFC_*.json")) if DEFAULT_OUTPUT.is_dir() else []
        self.last_json = fixed if fixed.is_file() else (existing_exports[-1] if existing_exports else None)
        self.work_queue = queue.Queue()
        self.busy = False
        self._load_prefs()
        self._draw()
        self.after(120, self._poll)

    def _load_prefs(self):
        if PREFS.is_file():
            try:
                d = json.loads(PREFS.read_text(encoding="utf-8"))
                for attr in ("fotmob", "crafted", "output"):
                    value = d.get(attr)
                    if value and Path(value).is_dir():
                        getattr(self, attr).set(value)
            except (ValueError, OSError):
                pass

    def _save_prefs(self):
        try:
            PREFS.write_text(json.dumps({"fotmob": self.fotmob.get(), "crafted": self.crafted.get(), "output": self.output.get()}, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass

    def _label(self, frame, content, size=10, color=TEXT, bold=False, **kw):
        widget = tk.Label(frame, text=content, bg=frame.cget("bg"), fg=color,
                          font=("Segoe UI", size, "bold" if bold else "normal"), **kw)
        return widget

    def _button(self, frame, text, fn, primary=False):
        return tk.Button(frame, text=text, command=fn, cursor="hand2", relief="flat", bd=0,
                         font=("Segoe UI", 10, "bold"), padx=14, pady=10,
                         bg=BLUE if primary else PANEL2, fg="white", activebackground="#319ef9", activeforeground="white")

    def _draw(self):
        head = tk.Frame(self, bg=PANEL, padx=22, pady=20)
        head.pack(fill="x")
        self._label(head, "EXPORTACIÓN UNIFICADA", 19, bold=True).pack(anchor="w")
        self._label(head, "FotMob Legacy Studio V2 + CraftedFC  ·  Un único archivo JSON", 10, color=MUTED).pack(anchor="w", pady=(4, 0))

        main = tk.Frame(self, bg=BG, padx=24, pady=19)
        main.pack(fill="both", expand=True)
        self._label(main, "1   ORÍGENES DE DATOS", 12, bold=True).pack(anchor="w", pady=(0, 12))
        self._source_row(main, "Carpeta de FotMob Studio", self.fotmob, lambda: self._browse(self.fotmob), "Buscar carpeta")
        self._source_row(main, "Snapshot de CraftedFC", self.crafted, lambda: self._browse(self.crafted), "Buscar carpeta")
        self._button(main, "Importar nuevo ZIP de CraftedFC (opcional)", self._choose_zip).pack(anchor="w", pady=(1, 16))

        self._label(main, "2   DESTINO DE EXPORTACIÓN", 12, bold=True).pack(anchor="w", pady=(0, 12))
        self._source_row(main, "Guardar el JSON en", self.output, lambda: self._browse(self.output), "Cambiar carpeta")

        tk.Frame(main, bg="#30435f", height=1).pack(fill="x", pady=17)
        self._label(main, "3   GENERAR JSON", 12, bold=True).pack(anchor="w", pady=(0, 11))
        self._label(main, "La fusión utiliza IDs exactos, separa temporadas y evita sobrescribir los datos originales.", 10, color=MUTED, wraplength=800, justify="left").pack(anchor="w")
        self._label(main, "No descarga datos automáticamente ni modifica tu Base44 o Football Manager.", 10, color=MUTED).pack(anchor="w", pady=(4, 14))

        style = ttk.Style(self)
        style.configure("Unified.Horizontal.TProgressbar", thickness=16)
        ttk.Progressbar(main, style="Unified.Horizontal.TProgressbar", orient="horizontal", mode="determinate", maximum=100, variable=self.progress).pack(fill="x", pady=(3, 9))
        self._label(main, self.status, 10, color=GREEN, anchor="w", textvariable=self.status, wraplength=790).pack(fill="x", pady=(0, 10))
        self.generate_button = self._button(main, "GENERAR JSON UNIFICADO", self._generate, primary=True)
        self.generate_button.pack(fill="x", ipady=4, pady=(0, 11))

        row = tk.Frame(main, bg=BG)
        row.pack(fill="x")
        self.open_button = self._button(row, "Abrir carpeta de resultados", self._open_output)
        self.open_button.pack(side="left")
        self._button(row, "Abrir último JSON", self._open_json).pack(side="left", padx=8)
        self._label(main, "RESULTADO / REGISTRO", 11, bold=True).pack(anchor="w", pady=(15, 5))
        self.log = tk.Text(main, height=7, relief="flat", bg=PANEL, fg=TEXT, insertbackground=TEXT,
                           font=("Consolas", 9), state="disabled", wrap="word", padx=10, pady=8)
        self.log.pack(fill="both", expand=True)
        self._append("Snapshot de CraftedFC incluido. Puedes sustituirlo desde un nuevo ZIP compatible.")

    def _source_row(self, parent, title, var, action, button_text):
        self._label(parent, title, 10, bold=True).pack(anchor="w", pady=(4, 5))
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", pady=(0, 12))
        entry = tk.Entry(row, textvariable=var, font=("Segoe UI", 9), relief="flat", bd=0,
                         bg=PANEL2, fg=TEXT, insertbackground=TEXT)
        entry.pack(side="left", fill="x", expand=True, ipady=12, padx=(0, 8))
        self._button(row, button_text, action).pack(side="right")

    def _browse(self, variable):
        p = filedialog.askdirectory(parent=self, title="Selecciona la carpeta", initialdir=variable.get())
        if p:
            variable.set(p)
            self._save_prefs()

    def _choose_zip(self):
        if self.busy:
            return
        file = filedialog.askopenfilename(parent=self, title="Selecciona la exportación ZIP de CraftedFC", filetypes=[("ZIP", "*.zip")])
        if not file:
            return
        if not messagebox.askyesno("Actualizar snapshot", "¿Importar el nuevo ZIP de CraftedFC?\n\nSe guardará un respaldo del snapshot anterior y no se modificará FotMob.", parent=self):
            return
        self.busy = True
        self.generate_button.configure(state="disabled")
        self._append("Importando ZIP de CraftedFC... Este proceso puede tardar un poco.")
        self.status.set("Importando snapshot, comprobando datos y guardando respaldo...")
        threading.Thread(target=self._import_job, args=(Path(file),), daemon=True).start()

    def _import_job(self, zip_path):
        try:
            result = import_snapshot(zip_path, DEFAULT_CRAFTED)
            self.work_queue.put(("import_done", result))
        except Exception:
            self.work_queue.put(("error", "Error al importar CraftedFC:\n" + traceback.format_exc()))

    def _generate(self):
        if self.busy:
            return
        f, c, o = Path(self.fotmob.get()), Path(self.crafted.get()), Path(self.output.get())
        try:
            validate_fotmob(f)
            validate_crafted(c)
            o.mkdir(parents=True, exist_ok=True)
            if not o.is_dir():
                raise ValueError("La ruta de salida no es una carpeta.")
        except Exception as exc:
            messagebox.showerror("Revisa las carpetas", str(exc), parent=self)
            return
        self._save_prefs()
        self.busy = True
        self.progress.set(0)
        self.generate_button.configure(state="disabled")
        self.status.set("Iniciando exportación...")
        self._append("--- Comienza la fusión FotMob + CraftedFC ---")
        threading.Thread(target=self._export_job, args=(f, c, o), daemon=True).start()

    def _export_job(self, f, c, o):
        try:
            def report(pct, message):
                self.work_queue.put(("progress", (pct, message)))
            data = build(f, c, progress_callback=report)
            # Nombre estable: cada nueva exportación reemplaza la anterior.
            # write_json_atomic termina usando os.replace, sin dejar JSON parcial.
            target = o / "MF_Legacy_FotMob_CraftedFC_UNIFICADO.json"
            digest = write_json_atomic(target, data, report)
            self.work_queue.put(("done", {"target": str(target), "digest": digest, "summary": data["summary"]}))
        except Exception:
            self.work_queue.put(("error", "Error en la exportación:\n" + traceback.format_exc()))

    def _append(self, line):
        self.log.configure(state="normal")
        self.log.insert("end", line + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _poll(self):
        try:
            while True:
                action, val = self.work_queue.get_nowait()
                if action == "progress":
                    pct, msg = val
                    self.progress.set(pct)
                    self.status.set(msg)
                elif action == "done":
                    self.busy = False
                    self.generate_button.configure(state="normal")
                    self.last_json = Path(val["target"])
                    s = val["summary"]
                    self.status.set("Exportación correcta: " + self.last_json.name)
                    self._append(f"Guardado: {self.last_json}")
                    self._append(f"Jugadores: {s['players_total']:,} | Vinculados: {s['players_exact_id_match']:,} | Clubes: {s['teams_total']:,}")
                    self._append(f"Históricos FotMob: {s['fotmob_historical_records']:,} | CraftedFC: {s['craftedfc_players']:,}")
                    self._append("SHA-256: " + val["digest"])
                    messagebox.showinfo("JSON unificado generado", "Archivo creado correctamente.\n\n" + str(self.last_json) + "\n\nEl JSON es para revisión antes de importarlo en Base44.", parent=self)
                elif action == "import_done":
                    self.busy = False
                    self.generate_button.configure(state="normal")
                    self.crafted.set(str(DEFAULT_CRAFTED))
                    self._save_prefs()
                    self.status.set("Snapshot CraftedFC actualizado.")
                    self._append(f"CraftedFC actualizado: {val['players']:,} jugadores, {val['teams']:,} clubes.")
                    if val['backup']:
                        self._append("Respaldo anterior: " + val['backup'])
                    messagebox.showinfo("Importación terminada", "CraftedFC se ha actualizado. FotMob permanece intacto.", parent=self)
                elif action == "error":
                    self.busy = False
                    self.generate_button.configure(state="normal")
                    self.status.set("La operación ha fallado; revisa el registro.")
                    self._append(val)
                    messagebox.showerror("Error", val[-1700:], parent=self)
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(120, self._poll)

    def _open_output(self):
        try:
            output = Path(self.output.get())
            output.mkdir(parents=True, exist_ok=True)
            os.startfile(str(output)) if os.name == "nt" else messagebox.showinfo("Carpeta", str(output), parent=self)
        except Exception as exc:
            messagebox.showerror("Abrir carpeta", str(exc), parent=self)

    def _open_json(self):
        if not self.last_json or not self.last_json.is_file():
            messagebox.showinfo("Todavía no hay JSON", "Primero genera un JSON unificado.", parent=self)
        elif os.name == "nt":
            os.startfile(str(self.last_json))
        else:
            messagebox.showinfo("Archivo", str(self.last_json), parent=self)


def show_window(parent):
    window = UnifiedWindow(parent)
    window.focus_set()
    return window
