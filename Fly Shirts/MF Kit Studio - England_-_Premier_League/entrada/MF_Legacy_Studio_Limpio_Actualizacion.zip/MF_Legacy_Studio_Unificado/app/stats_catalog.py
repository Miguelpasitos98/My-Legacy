"""Catálogo de estadísticas de FotMob para su presentación, sin cifras sintéticas.

Los nombres admiten variantes históricas en inglés y rótulos españoles.
Una métrica desconocida permanece visible en 'Otras estadísticas'.
"""
from __future__ import annotations
import re
import unicodedata


def key(label):
    text = str(label or '').strip().casefold()
    # Un porcentaje no puede colisionar con su contador (pases vs pases %).
    is_percent = '%' in text or 'percentage' in text or 'percent ' in text
    plain=''.join(c for c in unicodedata.normalize('NFKD',text) if not unicodedata.combining(c))
    plain=re.sub(r'[^a-z0-9]+','-',plain).strip('-')
    return plain + ('-pct' if is_percent and not plain.endswith(('pct','percentage')) else '')

# (identificador, categoría, etiqueta española, unidad, nombres aceptados)
CATEGORIES = [
    ('TIROS Y GOLES',[
        ('goals','Goles','',('Goals','Goles')),
        ('xg','Goles esperados (xG)','',('xG','Expected goals','Goles esperados')),
        ('xgot','xG a puerta (xGOT)','',('xGOT','Expected goals on target','xG on target')),
        ('npxg','xG sin penaltis','',('xG excl. penalty','Non-penalty xG','xG excluding penalties','xG sin penaltis')),
        ('shots','Tiros','',('Shots','Total shots','Tiros')),
        ('shots_on_target','Tiros a puerta','',('Shots on target','Tiros a puerta')),
        ('headed_shots','Tiros de cabeza','',('Headed shots','Headers','Tiros de cabeza')),
    ]),
    ('RENDIMIENTO FÍSICO',[
        ('top_speed','Velocidad máxima','km/h',('Top speed','Maximum speed','Velocidad máxima')),
        ('distance','Distancia recorrida','km',('Total Distance Covered','Distance covered','Total distance','Distancia recorrida')),
        ('running','Carrera','km',('Running','Carrera')),
        ('sprinting','Sprint','km',('Sprinting','Sprint')),
        ('sprints','Número de sprints','',('Number of Sprints','Sprints','Número de sprints')),
    ]),
    ('PASES',[
        ('assists','Asistencias','',('Assists','Asistencias')),
        ('xa','Asistencias esperadas (xA)','',('xA','Expected assists','Asistencias esperadas')),
        ('accurate_passes','Pases completados','',('Accurate passes','Completed passes','Pases completados')),
        ('pass_accuracy','Pases completados %','%',('Pass accuracy','Accurate passes %','Pass accuracy %','Pases completados %')),
        ('long_passes','Pases largos precisos','',('Accurate long balls','Accurate long passes','Pases largos precisos')),
        ('long_pass_accuracy','Pases largos precisos %','%',('Long ball accuracy','Accurate long balls %','Long pass accuracy','Pases largos precisos %')),
        ('line_breaking_passes','Pases que rompen líneas','',('Line breaking passes','Line-breaking passes','Pases que rompen líneas')),
        ('chances_created','Oportunidades creadas','',('Chances created','Key passes','Oportunidades creadas')),
        ('big_chances_created','Ocasiones claras creadas','',('Big chances created','Ocasiones claras creadas')),
        ('crosses','Centros completados','',('Successful crosses','Accurate crosses','Centros completados')),
        ('cross_accuracy','Centros completados %','%',('Cross accuracy','Successful crosses %','Centros completados %')),
    ]),
    ('POSESIÓN',[
        ('dribbles','Regates exitosos','',('Dribbles','Successful dribbles','Regates exitosos')),
        ('dribble_accuracy','Regates exitosos %','%',('Dribbles success rate','Dribble success rate','Dribbles %','Regates exitosos %')),
        ('duels_won','Duelos ganados','',('Duels won','Duelos ganados')),
        ('duel_accuracy','Duelos ganados %','%',('Duels won %','Duel success rate','Duelos ganados %')),
        ('aerials_won','Duelos aéreos ganados','',('Aerials won','Duelos aéreos ganados')),
        ('aerial_accuracy','Duelos aéreos ganados %','%',('Aerials won %','Aerial duel success rate','% de duelos aéreos ganados')),
        ('touches','Toques','',('Touches','Toques')),
        ('box_touches','Toques en el área rival','',('Touches in opposition box','Touches in opponent box','Toques en el área rival')),
        ('dispossessed','Pérdidas de balón','',('Dispossessed','Times dispossessed','Pérdidas de balón')),
        ('fouls_won','Faltas recibidas','',('Fouls won','Fouls received','Faltas recibidas')),
    ]),
    ('DEFENSA',[
        ('def_actions','Acciones defensivas','',('Defensive actions','Acciones defensivas')),
        ('tackles','Entradas','',('Tackles','Entradas')),
        ('interceptions','Intercepciones','',('Interceptions','Intercepciones')),
        ('blocked_shots','Tiros bloqueados','',('Blocked shots','Blocked scoring attempt','Tiros bloqueados')),
        ('fouls','Faltas','',('Fouls committed','Fouls','Faltas')),
        ('recoveries','Recuperaciones','',('Recoveries','Recuperaciones')),
        ('high_regains','Posesión ganada en el tercio ofensivo','',('Possession won final 3rd','Possession won in final third','Posesión ganada en el tercio ofensivo')),
        ('dribbled_past','Regateado','',('Dribbled past','Regateado')),
        ('clearances','Despejes','',('Clearances','Despejes')),
        ('clean_sheets','Porterías a cero','',('Clean sheets','Porterías a cero')),
        ('goals_conceded','Goles en contra (en el campo)','',('Goals conceded while on pitch','Goals conceded on pitch','Goles en contra (en el campo)')),
        ('xga_on_pitch','xG en contra (en el campo)','',('xG against while on pitch','xG conceded while on pitch','xG en contra (en el campo)')),
    ]),
    ('DISCIPLINA',[
        ('yellow','Tarjetas amarillas','',('Yellow cards','Tarjetas amarillas')),
        ('red','Tarjetas rojas','',('Red cards','Tarjetas rojas')),
    ]),
]

ALIAS={}
CAT_ORDER={}
for heading,fields in CATEGORIES:
    for identity, label, unit, aliases in fields:
        CAT_ORDER[identity]=(heading,label,unit)
        for alias in (label, *aliases):
            ALIAS[key(alias)]=identity

# Se muestran, pero no se agregan, tasas, medias, máximos y estados puntuales.
ADD_IDS = {
    'goals','xg','xgot','npxg','shots','shots_on_target','headed_shots',
    'distance','running','sprinting','sprints','assists','xa',
    'accurate_passes','long_passes','line_breaking_passes','chances_created','big_chances_created','crosses',
    'dribbles','duels_won','aerials_won','touches','box_touches','dispossessed','fouls_won',
    'def_actions','tackles','interceptions','blocked_shots','fouls','recoveries',
    'high_regains','dribbled_past','clearances','clean_sheets','goals_conceded','xga_on_pitch','yellow','red',
}


def metric_id(label):
    return ALIAS.get(key(label))


def sections(metrics):
    """Devuelve categorías ordenadas con valores reales; ausencia => no disponible."""
    known={}; other=[]
    for item in metrics:
        mid=metric_id(item['name'])
        if mid:
            previous=known.get(mid)
            if previous is None or (previous.get('per90') is None and item.get('per90') is not None):
                known[mid]=item
        else:
            other.append(item)
    result=[]
    for heading,fields in CATEGORIES:
        rows=[]
        for mid,label,unit,_ in fields:
            if mid in known:
                item=known[mid]
                if mid in ('distance','running','sprinting'):
                    # FotMob statFormat='meter', while our UI displays km.
                    # Conversion is presentation-only; source/export JSON stays in meters.
                    converted=dict(item)
                    for f in ('value','per90'):
                        if converted.get(f) is not None:
                            converted[f]=converted[f]/1000.0
                    item=converted
                rows.append({**item,'id':mid,'label':label,'unit':unit,'available':True})
            else:
                rows.append({'id':mid,'name':label,'label':label,'unit':unit,'value':None,'per90':None,'percentile':None,'available':False})
        result.append((heading,rows))
    if other:
        result.append(('OTRAS ESTADÍSTICAS',[{**x,'id':None,'label':x['name'],'unit':'','available':True} for x in other]))
    return result


def fmt(value, unit='', decimals=2):
    if value is None:
        return '—'
    text=f'{value:,.{decimals}f}'.replace(',','§').replace('.',',').replace('§','.')
    text=text.rstrip('0').rstrip(',') if ',' in text else text
    return text + ((' '+unit) if unit and unit!='%' else (' %' if unit=='%' else ''))
