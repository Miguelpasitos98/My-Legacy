"""Exportar estadísticas detalladas que ya estén en la caché local.

No consulta la red ni modifica archivos de caché. Los registros básicos
no se hacen pasar por estadísticas avanzadas.
"""
from pathlib import Path
from .profile import load_profile_bundle, read_json, extract_stat_details, slug
from .fotmob_client import player_cache_path, stat_cache_path
from .batch_stats import options_for_export, coverage_report
from .profile import export_stats_bundle, export_stats_csv
from .team_matches import for_basic_record, read_team_matches
import json


def cached_detail_records(root, basic_records, player_ids):
    root=Path(root)
    records=[]
    options=[]
    problems=[]
    team_counts=read_team_matches(root)
    historical_cache={}
    try:
        historical_cache=json.loads((root/"datos"/"fotmob_bigfive_cache.json").read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        pass
    for pid in sorted({str(p) for p in player_ids if p}):
        profile=player_cache_path(root,pid)
        if not profile.exists():
            problems.append({'fotmob_player_id':pid,'error':'No existe perfil de temporadas en caché'})
            continue
        try:
            bundle=load_profile_bundle(profile)
            if bundle['player']['fotmob_player_id'] not in ('',pid):
                raise ValueError('Identificador del perfil no coincide con el jugador')
        except Exception as err:
            problems.append({'fotmob_player_id':pid,'error':str(err)[:200]})
            continue
        history=[r for r in basic_records if str(r.get('fotmob_player_id'))==pid]
        for option in options_for_export(bundle['season_options']):
            season=option['season'];competition=option['competition']
            options.append({'fotmob_player_id':pid,**option})
            path=stat_cache_path(root,pid,option['season_id'])
            if not path.exists():
                problems.append({'fotmob_player_id':pid,'season':season,'competition':competition,'error':'Estadísticas no guardadas en caché'})
                continue
            try:
                raw=read_json(path)
                meta=raw.get('_mf_legacy_meta') or {}
                if meta and (str(meta.get('player_id'))!=pid or
                             str(meta.get('season_id'))!=str(option['season_id'])):
                    raise ValueError('La caché corresponde a otro jugador o competición')
                candidates=[r for r in history if slug(r.get('season'))==slug(season) and slug(r.get('league'))==slug(competition)]
                ambiguous_label=sum(1 for o in bundle['season_options'] if slug(o.get('season'))==slug(season) and slug(o.get('competition'))==slug(competition))>1
                if ambiguous_label:
                    candidates=[r for r in candidates if str(r.get('fotmob_tournament_id') or '') and
                                str(r.get('fotmob_tournament_id'))==str(option.get('tournament_id') or '')]
                if len({str(r.get('fotmob_team_id') or '') for r in candidates})>1:
                    raise ValueError('Varias identidades de club en la misma competición; requiere revisión')
                team=candidates[0] if candidates else {}
                payload=raw.get('payload',raw)
                record=extract_stat_details(payload,player_id=pid,season=season,competition=competition,
                                           team_id=team.get('fotmob_team_id',''),team_name=team.get('team_name',''),
                                           tournament_id=option.get('tournament_id',''),profile_season_id=option.get('season_id',''))
                if not record['metrics']:
                    raise ValueError('Caché sin métricas reconocibles')
                count=for_basic_record({'league':competition,'season':season,
                                        'fotmob_team_id':team.get('fotmob_team_id','')},
                                        historical_cache,team_counts)
                if count is not None:record['team_matches']=count
                record['source']='FotMob · caché detallada local'
                record['review_status']='pending'
                records.append(record)
            except Exception as err:
                problems.append({'fotmob_player_id':pid,'season':season,'competition':competition,'error':str(err)[:200]})
    return records,options,problems


def export_cached_details(root, basic_records, player_ids, destination):
    records,options,problems=cached_detail_records(root,basic_records,player_ids)
    destination=Path(destination)
    destination.mkdir(parents=True,exist_ok=True)
    if records:
        export_stats_bundle(records,destination/'ESTADISTICAS_FOTMOB_DETALLADAS_BASE44_REVISION.json')
        export_stats_csv(records,destination/'ESTADISTICAS_FOTMOB_DETALLADAS_BASE44_REVISION.csv')
    report={
        'note':'Cobertura de estadísticas detalladas existentes en caché local; sin consultas de red.',
        'player_ids':sorted({str(p) for p in player_ids}),
        'records_with_metrics':len(records),
        'records_with_team_matches':sum(r.get('team_matches') is not None for r in records),
        'available_competitions':len(options),
        'missing_or_incompatible':problems,
    }
    (destination/'COBERTURA_ESTADISTICAS_DETALLADAS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
