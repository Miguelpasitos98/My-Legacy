"""League/season expansion dialog. All downloads require the user's click."""
from __future__ import annotations

import json
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .league_expansion import SEASONS, CALENDAR_SEASONS, FotMobHttp, collect, verify_coverage, load_directory, parse_directory, atomic_json
from .region_presets import TARGET_REGIONS, region_filter, region_for
from .team_matches import read_team_matches


class LeagueWindow(tk.Toplevel):
    def __init__(self, parent, root, cache_path, on_reload):
        super().__init__(parent)
        self.parent=parent
        self.root=Path(root)
        self.cache_path=Path(cache_path)
        self.on_reload=on_reload
        self.title("MF LEGACY | Ampliar ligas y temporadas")
        self.geometry("965x700")
        self.minsize(780,560)
        self.configure(bg="#101a2b")
        self.protocol("WM_DELETE_WINDOW",self.close)
        self.messages=queue.Queue()
        self.stop=threading.Event()
        self.running=False
        self.chosen=set()
        self.regions={name:tk.BooleanVar(value=True) for name in TARGET_REGIONS}
        self.coverage=None
        self.approved_tasks=set()
        self.calendar_mode=tk.BooleanVar(value=False)
        self.leagues=load_directory(root)
        self.byid={int(l['id']):l for l in self.leagues}
        self._build()
        self._render()
        self.after(160,self._poll)

    def _btn(self,frame,label,cmd):
        return tk.Button(frame,text=label,command=cmd,relief="flat",bg="#24426d",fg="white",
                         activebackground="#1d85e5",activeforeground="white",font=("Segoe UI",9,"bold"),padx=11,pady=7)

    def _build(self):
        head=tk.Frame(self,bg="#142842",padx=18,pady=15);head.pack(fill="x")
        tk.Label(head,text="Ampliar ligas · desde 2016/2017",fg="white",bg="#142842",font=("Segoe UI",15,"bold")).pack(side="left")
        self._btn(head,"Actualizar catálogo FotMob",self.download_directory).pack(side="right",padx=5)
        self._btn(head,"Cargar catálogo JSON",self.load_directory_file).pack(side="right")
        self._btn(head,"Revisar PJ equipo",self.show_team_matches).pack(side="right",padx=5)
        self._btn(head,"Exportar PJ equipos",self.export_team_matches).pack(side="right",padx=5)
        self.search=tk.StringVar()
        controls=tk.Frame(self,bg="#101a2b",padx=18,pady=12);controls.pack(fill="x")
        tk.Label(controls,text="BUSCAR PAÍS O LIGA",fg="#b3c7df",bg="#101a2b").pack(anchor="w")
        entry=tk.Entry(controls,textvariable=self.search,font=("Segoe UI",11),bg="#1b2a45",fg="white",insertbackground="white",relief="flat")
        entry.pack(fill="x",ipady=7)
        self.search.trace_add("write",lambda *_:self._render())
        geo=tk.Frame(controls,bg="#101a2b");geo.pack(fill="x",pady=(7,0))
        tk.Label(geo,text="REGIONES",fg="#b3c7df",bg="#101a2b").pack(side="left",padx=(0,9))
        for name,var in self.regions.items():
            tk.Checkbutton(geo,text=name,variable=var,command=self._render,bg="#101a2b",fg="white",selectcolor="#24426d",activebackground="#101a2b",activeforeground="white").pack(side="left",padx=3)
        tk.Label(controls,text="Elige competiciones disponibles en el directorio. Se comprobará cada temporada antes de guardar. Las copas pueden carecer de ranking.",fg="#b3c7df",bg="#101a2b",wraplength=870,anchor="w",justify="left").pack(anchor="w",pady=(9,0))
        middle=tk.Frame(self,bg="#101a2b",padx=18);middle.pack(fill="both",expand=True)
        left=tk.Frame(middle,bg="#101a2b");left.pack(side="left",fill="both",expand=True)
        self.tree=ttk.Treeview(left,columns=("country","league","id"),show="headings",selectmode="extended",height=10)
        for name,title,width in (("country","PAÍS",165),("league","COMPETICIÓN",285),("id","ID",65)):
            self.tree.heading(name,text=title);self.tree.column(name,width=width,anchor="w")
        scroll=ttk.Scrollbar(left,command=self.tree.yview);self.tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right",fill="y");self.tree.pack(side="left",fill="both",expand=True)
        self.tree.bind("<<TreeviewSelect>>",self._selected)
        right=tk.Frame(middle,bg="#18283f",width=205,padx=11,pady=10);right.pack(side="left",fill="y",padx=(12,0))
        tk.Label(right,text="TEMPORADAS",font=("Segoe UI",10,"bold"),fg="white",bg="#18283f").pack(anchor="w",pady=(0,8))
        self.years={}
        tk.Checkbutton(right,text="Años naturales (MLS)",variable=self.calendar_mode,command=self._refresh_years,
                       bg="#18283f",fg="#eaf1fa",selectcolor="#24426d",
                       activebackground="#18283f",activeforeground="white").pack(anchor="w",pady=(0,8))
        self.years_frame=tk.Frame(right,bg="#18283f");self.years_frame.pack(fill="x")
        self._refresh_years()
        self._btn(right,"Marcar todos los años",lambda:[v.set(True) for v in self.years.values()]).pack(fill="x",pady=(8,3))
        self._btn(right,"Solo 2016/2017",self.only_2016).pack(fill="x")
        bar=tk.Frame(self,bg="#101a2b",padx=18,pady=10);bar.pack(fill="x")
        self.selection_label=tk.StringVar(value="0 ligas seleccionadas")
        tk.Label(bar,textvariable=self.selection_label,fg="#b3c7df",bg="#101a2b",font=("Segoe UI",9,"bold")).pack(side="left")
        self._btn(bar,"Seleccionar las visibles",self.select_visible).pack(side="right",padx=(6,0))
        self._btn(bar,"Limpiar selección",self.clear_selected).pack(side="right")
        bottom=tk.Frame(self,bg="#142842",padx=18,pady=12);bottom.pack(fill="x")
        self.status=tk.StringVar(value="Catálogo local listo. Actualízalo si quieres buscar todas las ligas de FotMob.")
        tk.Label(bottom,textvariable=self.status,fg="white",bg="#142842",anchor="w",justify="left",wraplength=780).pack(fill="x")
        self.progress=ttk.Progressbar(bottom,orient="horizontal",mode="determinate")
        self.progress.pack(fill="x",pady=8)
        buttons=tk.Frame(bottom,bg="#142842");buttons.pack(fill="x")
        self.start_button=self._btn(buttons,"DESCARGAR VERIFICADAS",self.start);self.start_button.pack(side="right",padx=5)
        self.verify_button=self._btn(buttons,"1. VERIFICAR COBERTURA",self.check_coverage);self.verify_button.pack(side="right",padx=5)
        self._btn(buttons,"Detener al terminar la petición",self.stop_now).pack(side="right")
        self._btn(buttons,"Cerrar",self.close).pack(side="left")

    def _render(self):
        if not hasattr(self,"tree"):return
        q=self.search.get().casefold().strip()
        self.tree.delete(*self.tree.get_children())
        selected_regions=[name for name,var in self.regions.items() if var.get()]
        for league in region_filter(self.leagues,selected_regions):
            if q and q not in (league["country"]+" "+league["name"]+" "+str(league["id"])).casefold():continue
            self.tree.insert("","end",iid=str(league["id"]),values=(league["country"],league["name"],league["id"]))
        matching=[str(x) for x in self.chosen if self.tree.exists(str(x))]
        self.tree.selection_set(matching)
        self.selection_label.set(f"{len(self.chosen)} ligas seleccionadas · {len(self.tree.get_children())} visibles")

    def _selected(self,event=None):
        visible={int(x) for x in self.tree.get_children()}
        self.chosen.difference_update(visible)
        self.chosen.update(int(x) for x in self.tree.selection())
        self.selection_label.set(f"{len(self.chosen)} ligas seleccionadas · {len(visible)} visibles")

    def select_visible(self):
        self.chosen.update(int(x) for x in self.tree.get_children());self._render()

    def clear_selected(self):
        self.chosen.clear();self._render()

    def _refresh_years(self):
        for child in self.years_frame.winfo_children():child.destroy()
        current=CALENDAR_SEASONS if self.calendar_mode.get() else SEASONS
        self.years={}
        for year in current:
            var=tk.BooleanVar(value=year==("2023" if self.calendar_mode.get() else "2016/2017"))
            self.years[year]=var
            tk.Checkbutton(self.years_frame,text=year,variable=var,bg="#18283f",fg="#eaf1fa",selectcolor="#24426d",
                           activebackground="#18283f",activeforeground="white",anchor="w").pack(anchor="w")

    def only_2016(self):
        if self.calendar_mode.get():self.calendar_mode.set(False);self._refresh_years()
        for y,var in self.years.items():var.set(y=="2016/2017")

    def _replace_directory(self,entries):
        self.leagues=entries;self.byid={int(x['id']):x for x in entries}
        self.chosen.intersection_update(self.byid)
        self._render()

    def export_team_matches(self):
        from .team_matches import export_team_match_audit
        target=self.root/"EXPORTACIONES"
        try:
            _json,_csv,count=export_team_match_audit(self.root,target)
            messagebox.showinfo("PJ equipos",f"{count} registros de equipo/temporada exportados.\n\n{_json}\n{_csv}\n\nRevisa el estado de cobertura antes de reutilizarlos.",parent=self)
        except Exception as err:messagebox.showerror("Exportación",str(err),parent=self)

    def show_team_matches(self):
        from .team_matches_gui import TeamMatchesWindow
        TeamMatchesWindow(self,self.root,self.on_reload)

    def download_directory(self):
        if self.running:return
        self.running=True;self.status.set("Actualizando catálogo de FotMob... (consulta puntual)")
        def worker():
            try:self.messages.put(("directory",load_directory(self.root,online=True)))
            except Exception as err:self.messages.put(("error",str(err)))
        threading.Thread(target=worker,daemon=True).start()

    def load_directory_file(self):
        path=filedialog.askopenfilename(parent=self,title="Catálogo JSON de allLeagues",filetypes=[("JSON","*.json")])
        if not path:return
        try:
            raw=json.loads(Path(path).read_text(encoding="utf-8-sig"))
            items=parse_directory(raw)
            if not items:raise ValueError("El JSON no contiene competiciones compatibles.")
            atomic_json(self.root/"datos"/"fotmob_league_directory.json",raw)
            self._replace_directory(items)
            self.status.set(f"Catálogo importado: {len(items)} ligas.")
        except Exception as err:messagebox.showerror("Catálogo",str(err),parent=self)

    def check_coverage(self):
        if self.running:return
        leagues=[self.byid[x] for x in sorted(self.chosen) if x in self.byid]
        seasons=[s for s,flag in self.years.items() if flag.get()]
        n=len(leagues)*len(seasons)
        if not n:
            messagebox.showinfo("Selecciona ligas","Selecciona las ligas y los años que quieras verificar.",parent=self);return
        if n>120:
            messagebox.showwarning("Lote demasiado grande",f"Has seleccionado {n} combinaciones. Para evitar saturar FotMob, verifica como máximo 120 a la vez. Divide la selección en lotes.",parent=self);return
        if not messagebox.askyesno("Verificar sin descargar",f"Se consultará la disponibilidad histórica de {n} combinaciones, sin descargar estadísticas de jugadores ni reemplazar la caché.\n¿Continuar?",parent=self):return
        self.coverage=None;self.approved_tasks.clear();self.stop.clear()
        self.running=True;self.start_button.configure(state="disabled");self.verify_button.configure(state="disabled")
        self.progress.configure(maximum=n,value=0)
        def progress(current,total,label):self.messages.put(("progress",current,total,label))
        def worker():
            try:self.messages.put(("coverage",verify_coverage(leagues,seasons,http=FotMobHttp(),stop=self.stop,progress=progress)))
            except Exception as err:self.messages.put(("error",str(err)))
        threading.Thread(target=worker,daemon=True).start()

    def start(self):
        if self.running:return
        leagues=[self.byid[x] for x in sorted(self.chosen) if x in self.byid]
        seasons=[s for s,flag in self.years.items() if flag.get()]
        if not leagues or not seasons:
            messagebox.showinfo("Selecciona datos","Marca al menos una liga y una temporada.",parent=self);return
        # Explicit verification is mandatory before downloading each league/year.
        wanted={(int(l['id']),str(s)) for l in leagues for s in seasons}
        if not self.coverage or not wanted.issubset(self.approved_tasks):
            messagebox.showwarning("Verifica primero","Primero pulsa «1. VERIFICAR COBERTURA». Si cambias la selección, vuelve a verificarla antes de descargar.",parent=self);return
        available={(int(e['id']),str(e['season'])) for e in self.coverage['entries'] if e['status']=='ranking_disponible'}
        # collect accepts league/seasons Cartesian combinations, so perform one pair at a time
        # to ensure an unverified combination can NEVER be downloaded.
        approved=[(l,s) for l in leagues for s in seasons if (int(l['id']),str(s)) in available]
        if not approved:
            messagebox.showinfo("Sin cobertura","FotMob no ha confirmado un ranking histórico de jugadores para ninguna combinación.",parent=self);return
        n=len(approved)
        if not messagebox.askyesno("Confirmar consulta",f"Se descargarán {n} combinaciones con ranking previamente verificado.\n\n"+
                 "FotMob puede no tener ranking o partidos completos para algunas.\n\n"+
                 "La aplicación respetará una pausa entre solicitudes, conservará todos tus datos y permitirá detener el proceso.\n¿Empezar?",parent=self):return
        self.stop.clear();self.running=True;self.start_button.configure(state="disabled")
        self.progress.configure(maximum=n,value=0)
        def progress(current,total,label):self.messages.put(("progress",current,total,label))
        def worker():
            try:
                http=FotMobHttp();combined={"requested":n,"updated":0,"skipped":0,"errors":[],"team_match_entries":0}
                for i,(league,season) in enumerate(approved,1):
                    if self.stop.is_set():break
                    progress(i,n,league['name']+" · "+season)
                    result=collect(self.root,[league],[season],http=http,stop=self.stop,cache_file=self.cache_path)
                    for key in ("updated","skipped","team_match_entries"):combined[key]+=result[key]
                    combined["errors"].extend(result["errors"])
                self.messages.put(("finished",combined))
            except Exception as err:self.messages.put(("error",str(err)))
        threading.Thread(target=worker,daemon=True).start()

    def stop_now(self):
        self.stop.set();self.status.set("Se detendrá después de completar la petición actual.")

    def _poll(self):
        try:
            while True:
                msg=self.messages.get_nowait()
                if msg[0]=="coverage":
                    self.coverage=msg[1]
                    self.approved_tasks={(int(e['id']),str(e['season'])) for e in self.coverage['entries']}
                    self.running=False;self.start_button.configure(state="normal");self.verify_button.configure(state="normal")
                    self.progress["value"]=self.coverage['checked']
                    report_path=self.root/"EXPORTACIONES"/"COBERTURA_PREVIA_LIGAS.json"
                    atomic_json(report_path,self.coverage)
                    summary=f"Verificadas: {self.coverage['checked']} / {self.coverage['requested']} · Ranking disponible: {self.coverage['ready']} · Informe: {report_path}"
                    self.status.set(summary)
                    messagebox.showinfo("Cobertura revisada",summary+"\n\nSolo se podrán descargar los rankings confirmados. No se han alterado estadísticas.",parent=self)
                elif msg[0]=="directory":
                    self._replace_directory(msg[1]);self.running=False;self.coverage=None;self.approved_tasks.clear()
                    self.status.set(f"Catálogo actualizado: {len(msg[1])} ligas disponibles para seleccionar.")
                elif msg[0]=="progress":
                    self.progress["value"]=msg[1]-1
                    self.status.set(f"{msg[1]}/{msg[2]} · {msg[3]}")
                elif msg[0]=="finished":
                    data=msg[1]
                    self.running=False;self.start_button.configure(state="normal");self.verify_button.configure(state="normal")
                    self.progress["value"]=self.progress["maximum"]
                    summary=f"Ligas/temporadas añadidas: {data['updated']} · Ya estaban: {data['skipped']} · Problemas: {len(data['errors'])} · Partidos de equipo observados: {data['team_match_entries']}"
                    self.status.set(summary)
                    path=self.root/"EXPORTACIONES"/"COBERTURA_NUEVAS_LIGAS.json"
                    atomic_json(path,data)
                    self.on_reload()
                    messagebox.showinfo("Ampliación completada",summary+f"\n\nInforme: {path}\nLos valores de mercado no se inventan.",parent=self)
                elif msg[0]=="error":
                    self.running=False;self.start_button.configure(state="normal");self.verify_button.configure(state="normal")
                    self.status.set("Error: "+msg[1][:200]);messagebox.showerror("Ampliación",msg[1],parent=self)
        except queue.Empty:pass
        if self.winfo_exists():self.after(160,self._poll)

    def close(self):
        if self.running:
            messagebox.showinfo("Descarga en curso","Pulsa Detener y espera a que finalice la petición antes de cerrar.",parent=self)
            return
        self.destroy()
