"""Ventana adicional para analizar fichas JSON locales de jugador y estadísticas."""
from __future__ import annotations
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from .profile import load_profile_bundle, read_json, extract_stat_details, export_profile_bundle, export_stats_bundle


class ProfileWindow(tk.Toplevel):
    def __init__(self, parent, filepath):
        super().__init__(parent)
        self.title('MF LEGACY · Perfil FotMob local')
        self.geometry('1090x720')
        self.minsize(830,560)
        self.bundle=load_profile_bundle(filepath)
        self.detail=None
        self.detail_records={}
        ident=self.bundle['player']
        self.configure(bg='#0c1324')
        self._label(f"{ident['name'] or 'Jugador'}  ·  FotMob ID: {ident['fotmob_player_id'] or 'no disponible'}",21,bold=True).pack(anchor='w',padx=24,pady=(22,4))
        self._label(f"Club: {ident['primary_team'] or 'sin identificar'}    ·    "
                    f"Etapas/temporadas: {len(self.bundle['career'])}    ·    "
                    f"Competiciones disponibles: {len(self.bundle['season_options'])}",11).pack(anchor='w',padx=24)
        self._label('Datos del fichero local; las temporadas no prueban las fechas contractuales. Importación a Base44 pendiente de revisión.',10).pack(anchor='w',padx=24,pady=(6,15))
        frame=tk.Frame(self,bg='#0c1324');frame.pack(fill='both',expand=True,padx=24)
        notebook=ttk.Notebook(frame);notebook.pack(fill='both',expand=True)
        career_box=ttk.Frame(notebook);notebook.add(career_box,text='TRAYECTORIA POR TEMPORADA')
        stats_box=ttk.Frame(notebook);notebook.add(stats_box,text='ESTADÍSTICAS DE COMPETICIÓN')
        opt_box=ttk.Frame(notebook);notebook.add(opt_box,text='COMPETICIONES DISPONIBLES')

        cols=('season','team','comp','app','goals','assists','rating')
        headers=('TEMPORADA','EQUIPO','COMPETICIÓN','PJ','GOLES','ASIST.','NOTA')
        self.career_tree=ttk.Treeview(career_box,columns=cols,show='headings')
        for c,h in zip(cols,headers):
            self.career_tree.heading(c,text=h)
            self.career_tree.column(c,width=140 if c in ('team','comp') else 93,stretch=c in ('team','comp'),anchor='w' if c in ('team','comp') else 'center')
        vs=ttk.Scrollbar(career_box,orient='vertical',command=self.career_tree.yview)
        self.career_tree.configure(yscrollcommand=vs.set)
        vs.pack(side='right',fill='y');self.career_tree.pack(side='left',fill='both',expand=True)
        for r in self.bundle['career']:
            fmt=lambda x: '—' if x is None else f'{x:g}' if isinstance(x,(float,int)) else str(x)
            self.career_tree.insert('', 'end', values=(r['season'],r['team_name'],r['competition'] or '—',*(fmt(r[k]) for k in ('appearances','goals','assists','rating'))))
        self.stats_header=tk.StringVar(value='Carga el archivo JSON de estadísticas de UNA competición para visualizarlo.')
        ttk.Label(stats_box,textvariable=self.stats_header,wraplength=820).pack(anchor='w',padx=12,pady=8)
        self.stats_tree=ttk.Treeview(stats_box,columns=('name','value','per90','percentile'),show='headings')
        for c,h in (('name','MÉTRICA'),('value','VALOR'),('per90','/90'),('percentile','PERCENTIL')):
            self.stats_tree.heading(c,text=h);self.stats_tree.column(c,width=240 if c=='name' else 95,anchor='w' if c=='name' else 'center')
        self.stats_tree.pack(fill='both',expand=True,padx=12,pady=8)

        self.options_tree=ttk.Treeview(opt_box,columns=('season','competition','season_id','deep'),show='headings')
        for c,h in (('season','TEMPORADA'),('competition','COMPETICIÓN'),('season_id','ID INTERNO'),('deep','AVANZADAS')):
            self.options_tree.heading(c,text=h)
            self.options_tree.column(c,width=260 if c=='competition' else 130,anchor='w')
        self.options_tree.pack(fill='both',expand=True,padx=12,pady=12)
        for o in self.bundle['season_options']:
            self.options_tree.insert('', 'end',values=(o['season'],o['competition'],o['season_id'],'Sí' if o['advanced'] else 'No'))
        controls=tk.Frame(self,bg='#0c1324');controls.pack(fill='x',padx=24,pady=20)
        for label,func in (("Cargar estadísticas locales",self.load_stats),
                           ("Exportar trayectoria JSON",self.save_career),
                           ("Exportar estadísticas JSON",self.save_stats)):
            tk.Button(controls,text=label,command=func,bg='#1d85e5',fg='white',font=('Segoe UI',10,'bold'),
                      relief='flat',padx=14,pady=10,activebackground='#2b9ef6',activeforeground='white').pack(side='left',padx=(0,9))
        tk.Button(controls,text='Cerrar',command=self.destroy,relief='flat',padx=14,pady=10).pack(side='right')
        self.grab_set()

    def _label(self,text,size,bold=False):
        return tk.Label(self,text=text,font=('Segoe UI',size,'bold' if bold else 'normal'),fg='#f1f5ff',bg='#0c1324')

    def save_career(self):
        if not self.bundle['career']:
            messagebox.showwarning('Sin trayectoria','El archivo no contiene careerHistory interpretable.',parent=self);return
        path=filedialog.asksaveasfilename(parent=self,title='Guardar trayectoria revisable',defaultextension='.json',
            initialfile='HISTORIAL_FOTMOB_SOLO_REVISION.json',filetypes=[('JSON','*.json')])
        if path:
            export_profile_bundle(self.bundle,path)
            messagebox.showinfo('Guardado',f'Trayectoria guardada en:\n{path}',parent=self)

    def load_stats(self):
        path=filedialog.askopenfilename(parent=self,title='Abrir estadísticas JSON existentes',filetypes=[('JSON','*.json')])
        if not path:return
        ident=self.bundle['player']
        pid=ident['fotmob_player_id'] or simpledialog.askstring('ID FotMob','Indica el ID FotMob numérico del jugador:',parent=self)
        if not pid:return
        season=simpledialog.askstring('Temporada','Indica la temporada (p. ej. 2024/2025):',parent=self)
        if not season:return
        competition=simpledialog.askstring('Competición','Indica la competición (p. ej. LaLiga):',parent=self)
        if not competition:return
        # El club actual no debe atribuirse automáticamente a temporadas históricas.
        team=simpledialog.askstring('Club histórico','Club en esa temporada (opcional; déjalo vacío si no lo sabes):',parent=self) or ''
        team_id=''
        try:
            payload=read_json(path)
            self.detail=extract_stat_details(payload,player_id=pid,season=season,competition=competition,team_id=team_id,team_name=team)
        except Exception as error:
            messagebox.showerror('Archivo no válido',str(error),parent=self);return
        self.stats_tree.delete(*self.stats_tree.get_children())
        for r in self.detail['metrics']:
            f=lambda v: '—' if v is None else f'{v:g}'
            self.stats_tree.insert('', 'end',values=(r['name'],f(r['value']),f(r['per90']),f(r['percentile'])))
        self.detail_records[self.detail['external_record_id']] = self.detail
        self.stats_header.set(f"{season} · {competition}  |  {len(self.detail['metrics'])} métricas  |  "
                              f"{len(self.detail['conflicts'])} discrepancias  ·  "
                              f"{len(self.detail_records)} competiciones cargadas · Revisar antes de importar")
        if not self.detail['metrics']:
            messagebox.showwarning('Sin métricas','Este JSON no tiene pares title/value reconocibles.',parent=self)

    def save_stats(self):
        if not self.detail_records:
            messagebox.showwarning('Sin estadísticas','Primero carga uno o varios JSON de estadísticas.',parent=self);return
        path=filedialog.asksaveasfilename(parent=self,title='Guardar estadísticas revisables',defaultextension='.json',
            initialfile='ESTADISTICAS_FOTMOB_LOTE_REVISION.json',filetypes=[('JSON','*.json')])
        if path:
            export_stats_bundle(list(self.detail_records.values()),path)
            messagebox.showinfo('Guardado',f'Estadísticas guardadas en:\n{path}',parent=self)
