"""Interfaz gráfica de consulta y exportación de datos locales históricos.

Usa únicamente la biblioteca estándar: Tkinter, JSON y CSV. No navega ni descarga.
"""
from pathlib import Path
import csv
import os
import subprocess
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .core import load_cache, load_mapping, classify_csv, to_records, filter_records, summarize, export_csv, export_json, export_report
from .team_matches import read_team_matches
from .history_sync import read_overlay, save_overlay, sync_player, merged_records

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CACHE = ROOT / "datos" / "fotmob_bigfive_cache.json"
OUTPUT = ROOT / "EXPORTACIONES"

COLORS = {
    "bg": "#0c1324", "panel": "#141f35", "panel2": "#1b2a45",
    "text": "#f2f6fd", "muted": "#a8bcd4", "brand": "#1d85e5", "border": "#30435f",
}


class Studio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MF LEGACY | FotMob + CraftedFC · Studio")
        self.geometry("1160x740")
        self.minsize(940, 580)
        self.configure(bg=COLORS["bg"])
        self.cache_path = DEFAULT_CACHE
        self.mapping_path = None
        self.mapping = {}
        self.records = []
        self.ranking_records = []
        self.visible_records = []
        self.pending_search = None
        self.last_output_dir = OUTPUT
        self._style()
        self._layout()
        self._open_cache(DEFAULT_CACHE)

    def _style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Treeview", background=COLORS["panel"], foreground=COLORS["text"],
                        fieldbackground=COLORS["panel"], borderwidth=0, rowheight=30, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", background=COLORS["panel2"], foreground=COLORS["text"],
                        relief="flat", font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", COLORS["brand"])])
        style.configure("TCombobox", padding=7)

    def _label(self, parent, text, *, size=11, weight="normal", color=None, **kw):
        return tk.Label(parent, text=text, font=("Segoe UI", size, weight),
                        fg=color or COLORS["text"], bg=parent.cget("bg"), **kw)

    def _button(self, parent, text, command, *, primary=False):
        return tk.Button(parent, text=text, command=command, cursor="hand2", relief="flat",
                         font=("Segoe UI", 10, "bold"), padx=13, pady=10,
                         bg=COLORS["brand"] if primary else COLORS["panel2"],
                         fg="white", activebackground="#2e9df6", activeforeground="white")

    def _layout(self):
        menubar = tk.Menu(self)
        archive = tk.Menu(menubar, tearoff=False)
        archive.add_command(label="Abrir ficha JSON guardada", command=self.open_profile)
        archive.add_command(label="Elegir caché FotMob", command=self.change_cache)
        archive.add_separator()
        archive.add_command(label="Salir", command=self.destroy)
        menubar.add_cascade(label="Archivo", menu=archive)
        tools = tk.Menu(menubar, tearoff=False)
        tools.add_command(label="Ampliar ligas y temporadas", command=self.expand_leagues)
        tools.add_command(label="JSON global FotMob + CraftedFC", command=self.open_unifier)
        tools.add_separator()
        tools.add_command(label="Equivalencias de IDs (CSV opcional)", command=self.change_mapping)
        tools.add_command(label="Exportación histórica básica (JSON/CSV)", command=self.export_both)
        menubar.add_cascade(label="Herramientas", menu=tools)
        self.configure(menu=menubar)

        header = tk.Frame(self, bg=COLORS["panel"], padx=24, pady=17)
        header.pack(fill="x")
        self._label(header, "MF LEGACY", size=23, weight="bold").pack(side="left")
        self._label(header, "  FOTMOB + CRAFTEDFC  ·  STUDIO", size=10, color=COLORS["muted"]).pack(side="left", pady=9)
        self._label(header, "Jugador → FotMob → CraftedFC → Base44", size=10,
                    color=COLORS["muted"]).pack(side="right", pady=9)

        top = tk.Frame(self, bg=COLORS["bg"], padx=20, pady=14)
        top.pack(fill="x")
        filt = tk.Frame(top, bg=COLORS["bg"])
        filt.pack(fill="x")
        self.league = tk.StringVar(value="Todas")
        self.season = tk.StringVar(value="Todas")
        self.player = tk.StringVar()
        self.team = tk.StringVar()
        for col, label, var in ((0, "COMPETICIÓN", self.league), (1, "TEMPORADA", self.season)):
            block = tk.Frame(filt, bg=COLORS["bg"])
            block.grid(row=0, column=col, padx=(0, 16), sticky="ew")
            self._label(block, label, size=9, color=COLORS["muted"]).pack(anchor="w", pady=(0, 6))
            combo = ttk.Combobox(block, textvariable=var, state="readonly", width=22)
            combo.pack(fill="x", ipady=3)
            combo.bind("<<ComboboxSelected>>", lambda event: self.refresh())
            setattr(self, f"{ 'league' if col == 0 else 'season' }_select", combo)
        for col, label, var in ((2, "BUSCAR JUGADOR O ID", self.player), (3, "BUSCAR EQUIPO O ID", self.team)):
            block = tk.Frame(filt, bg=COLORS["bg"])
            block.grid(row=0, column=col, padx=(0, 16), sticky="ew")
            self._label(block, label, size=9, color=COLORS["muted"]).pack(anchor="w", pady=(0, 6))
            entry = tk.Entry(block, textvariable=var, font=("Segoe UI", 11), relief="flat", bd=0,
                             bg=COLORS["panel2"], fg="white", insertbackground="white")
            entry.pack(fill="x", ipady=9)
            var.trace_add("write", lambda *_: self.delayed_refresh())
        for col in range(4):
            filt.grid_columnconfigure(col, weight=1)

        self.status = tk.StringVar(value="Cargando datos locales...")
        stat = tk.Frame(top, bg=COLORS["panel2"], padx=15, pady=9)
        stat.pack(fill="x", pady=(17, 0))
        self._label(stat, "DATOS DISPONIBLES", size=9, color=COLORS["muted"]).pack(side="left")
        tk.Label(stat, textvariable=self.status, font=("Segoe UI", 10, "bold"), fg=COLORS["text"], bg=COLORS["panel2"]).pack(side="left", padx=16)

        tablebox = tk.Frame(self, bg=COLORS["bg"], padx=20)
        tablebox.pack(fill="both", expand=True)
        cols = ("player", "team", "league", "season", "matches", "minutes", "team_matches", "rating", "value")
        self.table = ttk.Treeview(tablebox, columns=cols, show="headings", selectmode="browse")
        headers = {"player":"JUGADOR", "team":"CLUB", "league":"COMPETICIÓN", "season":"TEMPORADA",
                   "matches":"PARTIDOS", "minutes":"MINUTOS", "team_matches":"PJ EQUIPO", "rating":"NOTA", "value":"VALOR (€)"}
        widths = {"player":200,"team":190,"league":152,"season":100,"matches":84,"minutes":90,"team_matches":83,"rating":80,"value":112}
        for col in cols:
            self.table.heading(col, text=headers[col])
            self.table.column(col, width=widths[col], stretch=col in ("player", "team", "league"), anchor="w" if col in ("player","team","league") else "center")
        scroll = ttk.Scrollbar(tablebox, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.table.pack(side="left", fill="both", expand=True)
        self.table.bind("<Double-1>", self.open_selected_player)
        self.table.bind("<Return>", self.open_selected_player)

        bottom = tk.Frame(self, bg=COLORS["panel"], padx=21, pady=13)
        bottom.pack(fill="x")
        self._label(bottom, "Selecciona un jugador · Las fuentes se guardan localmente",
                    size=9, color=COLORS["muted"]).pack(side="left")
        self._button(bottom, "EXPORTAR JUGADOR → BASE44", self.export_selected_base44, primary=True).pack(side="right", padx=(8, 0))
        self._button(bottom, "ABRIR JUGADOR", self.open_selected_player).pack(side="right", padx=(8, 0))
        self._button(bottom, "Abrir resultados", self.open_output).pack(side="right")

    def open_unifier(self):
        """Abre el módulo de exportación conjunta sin alterar la interfaz original."""
        from .combined_gui import show_window
        show_window(self)

    def _open_cache(self, path):
        try:
            cache = load_cache(path)
            new_records = to_records(cache, self.mapping, read_team_matches(Path(__file__).resolve().parent.parent))
            combined=merged_records(new_records,read_overlay(ROOT))
        except Exception as error:
            messagebox.showerror("Caché inválida", str(error))
            return
        # Read-only overlay of individual profiles; original rankings untouched.
        current_league=self.league.get()
        current_season=self.season.get()
        self.cache_path, self.ranking_records, self.records = Path(path), new_records, combined
        self.league_select["values"] = ["Todas"] + sorted({r["league"] for r in self.records})
        self.season_select["values"] = ["Todas"] + sorted({r["season"] for r in self.records})
        self.league.set(current_league if current_league in self.league_select["values"] else "Todas")
        self.season.set(current_season if current_season in self.season_select["values"] else "Todas")
        self.refresh()

    def sync_player_history(self, player_id):
        """Opt-in, offline and additive. Does not rewrite rating/league cache."""
        from .fotmob_client import player_cache_path
        pid=str(player_id)
        if not player_cache_path(ROOT,pid).exists():
            raise FileNotFoundError('Falta el perfil JSON de este jugador en datos/perfiles_fotmob. Consulta su perfil desde la ficha primero.')
        supplements,report=sync_player(ROOT,pid,self.ranking_records)
        old=read_overlay(ROOT)
        kept=[r for r in old if str(r.get('fotmob_player_id'))!=pid]
        save_overlay(ROOT,kept+supplements)
        self._open_cache(self.cache_path)
        return report

    def expand_leagues(self):
        from .league_gui import LeagueWindow
        home = Path(__file__).resolve().parent.parent
        cache = getattr(self, "cache_path", home / "datos" / "fotmob_bigfive_cache.json")
        reload = (lambda: self._open_cache(cache)) if hasattr(self, "_open_cache") else (lambda: None)
        LeagueWindow(self, home, cache, reload)

    def open_profile(self):
        path = filedialog.askopenfilename(title="Selecciona un archivo JSON de jugador de FotMob", filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            from .profile_gui import ProfileWindow
            ProfileWindow(self, path)
        except Exception as error:
            messagebox.showerror("No se pudo abrir la ficha", str(error))

    def change_cache(self):
        path = filedialog.askopenfilename(title="Seleccionar caché de estadísticas", filetypes=[("JSON", "*.json")])
        if path:
            self._open_cache(path)

    def _record_for_csv_player(self, player_id):
        """Permite abrir el jugador SIN tomar el CSV como fuente de IDs."""
        return next((r for r in self.records if str(r.get("fotmob_player_id")) == str(player_id)), None)

    def _chosen_player(self):
        selected = self.table.selection()
        if selected:
            try:
                return self.visible_records[int(selected[0])]
            except (ValueError, IndexError):
                pass
        ids = {str(r.get("fotmob_player_id")) for r in self.visible_records}
        if len(ids) == 1 and self.visible_records:
            return self.visible_records[0]
        return None

    def export_selected_base44(self):
        """Exporta FotMob + CraftedFC desde la caché, sin CSV de equivalencias."""
        record = self._chosen_player()
        if not record:
            messagebox.showinfo(
                "Selecciona un jugador",
                "Selecciona una fila del jugador o búscalo por su nombre/ID "
                "hasta que solo quede un futbolista.\n\n"
                "No necesitas usar «Vincular IDs» para exportar estadísticas.",
                parent=self,
            )
            return
        self._open_player_for_base44(record)

    def _open_player_for_base44(self, record):
        from .player_window import PlayerWindow
        window = PlayerWindow(self, record, self.records)
        # El botón EXPORTAR JUGADOR PARA BASE44 está visible en su historial.
        try:
            window.tabs.select(window.history_page)
        except (AttributeError, tk.TclError):
            pass
        return window

    def change_mapping(self):
        # Una equivalencia es opcional; no se necesita para exportar estadísticas.
        path = filedialog.askopenfilename(
            title="SOLO CSV DE EQUIVALENCIAS (fotmob_player_id + FM26 UID / Base44 ID)",
            filetypes=[("CSV de equivalencias", "*.csv")], parent=self,
        )
        if not path:
            return
        try:
            info = classify_csv(path)
            if info["kind"] == "statistics":
                ids = info["player_ids"]
                intro = (
                    "Este es un CSV de ESTADÍSTICAS, no de equivalencias.\n"
                    f"Contiene {info['row_count']:,} líneas de estadísticas.\n\n"
                    "No se ha cambiado ningún ID ni ningún dato.\n"
                )
                if len(ids) == 1 and self._record_for_csv_player(ids[0]):
                    open_now = messagebox.askyesno(
                        "CSV estadístico reconocido", intro +
                        f"\n¿Quieres abrir ahora la ficha FotMob {ids[0]} "
                        "para exportar el JSON unificado de Base44?",
                        parent=self,
                    )
                    if open_now:
                        self._open_player_for_base44(self._record_for_csv_player(ids[0]))
                else:
                    messagebox.showinfo(
                        "CSV estadístico reconocido",intro +
                        "\nBusca al jugador y utiliza JUGADOR → BASE44 "
                        "o EXPORTAR JUGADOR PARA BASE44 en su ficha.",parent=self,
                    )
                return
            if info["kind"] != "mapping":
                messagebox.showwarning(
                    "Archivo no compatible",
                    "No es un CSV de equivalencias.\n\n"
                    "El CSV de IDs requiere estas columnas:\n"
                    "fotmob_player_id;fm26_uid;base44_player_id\n\n"
                    "Para exportar estadísticas utiliza JUGADOR → BASE44.", parent=self,
                )
                return
            mapping = load_mapping(path)
            records = to_records(load_cache(self.cache_path), mapping, read_team_matches(ROOT))
        except (OSError, UnicodeError, ValueError, csv.Error) as error:
            messagebox.showwarning("Equivalencias no aplicadas", str(error), parent=self)
            return
        self.mapping, self.mapping_path, self.ranking_records = mapping, Path(path), records
        self.records = merged_records(records, read_overlay(ROOT))
        self.refresh()
        messagebox.showinfo(
            "IDs vinculados",
            f"{len(mapping)} equivalencias explícitas cargadas.\n"
            "No se ha vinculado a ningún jugador por coincidencia de nombre.",
            parent=self,
        )

    def delayed_refresh(self):
        if self.pending_search:
            self.after_cancel(self.pending_search)
        self.pending_search = self.after(240, self.refresh)

    def refresh(self):
        self.pending_search = None
        self.visible_records = filter_records(self.records,
            league="" if self.league.get()=="Todas" else self.league.get(),
            season="" if self.season.get()=="Todas" else self.season.get(),
            team=self.team.get(), player=self.player.get())
        summary = summarize(self.visible_records)
        supplements=sum(r.get('verification_status')=='perfil_individual_parcial' for r in self.visible_records)
        suffix=f' · {supplements} datos parciales del perfil' if supplements else ''
        self.status.set(f"{summary['records']:,} registros  ·  {summary['players']:,} jugadores  ·  {summary['teams']:,} clubes".replace(",", ".")+suffix)
        self.table.delete(*self.table.get_children())
        # Limitar filas mostradas, NO los datos exportados.
        for idx, r in enumerate(self.visible_records[:1800]):
            self.table.insert("", "end", iid=str(idx), values=(r["player_name"],r["team_name"] or "Club sin confirmar",r["league"],r["season"],
                r["appearances"] if r["appearances"] is not None else "—",
                f"{r['minutes']:,.0f}" if r["minutes"] is not None else "—",
                r.get("team_matches") if r.get("team_matches") is not None else "—",
                f"{r['rating']:.2f}" if r["rating"] is not None else "—",
                f"{r['market_value']:,.0f}" if r["market_value"] is not None else "—"))

    def open_selected_player(self, event=None):
        selected = self.table.selection()
        if event is not None and hasattr(event, "y"):
            hit = self.table.identify_row(event.y)
            if hit:
                selected = (hit,)
        if not selected:
            messagebox.showinfo("Selecciona un jugador", "Selecciona una fila y haz doble clic o pulsa 'Ver ficha del jugador'.")
            return
        try:
            record = self.visible_records[int(selected[0])]
        except (ValueError, IndexError):
            return
        from .player_window import PlayerWindow
        PlayerWindow(self, record, self.records)

    def export_both(self):
        if not self.visible_records:
            messagebox.showwarning("Sin registros", "No hay resultados con estos filtros.")
            return
        folder = filedialog.askdirectory(title="Seleccionar carpeta de salida", initialdir=str(OUTPUT if OUTPUT.exists() else ROOT))
        if not folder:
            return
        try:
            records = self.visible_records
            output = Path(folder)
            export_json(records, output / "LOTE_ESTADISTICAS_BASE44_REVISION.json")
            export_csv(records, output / "ESTADISTICAS_TEMPORADAS.csv")
            export_report(records, output / "RESUMEN_EXPORTACION.json")
            # La exportación general era SOLO la caché básica: incluir los detalles
            # de los jugadores filtrados que ya se hayan guardado en disco.
            from .detailed_cache_export import export_cached_details
            detail_report = export_cached_details(ROOT, self.records,
                {r["fotmob_player_id"] for r in records}, output)
            self.last_output_dir = output
        except Exception as error:
            messagebox.showerror("Error al exportar", str(error))
            return
        messagebox.showinfo("Exportación completada",
            f"{len(records)} registros básicos guardados en:\n{output}\n\n"
            f"Estadísticas detalladas con métricas: {detail_report['records_with_metrics']}\n"
            f"Competiciones identificadas: {detail_report['available_competitions']}\n\n"
            + ("IMPORTA EN MY LEGACY: ESTADISTICAS_FOTMOB_DETALLADAS_BASE44_REVISION.json\n\n"
               if detail_report['records_with_metrics'] else
               "No se encontraron métricas detalladas en la caché de los jugadores seleccionados.\n\n")
            + "Los archivos básicos LOTE_ESTADISTICAS_BASE44_REVISION.json y ESTADISTICAS_TEMPORADAS.csv siguen siendo solo resúmenes.")

    def open_output(self):
        target = self.last_output_dir
        target.mkdir(exist_ok=True)
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(target))
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(target)])
            else:
                subprocess.Popen(["xdg-open", str(target)])
        except Exception as error:
            messagebox.showerror("No se pudo abrir la carpeta", str(error))


def main():
    Studio().mainloop()


if __name__ == "__main__":
    main()
