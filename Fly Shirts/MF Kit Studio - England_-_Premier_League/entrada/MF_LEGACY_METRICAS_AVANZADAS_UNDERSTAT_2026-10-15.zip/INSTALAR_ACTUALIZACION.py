"""MF LEGACY · instalador seguro de métricas avanzadas (Windows 11).

Actualiza puntos concretos de código de la instalación REAL, no reemplaza
módulos existentes. Respaldo previo completo del código afectado y rollback.
"""
from pathlib import Path
from datetime import datetime
import shutil
import sys
import os

ROOT=Path(__file__).resolve().parent
MARK='# MF_LEGACY_ADVANCED_METRICS_V1'


def once(contents,old,new,filename):
    if contents.count(old)!=1:
        raise RuntimeError(f'{filename}: se esperaba una coincidencia de anclaje y hubo {contents.count(old)}. No se actualiza por seguridad.')
    return contents.replace(old,new,1)


def patched(filename,text):
    if MARK in text:
        print('Ya actualizado:',filename)
        return text
    if filename=='app/profile.py':
        text=once(text,"    return {\n        'external_record_id':'fotmob-stats:'",
'''    from .advanced_metrics import enrich_ground_duels
    enhanced_metrics, ground_note = enrich_ground_duels(list(stats.values()))
    ground_ok = any(m.get('name') == 'Ground duels won %' for m in enhanced_metrics)
    # MF_LEGACY_ADVANCED_METRICS_V1
    return {
        'external_record_id':'fotmob-stats:' ''',filename)
        text=once(text,"        'metrics':list(stats.values()),","        'metrics':enhanced_metrics,\n        'advanced_metrics_sources':({'Ground duels won %':'FotMob derived (4 inputs, unique denominators)'} if ground_ok else {}),\n        'ground_duels_reconstruction_note':ground_note,",filename)
    elif filename=='app/detailed_cache_export.py':
        text=once(text,"                if not record['metrics']:\n",'''                # MF_LEGACY_ADVANCED_METRICS_V1
                from .understat_bridge import enrich_cached_record
                record=enrich_cached_record(root,record)
                if not record['metrics']:
''',filename)
    elif filename=='app/player_window.py':
        text=once(text,'        tools.add_command(label="Exportar estadísticas en JSON + CSV", command=self.export_stats)',
'''        tools.add_command(label="Completar métricas avanzadas (Understat)", command=self.complete_advanced_stats)
        # MF_LEGACY_ADVANCED_METRICS_V1
        tools.add_command(label="Exportar estadísticas en JSON + CSV", command=self.export_stats)''',filename)
        text=once(text,"        filters=tk.Frame(self.stats_page,bg=PANEL,padx=12,pady=10);filters.pack(fill='x',pady=(6,8))",
'''        self._button(buttons,'4 · XG CHAIN / BUILDUP (UNDERSTAT)',self.complete_advanced_stats).pack(side='left',padx=(0,6))
        filters=tk.Frame(self.stats_page,bg=PANEL,padx=12,pady=10);filters.pack(fill='x',pady=(6,8))''',filename)
        text=once(text,"        rec['source']='FotMob · JSON local / consulta individual'",
'''        from .understat_bridge import enrich_cached_record
        rec=enrich_cached_record(ROOT,rec)
        rec['source']='FotMob · JSON local / consulta individual' ''',filename)
        method='''    def complete_advanced_stats(self):
        """Consulta voluntaria; los duelos terrestres ya se calculan offline."""
        if self._busy:return
        from .understat_bridge import eligible_target,fetch_all_for_player
        targets=[]
        for o in self.options:
            tid,team=self._club_from_cache(o['season'],o['competition'],o.get('tournament_id',''))
            if tid and team and eligible_target(o['season'],o['competition'],team):
                targets.append((o['season'],o['competition'],team))
        if not targets:
            messagebox.showinfo('Métricas avanzadas','Los duelos terrestres se calculan al leer/exportar las estadísticas guardadas. No hay liga europea y club confirmado compatibles con Understat. No se inventarán valores.',parent=self)
            return
        self._busy=True
        self.status_var.set('Consultando métricas xG Chain y xG Buildup…')
        def worker():
            try:
                result=fetch_all_for_player(ROOT,self.pid,self.selected.get('player_name',''),targets)
                err=None
            except Exception as exc:
                result=None;err=str(exc)
            def done():
                if not self.winfo_exists():return
                self._busy=False
                if err:
                    self.status_var.set('Understat no disponible. Los duelos terrestres siguen siendo calculables sin conexión.')
                    messagebox.showwarning('Consulta Understat pendiente',err,parent=self)
                    return
                self.status_var.set('Understat: '+str(len(result['downloaded']))+' nuevas, '+str(len(result['reused']))+' en caché y '+str(len(result['pending']))+' pendientes. Exporta de nuevo para Base44.')
                current=self._selected_option()
                if current and current.get('season_id'):
                    path=stat_cache_path(ROOT,self.pid,current['season_id'])
                    if path.is_file():
                        try:self._present_stats_file(path,current)
                        except (ValueError,OSError):pass
                if result['pending']:
                    examples='\\n'.join(x['season']+' · '+x['competition']+': '+x['reason'] for x in result['pending'][:7])
                    messagebox.showinfo('Consulta parcial',self.status_var.get()+'\\n\\n'+examples,parent=self)
                else:messagebox.showinfo('Métricas avanzadas',self.status_var.get(),parent=self)
            try:self.after(0,done)
            except (RuntimeError,tk.TclError):pass
        threading.Thread(target=worker,daemon=True).start()

'''
        text=once(text,'    def _on_stats(self,option,payload):',method+'    def _on_stats(self,option,payload):',filename)
    elif filename=='app/stats_catalog.py':
        old="        ('aerial_accuracy','Duelos aéreos ganados %','%',('Aerials won %','Aerial duel success rate','% de duelos aéreos ganados')),'"
        # use exact text without extra quote
        old="        ('aerial_accuracy','Duelos aéreos ganados %','%',('Aerials won %','Aerial duel success rate','% de duelos aéreos ganados'))," 
        new=old+'''
        # MF_LEGACY_ADVANCED_METRICS_V1
        ('ground_won','Duelos terrestres ganados','',('Ground duels won',)),
        ('ground_attempted','Duelos terrestres disputados','',('Ground duels contested',)),
        ('ground_pct','Duelos terrestres ganados %','%',('Ground duels won %','Ground duels success rate')),'''
        text=once(text,old,new,filename)
        text=once(text,"    ('DEFENSA',[",'''    ('XG PARTICIPACION — UNDERSTAT',[
        ('chain','xG Chain','',('xG Chain',)),
        ('buildup','xG Buildup','',('xG Buildup',)),
        ('understat_minutes','Minutos Understat','',('Understat minutes',)),
    ]),
    ('DEFENSA',[''',filename)
        text=once(text,"    'dribbles','duels_won','aerials_won','touches'", "    'dribbles','duels_won','aerials_won','ground_won','ground_attempted','touches'",filename)
    elif filename=='app/base44_export.py':
        text=once(text,"    if crafted:\n        batch.insert(0,",'''    # MF_LEGACY_ADVANCED_METRICS_V1
    advanced_counts={'ground_duels':0,'xg_chain':0,'xg_buildup':0}
    for entry in batch:
        if entry.get('kind')!='season':continue
        labels={m.get('name') for m in entry['data'].get('metrics') or []}
        if 'Ground duels won %' in labels:advanced_counts['ground_duels']+=1
        if 'xG Chain' in labels:advanced_counts['xg_chain']+=1
        if 'xG Buildup' in labels:advanced_counts['xg_buildup']+=1
    if crafted:
        batch.insert(0,''',filename)
        text=once(text,"      'fotmob_metrics':stat_count,'fotmob_exportable':verified,", "      'fotmob_metrics':stat_count,'advanced_metrics':advanced_counts,'fotmob_exportable':verified,",filename)
    else:raise ValueError('Archivo no previsto: '+filename)
    return text


def run(target):
    target=Path(target).expanduser().resolve()
    files=['app/profile.py','app/detailed_cache_export.py','app/player_window.py','app/stats_catalog.py','app/base44_export.py']
    if not (target/'INICIAR.pyw').is_file() or not all((target/name).is_file() for name in files):
        raise RuntimeError('No se reconoce la instalación MF_Legacy_Studio_Unificado: '+str(target))
    # Everything is validated before touching any file.
    new={name:patched(name,(target/name).read_text(encoding='utf-8')) for name in files}
    for name in ('app/advanced_metrics.py','app/understat_bridge.py'):
        new[name]=(ROOT/name).read_text(encoding='utf-8')
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    backup=target/'RESPALDOS'/('METRICAS_AVANZADAS_'+stamp)
    backup.mkdir(parents=True,exist_ok=False)
    saved=[];written=[]
    try:
        for name in new:
            source=target/name
            if source.is_file():
                dst=backup/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dst)
                saved.append(name)
        for name,content in new.items():
            dst=target/name
            temp=dst.with_suffix(dst.suffix+'.tmp_mflegacy')
            temp.write_text(content,encoding='utf-8')
            os.replace(temp,dst)
            written.append(name)
    except Exception:
        for name in written:
            b=backup/name
            if b.is_file():shutil.copy2(b,target/name)
            elif (target/name).exists():(target/name).unlink()
        raise
    (backup/'RESTAURAR.py').write_text('''from pathlib import Path
import shutil
here=Path(__file__).resolve().parent
root=here.parent.parent
for path in here.rglob('*'):
    if not path.is_file() or path.name=='RESTAURAR.py':continue
    if 'app' not in path.relative_to(here).parts:continue
    dst=root/path.relative_to(here)
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,dst)
    print('Restaurado:',dst)
''',encoding='utf-8')
    print('\nACTUALIZACIÓN COMPLETADA. Reinicia MF Legacy Studio.')
    print('Respaldo:',backup)
    print('Cachés, FUENTES, EXPORTACIONES y datos no modificados.')
    return backup

if __name__=='__main__':
    try:
        path=sys.argv[1] if len(sys.argv)>1 else r'E:\Football Manager\MF_Legacy_Studio_Unificado'
        run(path)
    except Exception as exc:
        print('NO SE HA ACTUALIZADO:',exc)
        raise SystemExit(1)
