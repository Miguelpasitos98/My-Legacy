from __future__ import annotations
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from app.advanced_metrics import attempted_from_percentage,derive_ground_duels,attach_understat_metrics
from app.profile import extract_stat_details
from app.understat_bridge import (eligible_target,selected_player,fetch_all_for_player,
                                  read_cached_metric,cache_file, same_team,enrich_cached_record)

class Tests(unittest.TestCase):
    def test_ground_from_cached_fotmob_values(self):
        # Historical sample of 4 FotMob aggregate stats (values retained,
        # but user caches are never bundled with the update).
        data=[
          {'name':'Duels won','value':41,'per90':1.96485623},
          {'name':'Duels won %','value':43.2,'per90':43.1578947368421},
          {'name':'Aerials won','value':3,'per90':0.14376996},
          {'name':'Aerials won %','value':75,'per90':75},
        ]
        rows,note=derive_ground_duels(data)
        values={m['name']:m['value'] for m in rows}
        self.assertEqual(values['Ground duels won'],38)
        self.assertEqual(values['Ground duels contested'],91)
        self.assertAlmostEqual(values['Ground duels won %'],41.758242,places=5)

    def test_example_from_fotmob_image(self):
        data=[
          {'name':'Duels won','value':21},{'name':'Duels won %','value':40.4,'per90':40.4},
          {'name':'Aerials won','value':10},{'name':'Aerials won %','value':41.7,'per90':41.7}]
        rows,note=derive_ground_duels(data)
        self.assertEqual({m['name']:m['value'] for m in rows}['Ground duels won'],11)
        self.assertEqual({m['name']:m['value'] for m in rows}['Ground duels contested'],28)
        self.assertAlmostEqual(rows[-1]['value'],39.285714,places=5)

    def test_ambiguous_denominator_is_null(self):
        self.assertIsNone(attempted_from_percentage(1,0.1,.05))
        self.assertIsNone(attempted_from_percentage(0,0,.05))
        self.assertEqual(derive_ground_duels([{'name':'Duels won','value':3}])[0],[])

    def test_invalid_ground_subtraction_no_output(self):
        data=[{'name':'Duels won','value':2},{'name':'Duels won %','value':100},
              {'name':'Aerials won','value':3},{'name':'Aerials won %','value':100}]
        self.assertEqual(derive_ground_duels(data)[0],[])

    def test_understat_minutes_not_fotmob(self):
        updated,ok=attach_understat_metrics([{'name':'Minutes','value':900}],
                          {'minutes':600,'xGChain':15,'xGBuildup':7})
        self.assertTrue(ok)
        d={m['name']:m for m in updated}
        self.assertAlmostEqual(d['xG Chain']['per90'],2.25)
        self.assertEqual(d['Understat minutes']['value'],600)
        self.assertEqual(d['Minutes']['value'],900)

    def test_league_not_cup_and_no_natural_seasons(self):
        self.assertEqual(eligible_target('2022/2023','Premier League','Manchester City'),('EPL','2022'))
        self.assertIsNone(eligible_target('2022/2023','Champions League','Manchester City'))
        self.assertIsNone(eligible_target('2018','Premier League','Manchester City'))
        self.assertIsNone(eligible_target('2022/2023','Premier League',''))

    def test_player_requires_exact_and_single_match(self):
        row={'id':'9','player_name':'Erling Haaland','team_title':'Manchester City',
             'time':'1700','xGChain':'21','xGBuildup':'11'}
        self.assertIsNotNone(selected_player([row],'Erling Haaland','Manchester City'))
        self.assertIsNone(selected_player([row],'Romelu Lukaku','Manchester City'))
        self.assertIsNone(selected_player([row],'Erling Haaland','Real Madrid'))
        self.assertIsNone(selected_player([row,row],'Erling Haaland','Manchester City'))
        self.assertTrue(same_team('Real Madrid CF','Real Madrid'))

    def test_read_cache_rejects_wrong_team(self):
        with tempfile.TemporaryDirectory() as td:
            path=cache_file(td,'1','2022/2023','EPL','Manchester City')
            path.parent.mkdir(parents=True)
            path.write_text(json.dumps({'fotmob_player_id':'1','season':'2022/2023','league':'EPL',
               'team':'Manchester City','verification':'exact_name_and_team',
               'minutes':100,'xGChain':5,'xGBuildup':2}),encoding='utf8')
            self.assertIsNotNone(read_cached_metric(td,'1','2022/2023','Premier League','Manchester City'))
            self.assertIsNone(read_cached_metric(td,'1','2022/2023','Premier League','Liverpool'))

    def test_fetch_mocked_offline_and_reuse_without_dup(self):
        fake={'id':'9','player_name':'Erling Haaland','team_title':'Manchester City',
             'time':'1700','xGChain':'21','xGBuildup':'11'}
        calls=[]
        class FakeClient:
            def __enter__(self):return self
            def __exit__(self,*args):return False
            def league(self,league):self.code=league;return self
            def get_player_data(self,season):calls.append((self.code,season));return [fake]
        with tempfile.TemporaryDirectory() as td:
            with patch('app.understat_bridge.time.sleep',lambda v:None):
                report=fetch_all_for_player(td,'737066','Erling Haaland',
                   [('2022/2023','Premier League','Manchester City'),
                    ('2022/2023','Premier League','Manchester City'),
                    ('2022/2023','Champions League','Manchester City')],client_factory=FakeClient)
            self.assertEqual(len(calls),1)
            self.assertEqual(len(report['downloaded']),2)
            self.assertEqual(len(report['pending']),1)
            rec={'fotmob_player_id':'737066','season':'2022/2023','competition':'Premier League',
                 'team_name':'Manchester City','metrics':[{'name':'Minutes','value':1800}]}
            enriched=enrich_cached_record(td,rec)
            self.assertEqual(len(enriched['metrics']),4)
            self.assertAlmostEqual(next(m for m in enriched['metrics'] if m['name']=='xG Buildup')['per90'],11*90/1700,places=7)
            with patch('app.understat_bridge.time.sleep',lambda v:None):
                report2=fetch_all_for_player(td,'737066','Erling Haaland',
                   [('2022/2023','Premier League','Manchester City')],client_factory=FakeClient)
            self.assertEqual(len(calls),1)
            self.assertEqual(len(report2['reused']),1)

if __name__=='__main__':unittest.main(verbosity=2)
