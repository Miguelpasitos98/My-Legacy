@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "STUDIO=E:\Football Manager\MF_Legacy_Studio_Unificado"
if not "%~1"=="" set "STUDIO=%~1"
echo.
echo ================================================
echo MF LEGACY - ACTUALIZACION METRICAS AVANZADAS
echo ================================================
echo.
echo Instalacion: "%STUDIO%"
echo Se realizara respaldo de codigo antes de cambiarlo.
echo Cierra MF Legacy Studio antes de continuar.
echo.
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0INSTALAR_ACTUALIZACION.py" "%STUDIO%"
) else (
    python "%~dp0INSTALAR_ACTUALIZACION.py" "%STUDIO%"
)
if errorlevel 1 (
  echo.
  echo La instalacion NO se ha completado. Lee el mensaje anterior.
) else (
  echo.
  echo La instalacion se ha completado.
  echo Understat opcional: py -m pip install understatapi
)
echo.
pause
