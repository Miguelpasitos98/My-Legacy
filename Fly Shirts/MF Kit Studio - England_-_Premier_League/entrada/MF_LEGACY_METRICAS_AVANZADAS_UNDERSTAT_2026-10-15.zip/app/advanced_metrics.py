"""MF LEGACY: métricas derivadas verificables y unión no destructiva.

Los porcentajes de FotMob NO son tasas por 90 aunque a veces el proveedor
almacene el valor de precisión completa en el campo `per90`.
Nunca se infieren denominadores cuando no hay una solución entera única.
"""
from __future__ import annotations
import math
import re
import unicodedata


def _norm(value):
    s=''.join(c for c in unicodedata.normalize('NFKD',str(value or '')) if not unicodedata.combining(c))
    plain=re.sub(r'[^a-z0-9]+','',s.lower())
    return plain + ('pct' if ('%' in s or 'percentage' in plain or 'percent' in plain) and not plain.endswith(('pct','percent','percentage')) else '')

ALIASES={
 'duels':{'duelswon','duelosganados'},
 'duels_pct':{'duelswon','duelswonpct','duelswonpercent','duelswonpercentage','duelsuccessrate','duelosganados'},
 'aerial':{'aerialswon','duelosaereosganados'},
 'aerial_pct':{'aerialswonpct','aerialduelsuccessrate','deduelosaereosganados'},
}

def _metric(metrics,names):
    for m in metrics:
        if _norm(m.get('name')) in names:return m
    return None

def _num(v):
    if isinstance(v,bool) or v is None:return None
    try:
        n=float(v)
        return n if math.isfinite(n) else None
    except (ValueError,TypeError):return None

def _wins(m):
    n=_num(m.get('value')) if m else None
    return int(n) if n is not None and n>=0 and n.is_integer() else None

def _percentage(m):
    if m is None:return None,None
    # FotMob stores more precision in `per90` for percentages. This is NOT a /90.
    detailed=_num(m.get('per90'))
    shown=_num(m.get('value'))
    # Not all historical FotMob versions encode precision the same way.
    # Accept `per90` only when it is consistent with the displayed percentage.
    if detailed is not None and 0<=detailed<=100 and shown is not None and abs(detailed-shown)<=.0500002:
        return detailed, (1e-7 if abs(detailed-round(detailed,1))>1e-6 else .0500001)
    if shown is None or not 0<=shown<=100:return None,None
    return shown,.0500001

def attempted_from_percentage(wins,rate,tolerance):
    """Infer integer attempts iff exactly one integer is compatible with rate.

    Does not invent zero attempts from 0 wins / 0%; n=0 is undefined.
    """
    if wins is None or rate is None or tolerance is None:return None
    if wins<=0 or rate<=0 or rate>100:return None
    low=max(0,rate-tolerance)
    high=min(100,rate+tolerance)
    lo=max(wins,math.ceil(wins*100/high-1e-8))
    hi=math.floor(wins*100/low+1e-8) if low>0 else 20001
    if hi>20000 or lo<1 or hi<lo or hi-lo>2000:return None
    matches=[n for n in range(lo,hi+1) if abs(wins*100/n-rate)<=tolerance+1e-9]
    return matches[0] if len(matches)==1 else None

def derive_ground_duels(metrics):
    """Produce 3 new metrics or an explicit absence reason (no guessing)."""
    existing={_norm(m.get('name')) for m in metrics}
    if 'groundduelswon' in existing or 'groundduelswonpct' in existing:
        return [],'Valor terrestre explícito conservado'
    total=_metric(metrics,ALIASES['duels'])
    total_pct=_metric(metrics,{'duelswonpct','duelswonpercent','duelswonpercentage','duelsuccessrate','duelosganadospct'})
    aerial=_metric(metrics,ALIASES['aerial'])
    aerial_pct=_metric(metrics,{'aerialswonpct','aerialduelsuccessrate','deduelosaereosganados'})
    won,wona=_wins(total),_wins(aerial)
    pt,tt=_percentage(total_pct)
    pa,ta=_percentage(aerial_pct)
    total_attempts=attempted_from_percentage(won,pt,tt)
    aerial_attempts=attempted_from_percentage(wona,pa,ta)
    if None in (won,wona,total_attempts,aerial_attempts):
        return [],'Duelos/porcentajes ausentes, cero ambiguo o denominador no recuperable'
    ground_won=won-wona
    ground_attempts=total_attempts-aerial_attempts
    if ground_won<0 or ground_attempts<=0 or ground_won>ground_attempts:
        return [],'Datos incompatibles entre duelos totales y aéreos'
    percent=round(ground_won/ground_attempts*100,6)
    return [
        {'name':'Ground duels won','value':ground_won,'per90':None,'percentile':None},
        {'name':'Ground duels contested','value':ground_attempts,'per90':None,'percentile':None},
        {'name':'Ground duels won %','value':percent,'per90':None,'percentile':None},
    ],''


def enrich_ground_duels(metrics):
    extra,note=derive_ground_duels(metrics)
    return list(metrics)+extra, note


def attach_understat_metrics(metrics,payload):
    """Add season+league+team verified Understat totals, keeping minutes separate."""
    data=payload or {}
    mins=_num(data.get('minutes'))
    chain=_num(data.get('xGChain'))
    buildup=_num(data.get('xGBuildup'))
    if mins is None or mins<=0 or chain is None or buildup is None or min(chain,buildup)<0:
        return list(metrics),False
    if chain<buildup-1e-7:return list(metrics),False
    additions=[
        {'name':'Understat minutes','value':mins,'per90':None,'percentile':None},
        {'name':'xG Chain','value':chain,'per90':round(chain*90/mins,7),'percentile':None},
        {'name':'xG Buildup','value':buildup,'per90':round(buildup*90/mins,7),'percentile':None},
    ]
    existing={_norm(m.get('name')) for m in metrics}
    return list(metrics)+[m for m in additions if _norm(m['name']) not in existing],True
