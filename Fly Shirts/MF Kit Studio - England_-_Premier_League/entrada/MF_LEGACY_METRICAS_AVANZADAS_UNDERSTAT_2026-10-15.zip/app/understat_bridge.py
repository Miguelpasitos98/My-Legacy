"""Consulta optativa, conservadora y cacheada de Understat (fuente no oficial).

No realiza peticiones automáticamente al exportar; solo desde una acción
explícita del usuario. No sortea login ni límites; falla ante ambigüedades.
"""
from __future__ import annotations
from datetime import datetime,timezone
from pathlib import Path
import json
import os
import re
import time
import unicodedata
from .advanced_metrics import attach_understat_metrics

LEAGUES={
    'premierleague':'EPL','laliga':'La_Liga','laligaeasports':'La_Liga','primeradivision':'La_Liga',
    'bundesliga':'Bundesliga','seriea':'Serie_A','ligue1':'Ligue_1',
    'russianpremierleague':'RFPL',
}

def norm(s):
    s=''.join(c for c in unicodedata.normalize('NFKD',str(s or '')) if not unicodedata.combining(c))
    s=re.sub(r'[^a-z0-9]+','',s.lower())
    return s

def club_norm(s):
    x=norm(s)
    for prefix in ('fc','afc','ac','cf'):
        if x.startswith(prefix) and len(x)>len(prefix)+5:x=x[len(prefix):];break
    for suffix in ('fc','cf'):
        if x.endswith(suffix) and len(x)>len(suffix)+5:x=x[:-len(suffix)];break
    return x

# Only approved, transparent name equivalences; not fuzzy similarity.
TEAM_ALIASES={
 'realmadridcf':'realmadrid','intermilan':'internazionale','inter':'internazionale',
 'fcinternazionalemilano':'internazionale','internazionalemilano':'internazionale',
 'interdemilan':'internazionale','bayernmunich':'bayernmunchen',
 'fcbayernmunchen':'bayernmunchen','parissaintgermain':'psg',
 'parissaintgermainfc':'psg','psg':'psg',
 'borussiadortmund':'borussiadortmund',
}

def same_team(a,b):
    aa=TEAM_ALIASES.get(norm(a),club_norm(a))
    bb=TEAM_ALIASES.get(norm(b),club_norm(b))
    return aa!="" and aa==bb

def eligible_target(season,competition,team):
    text=str(season or '')
    m=re.fullmatch(r'(20\d\d)/(20\d\d)',text)
    if not m or int(m.group(2))!=int(m.group(1))+1:return None
    if not str(team or '').strip():return None
    code=LEAGUES.get(norm(competition))
    return (code,m.group(1)) if code else None

def _n(v):
    try:
        n=float(v)
        if n!=n or n==float('inf') or n==float('-inf'):return None
        return n
    except (TypeError,ValueError):return None

def selected_player(rows,name,team):
    """Need exact player name + exact/approved club, never guess shared names."""
    match=[r for r in rows if norm(r.get('player_name'))==norm(name) and
           same_team(r.get('team_title'),team)]
    # If provider aggregates several teams into one row, team_title won't match.
    if len(match)!=1:return None
    row=match[0]
    mins=_n(row.get('time') if row.get('time') is not None else row.get('minutes'))
    chain=_n(row.get('xGChain'))
    buildup=_n(row.get('xGBuildup'))
    if any(v is None for v in (mins,chain,buildup)) or mins<=0 or min(chain,buildup)<0:return None
    if chain < buildup-1e-7:return None
    return {'understat_player_id':str(row.get('id') or ''),'minutes':mins,
            'xGChain':chain,'xGBuildup':buildup,'team':str(row['team_title']),
            'player':str(row['player_name'])}

def cache_file(root,pid,season,league,team):
    return Path(root)/'FUENTES'/'UNDERSTAT'/'cache'/str(pid)/f'{season.replace("/","-")}_{league}_{club_norm(team)}.json'

def read_cached_metric(root,pid,season,competition,team):
    target=eligible_target(season,competition,team)
    if not target:return None
    league,year=target
    path=cache_file(root,pid,season,league,team)
    if not path.is_file():return None
    try:
        doc=json.loads(path.read_text(encoding='utf-8'))
        if str(doc.get('fotmob_player_id'))!=str(pid) or doc.get('league')!=league or str(doc.get('season'))!=str(season):return None
        if not same_team(doc.get('team'),team):return None
        if doc.get('verification')!='exact_name_and_team':return None
        return doc
    except (OSError,ValueError,TypeError):return None

def enrich_cached_record(root,record):
    raw=read_cached_metric(root,record.get('fotmob_player_id'),record.get('season'),record.get('competition'),record.get('team_name'))
    if not raw:return record
    enriched,ok=attach_understat_metrics(record.get('metrics') or [],raw)
    if ok:
        record={**record,'metrics':enriched,'advanced_metrics_sources':{
          'xG Chain':'Understat','xG Buildup':'Understat',
          'understat_player_id':raw.get('understat_player_id'),
          'understat_minutes':raw.get('minutes')}}
    return record

def fetch_all_for_player(root,pid,player_name,targets,progress=None,client_factory=None):
    """targets: (season, competition, team); fetch one league-season at most once.

    Retries are not automatic: upstream rate-limit or failures stop a lookup
    and are recorded as pending. Existing caches are never overwritten on error.
    """
    if client_factory is None:
        try:from understatapi import UnderstatClient
        except ImportError as exc:raise RuntimeError('Falta understatapi. Instala con: py -m pip install understatapi') from exc
        client_factory=UnderstatClient
    grouped={}
    omitted=[]
    for season,comp,team in targets:
        resolved=eligible_target(season,comp,team)
        if not resolved:
            omitted.append({'season':season,'competition':comp,'reason':'Fuera de cobertura o equipo sin verificar'})
            continue
        code,year=resolved
        grouped.setdefault((code,year),[]).append((season,comp,team))
    report={'downloaded':[],'reused':[],'pending':omitted}
    with client_factory() as client:
        for (league,year),matches in grouped.items():
            to_fetch=[]
            for season,comp,team in matches:
                cache=read_cached_metric(root,pid,season,comp,team)
                if cache:report['reused'].append({'season':season,'competition':comp});continue
                to_fetch.append((season,comp,team))
            if not to_fetch:continue
            if progress:progress(f'Consultando Understat {league} {year}…')
            try:rows=client.league(league=league).get_player_data(season=year)
            except Exception as exc:
                for season,comp,team in to_fetch:
                    report['pending'].append({'season':season,'competition':comp,'reason':'Consulta fallida: '+str(exc)[:140]})
                continue
            if not isinstance(rows,list):
                for season,comp,team in to_fetch:report['pending'].append({'season':season,'competition':comp,'reason':'Formato inesperado'})
                continue
            for season,comp,team in to_fetch:
                match=selected_player(rows,player_name,team)
                if not match:
                    report['pending'].append({'season':season,'competition':comp,'reason':'Jugador/equipo no coinciden de manera única'})
                    continue
                data={**match,'source':'Understat (consulta pública no oficial)','league':league,
                      'season':season,'competition':comp,'fotmob_player_id':str(pid),
                      'verification':'exact_name_and_team','retrieved_at':datetime.now(timezone.utc).isoformat()}
                path=cache_file(root,pid,season,league,team)
                path.parent.mkdir(parents=True,exist_ok=True)
                tmp=path.with_suffix('.json.tmp')
                try:
                    tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
                    os.replace(tmp,path)
                    report['downloaded'].append({'season':season,'competition':comp})
                finally:
                    if tmp.exists():tmp.unlink()
            time.sleep(1.0)
    return report
