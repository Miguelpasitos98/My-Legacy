"""Regresiones: conservar temporadas sin mezclar clubes ni selecciones."""
from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch

from app.history_sync import _national_competition
from app.team_resolution import (resolve_career_team, season_key,
                                 save_assignments,load_assignments,
                                 multiple_clubs_in_international_cup)
from app.base44_export import create_player_batch


class TeamResolutionTests(unittest.TestCase):
    def setUp(self):
        self.bundle={
            'player':{'fotmob_player_id':'737066'},
            'career':[
                {'season':'2018/2019','team_name':'Molde','fotmob_team_id':'9917'},
                {'season':'2018/2019','team_name':'Salzburg','fotmob_team_id':'10013'},
                {'season':'2019/2020','team_name':'Salzburg','fotmob_team_id':'10013'},
                {'season':'2019/2020','team_name':'Borussia Dortmund','fotmob_team_id':'9789'},
                {'season':'2019/2020','team_name':'Norway','fotmob_team_id':'8492'},
            ],
            'season_options':[
                {'season':'2019/2020','competition':'Bundesliga','tournament_id':'54'},
                {'season':'2019/2020','competition':'Bundesliga','tournament_id':'38'},
            ]
        }
        self.basic=[{'fotmob_player_id':'737066','season':'2020/2021',
                     'league':'Bundesliga','fotmob_team_id':'9789',
                     'team_name':'Borussia Dortmund','fotmob_tournament_id':'54'}]
        self.detail={'fotmob_player_id':'737066','profile_season_id':'8-0',
                     'season':'2018/2019','competition':'Bundesliga','fotmob_tournament_id':'38'}

    def test_no_invented_club_when_two_candidates(self):
        tid, name, source, candidates=resolve_career_team(self.detail,self.bundle,self.basic,{})
        self.assertFalse(tid)
        self.assertTrue(any(c['team_name']=='Salzburg' for c in candidates))

    def test_manual_mapping_requires_actual_career_id_and_matching_season(self):
        key=season_key(self.detail)
        ok={key:{'fotmob_team_id':'10013','season':'2018/2019','competition':'Bundesliga'}}
        tid,name,source,_=resolve_career_team(self.detail,self.bundle,self.basic,ok)
        self.assertEqual((tid,name,source),('10013','Salzburg','usuario_confirmado'))
        bad={key:{'fotmob_team_id':'123456789','season':'2018/2019','competition':'Bundesliga'}}
        self.assertFalse(resolve_career_team(self.detail,self.bundle,self.basic,bad)[0])

    def test_same_name_two_leagues_are_disambiguated_by_tournament_id(self):
        german={**self.detail,'season':'2019/2020','profile_season_id':'7-0','fotmob_tournament_id':'54'}
        tid,name,source,_=resolve_career_team(german,self.bundle,self.basic,{})
        self.assertEqual((tid,name),('9789','Borussia Dortmund'))
        austrian={**german,'profile_season_id':'7-1','fotmob_tournament_id':'38'}
        self.assertFalse(resolve_career_team(austrian,self.bundle,self.basic,{})[0])

    def test_same_league_reuses_confirmed_mapping_if_club_is_in_career(self):
        austrian={**self.detail,'season':'2019/2020','profile_season_id':'7-1','fotmob_tournament_id':'38'}
        previous={'737066:8-0':{'fotmob_team_id':'10013','season':'2018/2019',
                                'competition':'Bundesliga','fotmob_tournament_id':'38'}}
        tid,name,source,_=resolve_career_team(austrian,self.bundle,self.basic,previous)
        self.assertEqual((tid,name),('10013','Salzburg'))

    def test_multi_club_champions_not_misattributed(self):
        ucl={**self.detail,'season':'2019/2020','competition':'Champions League','fotmob_tournament_id':'42'}
        self.assertTrue(multiple_clubs_in_international_cup(ucl,self.bundle,self.basic))
        self.assertFalse(resolve_career_team(ucl,self.bundle,self.basic,{})[0])

    def test_club_world_cup_not_national_team_competition(self):
        self.assertFalse(_national_competition({'competition':'FIFA Club World Cup','tournament_id':'78'}))
        self.assertTrue(_national_competition({'competition':'World Cup UEFA qualification','tournament_id':'10195'}))

    def test_mapping_saves_and_preserves_other_assignments(self):
        with tempfile.TemporaryDirectory() as td:
            inp={'737066:8-0':{'fotmob_team_id':'10013','season':'2018/2019','competition':'Bundesliga'}}
            save_assignments(td,inp)
            self.assertEqual(load_assignments(td),inp)

    def test_missing_detailed_cache_preserves_profile_season_and_basic_minutes(self):
        basic=[{'fotmob_player_id':'123','season':'2017','league':'Eliteserien',
                'fotmob_team_id':'9917','team_name':'Molde',
                'fotmob_tournament_id':'59','appearances':16,'minutes':900,'rating':None}]
        option={'season':'2017','competition':'Eliteserien','season_id':'5-0','tournament_id':'59'}
        with tempfile.TemporaryDirectory() as td, \
             patch('app.base44_export._read_rows',return_value=basic), \
             patch('app.base44_export.cached_detail_records',return_value=([],[option],[])), \
             patch('app.base44_export._snapshot',return_value=(None,None)), \
             patch('app.base44_export.load_bundle_if_available',return_value=None):
            out=create_player_batch(td,'123')
        self.assertEqual(out['summary']['fotmob_records_preserved'],1)
        self.assertEqual(out['summary']['fotmob_without_detail'],1)
        rec=out['records'][0]['data']
        self.assertEqual((rec['matches'],rec['minutes']), (16,900))
        self.assertEqual(rec['metrics'],[])
        self.assertFalse(rec['detailed_metrics_available'])

    def test_haaland_real_cache_retains_all_52_if_available(self):
        root=Path(__file__).resolve().parent.parent
        if not (root/'datos/perfiles_fotmob/737066.json').exists():
            self.skipTest('La caché de Haaland no está incluida en la actualización ligera')
        result=create_player_batch(root,'737066')
        self.assertEqual(result['summary']['fotmob_options'],52)
        self.assertEqual(result['summary']['fotmob_with_details'],52)
        self.assertEqual(result['summary']['fotmob_seasons_detected'],12)
        self.assertEqual(len(result['all_season_records']),52)
        self.assertEqual(result['summary']['fotmob_exportable']+result['summary']['fotmob_pending_review'],52)
        self.assertGreater(result['summary']['fotmob_exportable'],36)
        self.assertIn('2018/2019',result['summary']['all_seasons'])
        self.assertTrue(any(row['season']=='2019/2020' and
                            row['competition']=='Champions League' and row.get('multi_club_competition')
                            for row in result['pending_team_review']))


if __name__=='__main__':unittest.main()
