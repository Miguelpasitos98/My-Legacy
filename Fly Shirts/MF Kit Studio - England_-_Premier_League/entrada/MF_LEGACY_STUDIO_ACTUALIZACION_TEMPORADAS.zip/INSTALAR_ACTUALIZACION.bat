@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title MF LEGACY - Correccion de temporadas
set "DEST=%~1"
if not defined DEST if exist "%~dp0MF_Legacy_Studio_Unificado\INICIAR.pyw" set "DEST=%~dp0MF_Legacy_Studio_Unificado"
if not defined DEST if exist "%~dp0..\MF_Legacy_Studio_Unificado\INICIAR.pyw" set "DEST=%~dp0..\MF_Legacy_Studio_Unificado"
if not defined DEST if exist "E:\Football Manager\MF_Legacy_Studio_Unificado\INICIAR.pyw" set "DEST=E:\Football Manager\MF_Legacy_Studio_Unificado"
if not defined DEST (
 echo.
 echo Introduce la ruta de la carpeta original MF_Legacy_Studio_Unificado
 set /p "DEST=Ruta: "
)
if not exist "%DEST%\INICIAR.pyw" (
 echo ERROR: la ruta indicada NO contiene INICIAR.pyw.
 echo No se ha modificado ningun archivo.
 pause
 exit /b 1
)
if not exist "%DEST%\app\base44_export.py" (
 echo ERROR: la ruta indicada no contiene app\base44_export.py.
 pause
 exit /b 1
)
set "BACKUP=%DEST%\RESPALDOS\HISTORIAL_BASE44_%RANDOM%_%RANDOM%"
mkdir "%BACKUP%" >nul 2>&1
if errorlevel 1 (
 echo ERROR: no se pudo crear carpeta de respaldo.
 pause
 exit /b 1
)
echo.
echo Guardando respaldo del codigo anterior...
for %%F in (base44_export.py player_window.py history_sync.py team_resolution.py team_review_dialog.py) do (
 if exist "%DEST%\app\%%F" copy /Y "%DEST%\app\%%F" "%BACKUP%\%%F" >nul
)
echo Aplicando actualizacion en: %DEST%
for %%F in (base44_export.py player_window.py history_sync.py team_resolution.py team_review_dialog.py) do (
 copy /Y "%~dp0app\%%F" "%DEST%\app\%%F" >nul
 if errorlevel 1 goto ERROR_COPY
)
if exist "%DEST%\actualizacion\app" (
 for %%F in (base44_export.py player_window.py) do (
  copy /Y "%~dp0actualizacion\app\%%F" "%DEST%\actualizacion\app\%%F" >nul
  if errorlevel 1 goto ERROR_COPY
 )
)
copy /Y "%~dp0VERIFICAR_TEMPORADAS.py" "%DEST%\VERIFICAR_TEMPORADAS.py" >nul
if exist "%DEST%\tests" copy /Y "%~dp0tests\test_team_resolution_base44.py" "%DEST%\tests\test_team_resolution_base44.py" >nul
echo.
echo ACTUALIZACION COMPLETADA.
echo Respaldo: %BACKUP%
echo No se han modificado datos, cache, FUENTES, EXPORTACIONES ni configuraciones.
echo.
echo Cierra y vuelve a abrir MF Legacy Studio.
pause
exit /b 0
:ERROR_COPY
echo ERROR: hubo un fallo copiando archivos.
echo Los anteriores estan en: %BACKUP%
echo No se han borrado datos ni exportaciones.
pause
exit /b 1
