"""Revisión explícita de IDs de club que no se pudieron atribuir."""
from __future__ import annotations
import tkinter as tk
from tkinter import ttk, messagebox
from .team_resolution import season_key


def review_pending_teams(parent, pending):
    """Devuelve dict de confirmaciones nuevas, o None al cancelar exportación."""
    dialog=tk.Toplevel(parent)
    dialog.title('MF LEGACY | Revisar equipos antes de exportar')
    dialog.geometry('1020x560')
    dialog.minsize(760,455)
    dialog.configure(bg='#0c1324')
    dialog.transient(parent)
    dialog.grab_set()
    result={'updates':None}
    updates={}
    fg='#eff5fe'; muted='#adbed3'
    def label(where,txt,sz=10,col=fg,bold=False):
        return tk.Label(where,text=txt,bg=where.cget('bg'),fg=col,
                        justify='left',wraplength=940,
                        font=('Segoe UI',sz,'bold' if bold else 'normal'))
    header=tk.Frame(dialog,bg='#15223a',padx=20,pady=14)
    header.pack(fill='x')
    label(header,'REVISAR CLUBES Y SELECCIONES',16,bold=True).pack(anchor='w')
    label(header,'Estas estadísticas YA existen. Solo falta decidir a qué ID real de FotMob corresponden. '
                 'No atribuyas una competición a un club si sus datos incluyen más de uno.',10,muted).pack(anchor='w',pady=(5,0))
    body=tk.Frame(dialog,bg='#0c1324',padx=17,pady=13)
    body.pack(fill='both',expand=True)
    cols=('season','competition','id','team')
    table=ttk.Treeview(body,columns=cols,show='headings',height=9,selectmode='browse')
    for col,title,width in [('season','TEMPORADA',120),('competition','COMPETICIÓN',390),
                            ('id','ID TORNEO',100),('team','ASIGNACIÓN',290)]:
        table.heading(col,text=title)
        table.column(col,width=width,anchor='w')
    sy=ttk.Scrollbar(body,orient='vertical',command=table.yview)
    table.configure(yscrollcommand=sy.set)
    sy.pack(side='right',fill='y')
    table.pack(fill='both',expand=True)
    for i,r in enumerate(pending):
        table.insert('','end',iid=str(i),values=(r['season'],r['competition'],
            r.get('fotmob_tournament_id') or '—','Pendiente de revisión'))

    edit=tk.Frame(body,bg='#1a2a45',padx=14,pady=12)
    edit.pack(fill='x',pady=(12,0))
    label(edit,'Selecciona una fila de arriba y después el equipo identificado en la trayectoria FotMob.',10,bold=True).pack(anchor='w')
    choice=tk.StringVar()
    combo=ttk.Combobox(edit,textvariable=choice,state='readonly',width=65)
    combo.pack(side='left',padx=(0,10),pady=(8,0),fill='x',expand=True)
    info=tk.StringVar(value='Elige un registro para revisar.')
    note=label(body,'',10,muted)
    note.configure(textvariable=info)
    note.pack(anchor='w',pady=(10,0))
    options=[]
    def current():
        sel=table.selection()
        return int(sel[0]) if sel else None
    def selected_row(event=None):
        nonlocal options
        i=current()
        if i is None:return
        r=pending[i]
        options=list(r.get('team_candidates') or [])
        values=['— Mantener pendiente —']+[f"{t['team_name']}  |  FotMob ID: {t['fotmob_team_id']}" for t in options]
        combo['values']=values
        key=season_key(r)
        found=next((j for j,v in enumerate(options,1) if updates.get(key,{}).get('fotmob_team_id')==v['fotmob_team_id']),0)
        combo.current(found)
        if r.get('multi_club_competition'):
            info.set('Atención: esta competición podría agrupar datos de varios clubes en una misma temporada. No asignes el total a uno solo.')
        else:
            info.set(f"Opciones tomadas de la trayectoria real en FotMob: {len(options)}. Si no hay certeza, conserva «Pendiente».")
    table.bind('<<TreeviewSelect>>',selected_row)
    def apply():
        i=current()
        if i is None:return
        r=pending[i]
        idx=combo.current()
        key=season_key(r)
        if idx<=0:
            updates.pop(key,None)
            table.set(str(i),'team','Pendiente de revisión')
            info.set('Sin asignar. Se conservará en el JSON como registro pendiente.')
            return
        t=options[idx-1]
        if r.get('multi_club_competition'):
            messagebox.showwarning('Champions League compartida',
                'El jugador figura en varios clubes durante esta temporada. '
                'Es necesario separar las estadísticas por club usando datos contrastados. '
                'No es seguro asociar el total de la competición a uno solo.',parent=dialog)
            return
        updates[key]={'fotmob_team_id':t['fotmob_team_id'],
                      'season':r['season'],'competition':r['competition'],
                      'fotmob_tournament_id':str(r.get('fotmob_tournament_id') or '')}
        table.set(str(i),'team',t['team_name']+' (confirmado)')
        info.set('Asignación preparada. Se guardará al pulsar «Guardar y continuar».')
    def finish():
        result['updates']=dict(updates)
        dialog.destroy()
    def cancel():dialog.destroy()
    controls=tk.Frame(dialog,bg='#15223a',padx=17,pady=11)
    controls.pack(fill='x')
    tk.Button(controls,text='Aplicar selección',command=apply,bg='#2452a3',fg='white',
              relief='flat',padx=14,pady=8).pack(side='left')
    tk.Button(controls,text='Guardar y continuar',command=finish,bg='#1d85e5',fg='white',
              relief='flat',padx=14,pady=8).pack(side='right')
    tk.Button(controls,text='Cancelar exportación',command=cancel,bg='#273650',fg='white',
              relief='flat',padx=14,pady=8).pack(side='right',padx=(0,9))
    dialog.protocol('WM_DELETE_WINDOW',cancel)
    if pending:table.selection_set('0');table.focus('0');selected_row()
    parent.wait_window(dialog)
    return result['updates']
