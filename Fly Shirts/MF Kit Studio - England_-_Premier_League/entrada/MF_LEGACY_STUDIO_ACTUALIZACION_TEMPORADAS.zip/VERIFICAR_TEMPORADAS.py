"""Comprueba sin modificar la caché ni exportar datos a Base44."""
from pathlib import Path
from app.base44_export import create_player_batch

root=Path(__file__).resolve().parent
try:
    doc=create_player_batch(root,'737066')
    s=doc['summary']
    print('Jugador: Erling Haaland (FotMob 737066)')
    print('Temporadas localizadas:',s['fotmob_seasons_detected'])
    print('Competiciones conservadas:',s['fotmob_records_preserved'])
    print('Competiciones listas para importar:',s['fotmob_exportable'])
    print('Competiciones pendientes de revisar:',s['fotmob_pending_review'])
    print('Temporadas sin fila importable:',', '.join(s['seasons_pending_entirely']) or 'Ninguna')
    print('Nota: all_season_records contiene todas las temporadas, incluso las pendientes.')
except Exception as err:
    print('No se pudo analizar Haaland. Comprueba que sus datos locales esten cargados:',err)
input('\nPulsa ENTER para cerrar...')
