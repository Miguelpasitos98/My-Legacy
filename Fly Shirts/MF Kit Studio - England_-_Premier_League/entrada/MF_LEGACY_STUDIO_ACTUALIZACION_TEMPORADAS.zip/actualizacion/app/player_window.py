"""Ficha por jugador: historial local + estadísticas por temporada/competición.

Los datos avanzados solo se muestran si el usuario aporta JSON o consulta una
competición concreta. No hay extracción de plantillas en segundo plano.
"""
from __future__ import annotations
from pathlib import Path
import json
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from .core import export_csv, export_json, export_report
from .history_sync import normalized_season
from .profile import (load_profile_bundle, read_json, extract_stat_details,
                      aggregate_stats_seasons, export_stats_bundle, export_stats_csv)
from .stats_catalog import sections, fmt
from .batch_stats import options_for_export, coverage_report
from .fotmob_client import (fetch_profile, fetch_stats, player_cache_path,
                            stat_cache_path, save_json)

BG='#0c1324'
PANEL='#141f35'
FG='#f2f6fd'
MUTED='#a8bcd4'
BLUE='#1d85e5'
ROOT=Path(__file__).resolve().parent.parent


def player_history(records, player_id):
    """Recupera todas las temporadas de este ID, no solo las de filtros activos."""
    return sorted((r for r in records if str(r.get('fotmob_player_id'))==str(player_id)),
                  key=lambda r:(r.get('season',''),r.get('league',''),r.get('team_name','')), reverse=True)


def overview(records):
    """Suma solo contadores; ratings y valores nunca se suman."""
    return {
        'records':len(records),
        'seasons':len({r.get('season') for r in records}),
        'teams':len({r.get('fotmob_team_id') for r in records if r.get('fotmob_team_id')}),
        'appearances':sum(r['appearances'] for r in records if r.get('appearances') is not None),
        'minutes':sum(r['minutes'] for r in records if r.get('minutes') is not None),
        'missing_appearances':sum(r.get('appearances') is None for r in records),
        'missing_minutes':sum(r.get('minutes') is None for r in records),
    }


class PlayerWindow(tk.Toplevel):
    def __init__(self, parent, selected, all_records):
        super().__init__(parent)
        self.parent=parent
        self.records=player_history(all_records,selected['fotmob_player_id'])
        self.selected=selected
        self.pid=str(selected['fotmob_player_id'])
        self.title('MF LEGACY | '+selected['player_name'])
        self.geometry('1160x790')
        self.minsize(870,590)
        self.configure(bg=BG)
        self.transient(parent)
        menubar = tk.Menu(self)
        tools = tk.Menu(menubar, tearoff=False)
        tools.add_command(label="Importar perfil JSON guardado", command=self.load_profile_file)
        tools.add_command(label="Importar estadísticas JSON", command=self.import_stats_file)
        tools.add_command(label="Ver perfil JSON guardado", command=self.open_local_profile)
        tools.add_separator()
        tools.add_command(label="Exportar estadísticas en JSON + CSV", command=self.export_stats)
        tools.add_command(label="Exportar histórico básico", command=self.export_player)
        menubar.add_cascade(label="Opciones avanzadas", menu=tools)
        self.configure(menu=menubar)
        self.bundle=None
        self.options=[]
        self.detail_records={}
        self._busy=False
        self._batch_cancel=threading.Event()
        self._build()
        cache=player_cache_path(ROOT,self.pid)
        if cache.exists():
            try:self._set_profile(cache,announce=False)
            except (OSError,ValueError,KeyError,json.JSONDecodeError):pass

    def _label(self,parent,text,size=11,color=FG,bold=False):
        return tk.Label(parent,text=text,bg=parent.cget('bg'),fg=color,font=('Segoe UI',size,'bold' if bold else 'normal'))

    def _button(self,parent,label,command,primary=False):
        return tk.Button(parent,text=label,command=command,bg=BLUE if primary else '#1b2a45',
                         fg='white',activeforeground='white',activebackground=BLUE,
                         font=('Segoe UI',10,'bold'),relief='flat',padx=12,pady=8,cursor='hand2')

    def _build(self):
        head=tk.Frame(self,bg=PANEL,padx=22,pady=14);head.pack(fill='x')
        self._label(head,self.selected['player_name'],22,bold=True).pack(anchor='w')
        self._label(head,'FotMob ID: '+self.pid +
                    ('   ·   FM26 UID: '+self.selected['fm26_uid'] if self.selected.get('fm26_uid') else '')+
                    ('   ·   Base44: '+self.selected['base44_player_id'] if self.selected.get('base44_player_id') else ''),
                    10,MUTED).pack(anchor='w',pady=(3,0))
        sums=overview(self.records)
        bar=tk.Frame(self,bg=BG,padx=22,pady=10);bar.pack(fill='x')
        for k,v in [('TEMPORADAS',sums['seasons']),('CLUBES',sums['teams']),
                    ('REGISTROS',sums['records']),('PARTIDOS',f"{sums['appearances']:,}"),
                    ('MINUTOS',f"{sums['minutes']:,.0f}")]:
            block=tk.Frame(bar,bg='#1b2a45',padx=13,pady=7);block.pack(side='left',fill='x',expand=True,padx=(0,7))
            self._label(block,k,9,MUTED).pack(anchor='w')
            self._label(block,str(v).replace(',','.'),15,bold=True).pack(anchor='w')
        body=tk.Frame(self,bg=BG,padx=19);body.pack(fill='both',expand=True)
        self.tabs=ttk.Notebook(body);self.tabs.pack(fill='both',expand=True)
        self.history_page=tk.Frame(self.tabs,bg=BG)
        self.stats_page=tk.Frame(self.tabs,bg=BG)
        self.tabs.add(self.history_page,text='  HISTORIAL ESTADÍSTICO  ')
        self.tabs.add(self.stats_page,text='  ESTADÍSTICAS POR TEMPORADA  ')
        self._build_history()
        self._build_stats()
        footer=tk.Frame(self,bg=PANEL,padx=21,pady=11);footer.pack(fill='x')
        self._button(footer,'Cerrar',self.destroy).pack(side='right')
        self._button(footer,'EXPORTAR A BASE44',self.export_for_base44,primary=True).pack(side='right',padx=7)
        self._label(footer,'FotMob por competición + CraftedFC global · Exportación revisable',9,MUTED).pack(side='left')

    def _build_history(self):
        self._label(self.history_page,'Rankings + perfil individual sincronizado. Los datos parciales no equivalen a cero.',10,MUTED).pack(anchor='w',pady=(8,5),padx=5)
        bar=tk.Frame(self.history_page,bg=BG);bar.pack(fill='x',padx=5,pady=(0,7))
        self._button(bar,'SINCRONIZAR HISTORIAL',self.sync_profile_history,primary=True).pack(side='left',padx=(0,8))
        self._label(bar,'Completa la tabla con datos del perfil local.',9,MUTED).pack(side='left')
        tablebox=tk.Frame(self.history_page,bg=BG);tablebox.pack(fill='both',expand=True)
        cols=('season','team','league','apps','minutes','rating','market','coverage')
        self.history_tree=ttk.Treeview(tablebox,columns=cols,show='headings',selectmode='browse')
        cols_data=[('season','TEMPORADA',108),('team','CLUB',190),('league','COMPETICIÓN',170),
                   ('apps','PJ',64),('minutes','MIN',85),('rating','NOTA',75),('market','VALOR (€)',120),('coverage','DATOS',165)]
        for name,label,width in cols_data:
            self.history_tree.heading(name,text=label)
            self.history_tree.column(name,width=width,anchor='w' if name in ('team','league') else 'center')
        scroll=ttk.Scrollbar(tablebox,orient='vertical',command=self.history_tree.yview)
        self.history_tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');self.history_tree.pack(side='left',fill='both',expand=True)
        for i,r in enumerate(self.records):
            num=lambda n: '—' if n is None else f'{n:,.0f}'
            self.history_tree.insert('','end',iid=str(i),values=(r['season'],r['team_name'] or 'Club por confirmar',r['league'],
                num(r['appearances']),num(r['minutes']),
                '—' if r['rating'] is None else f"{r['rating']:.2f}",num(r['market_value']),
                ('Perfil parcial · '+str(len(r.get('metrics') or []))+' métricas') if r.get('verification_status')=='perfil_individual_parcial' else 'Ranking FotMob'))
        self.history_tree.bind('<Double-1>',self._from_history)
        self.history_tree.bind('<Return>',self._from_history)
        if sums:=overview(self.records):
            missing=sums['missing_appearances']+sums['missing_minutes']
            if missing:
                self._label(self.history_page,'Hay registros sin partidos o minutos. Los totales anteriores son parciales.',10,MUTED).pack(anchor='w',pady=6)

    def sync_profile_history(self):
        if self._busy:
            messagebox.showinfo('Operación en curso','Termina antes las consultas de estadísticas.',parent=self)
            return
        try:
            report=self.parent.sync_player_history(self.pid)
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
            messagebox.showerror('No se pudo sincronizar el perfil',str(error),parent=self)
            return
        text=(f'Competiciones del perfil: {report["options"]}\n'
              f'Ya presentes en rankings: {report["already_in_rankings"]}\n'
              f'Nuevos registros parciales: {report["new_partial_rows"]}\n'
              f'Con métricas detalladas locales: {report["with_cached_metrics"]}\n'
              f'Sin detalle: {report["no_cached_metrics"]}\n'
              f'Ambigüedades que requieren revisión: {len(report["ambiguous"])}\n'
              f'Errores de caché: {len(report["errors"])}\n\n'
              'Se conserva intacto fotmob_bigfive_cache.json. '
              'Los registros sin minutos o PJ se marcan como parciales y NO equivalen a cero.')
        messagebox.showinfo('Sincronización completada',text,parent=self)
        # Refresh overview counters, history and main table in a fresh window.
        parent=self.parent
        selected=self.selected
        self.destroy()
        PlayerWindow(parent,selected,parent.records)

    def _build_stats(self):
        helpframe=tk.Frame(self.stats_page,bg=BG);helpframe.pack(fill='x',pady=(9,7))
        self._label(helpframe,'Elige una temporada y competición. Los detalles no incluidos en la caché se consultan o importan por separado.',10,MUTED).pack(anchor='w')
        buttons=tk.Frame(self.stats_page,bg=BG);buttons.pack(fill='x',pady=6)
        self._button(buttons,'1 · CONSULTAR TEMPORADAS',self.consult_profile).pack(side='left',padx=(0,6))
        self._button(buttons,'2 · ACTUALIZAR COMPETICIÓN',self.refresh_stats).pack(side='left',padx=(0,6))
        self._button(buttons,'3 · COMPLETAR ESTADÍSTICAS',self.prepare_full_export,primary=True).pack(side='left',padx=(0,6))
        filters=tk.Frame(self.stats_page,bg=PANEL,padx=12,pady=10);filters.pack(fill='x',pady=(6,8))
        self._label(filters,'TEMPORADA',9,MUTED,bold=True).grid(row=0,column=0,sticky='w')
        self._label(filters,'COMPETICIÓN',9,MUTED,bold=True).grid(row=0,column=1,sticky='w',padx=(12,0))
        self.season_var=tk.StringVar()
        self.competition_var=tk.StringVar()
        self.season_select=ttk.Combobox(filters,textvariable=self.season_var,state='readonly',width=21)
        self.season_select.grid(row=1,column=0,sticky='ew',pady=(5,0))
        self.season_select.bind('<<ComboboxSelected>>',self._change_season)
        self.comp_select=ttk.Combobox(filters,textvariable=self.competition_var,state='readonly',width=44)
        self.comp_select.grid(row=1,column=1,sticky='ew',padx=(12,12),pady=(5,0))
        self.comp_select.bind('<<ComboboxSelected>>',self._clear_forced_option)
        self._button(filters,'VER ESTADÍSTICAS',self.show_stats,primary=True).grid(row=1,column=2,sticky='ew',pady=(5,0))
        self._button(filters,'TOTAL TEMPORADA',self.show_season_total).grid(row=1,column=3,sticky='ew',padx=(9,0),pady=(5,0))
        filters.columnconfigure(1,weight=1)
        self.status_var=tk.StringVar(value='Cargando opciones locales...')
        status=tk.Frame(self.stats_page,bg=BG);status.pack(fill='x',pady=(0,7))
        self._label(status,'ESTADO',9,MUTED,bold=True).pack(side='left')
        tk.Label(status,textvariable=self.status_var,bg=BG,fg=FG,font=('Segoe UI',10),anchor='w',wraplength=900).pack(side='left',padx=10)
        progress=tk.Frame(self.stats_page,bg=BG)
        progress.pack(fill='x',pady=(0,8))
        self.batch_progress=ttk.Progressbar(progress,mode='determinate',maximum=100)
        self.batch_progress.pack(side='left',fill='x',expand=True,padx=(0,10))
        self.batch_label=tk.StringVar(value='0 / 0 competiciones')
        tk.Label(progress,textvariable=self.batch_label,bg=BG,fg=MUTED,font=('Segoe UI',9)).pack(side='left')
        self._button(progress,'Detener',self.stop_full_export).pack(side='left',padx=(10,0))
        box=tk.Frame(self.stats_page,bg=BG);box.pack(fill='both',expand=True)
        cols=('metric','value','per90','percentile')
        self.stats_tree=ttk.Treeview(box,columns=cols,show='tree headings')
        self.stats_tree.heading('#0',text='CATEGORÍA')
        self.stats_tree.column('#0',width=208,minwidth=140,stretch=False)
        for col,label,width in [('metric','ESTADÍSTICA',310),('value','VALOR',130),('per90','POR 90',112),('percentile','PERCENTIL',102)]:
            self.stats_tree.heading(col,text=label)
            self.stats_tree.column(col,width=width,anchor='w' if col=='metric' else 'center',stretch=col=='metric')
        scroll=ttk.Scrollbar(box,orient='vertical',command=self.stats_tree.yview)
        self.stats_tree.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');self.stats_tree.pack(side='left',fill='both',expand=True)
        self._set_options([])

    def _set_options(self, options):
        if not options:
            # Sin perfil detallado aún se puede abrir un JSON manual para una
            # temporada/competición de la caché; sin ID interno no se consulta en línea.
            options=[{'season':r['season'],'competition':r['league'],'season_id':'',
                      'is_first':False,'advanced':False} for r in self.records]
        self.options=list(options)
        seasons=list(dict.fromkeys(o['season'] for o in self.options if o.get('season')))
        seasons.sort(reverse=True)
        self.season_select['values']=seasons
        if self.selected.get('season') in seasons:
            self.season_var.set(self.selected['season'])
        elif seasons:self.season_var.set(seasons[0])
        else:self.season_var.set('')
        self._select_season()

    def _clear_forced_option(self,event=None):
        self._forced_season_id=''

    def _change_season(self,event=None):
        self._clear_forced_option()
        self._select_season()

    def _select_season(self,event=None):
        options=[o for o in self.options if o['season']==self.season_var.get()]
        labels=list(dict.fromkeys(o['competition'] for o in options))
        previous=self.competition_var.get()
        self.comp_select['values']=labels
        if previous in labels:self.competition_var.set(previous)
        elif self.selected.get('league') in labels:self.competition_var.set(self.selected['league'])
        else:self.competition_var.set(labels[0] if labels else '')

    def _selected_option(self):
        matches=[o for o in self.options if o.get('season')==self.season_var.get() and
                 o.get('competition')==self.competition_var.get()]
        if len(matches)==1:return matches[0]
        wanted=getattr(self,'_forced_season_id','')
        if wanted:
            selected=next((o for o in matches if str(o.get('season_id') or '')==wanted),None)
            if selected:return selected
        if len(matches)>1:
            self.status_var.set('Existen dos torneos con el mismo nombre y temporada. Elige desde HISTORIAL para evitar mezclarlos.')
        return None


    def _from_history(self,event=None):
        idx=self.history_tree.selection()
        if event is not None and hasattr(event,'y'):
            clicked=self.history_tree.identify_row(event.y)
            if clicked:idx=(clicked,)
        if not idx:return
        r=self.records[int(idx[0])]
        self._forced_season_id=str(r.get('profile_season_id') or '')
        self.tabs.select(self.stats_page)
        seasons=self.season_select['values']
        if r['season'] in seasons:
            self.season_var.set(r['season']);self._select_season()
            if r['league'] in self.comp_select['values']:
                self.competition_var.set(r['league'])
        else:
            self.status_var.set('Esa temporada está en la caché resumida. Pulsa «Consultar temporadas FotMob» o abre un perfil JSON para identificar sus competiciones.')
            return
        # Solo mostrar lo ya disponible; consultar requiere pulsar el botón.
        option=self._selected_option()
        if option:
            if not option.get('season_id'):
                self.status_var.set('Este registro es un resumen de la caché. Consulta primero las temporadas FotMob para ver métricas en línea, o importa un JSON.')
                return
            path=stat_cache_path(ROOT,self.pid,option['season_id'])
            if path.exists():
                try:self._present_stats_file(path,option)
                except (ValueError,KeyError,json.JSONDecodeError) as err:
                    self.status_var.set(f'Caché desactualizada: {err}')
            else:self.status_var.set('Temporada seleccionada. Pulsa «VER ESTADÍSTICAS» para consultar sus métricas, o importa un JSON.')

    def _set_profile(self,path,announce=True):
        bundle=load_profile_bundle(path)
        remote_id=bundle['player']['fotmob_player_id']
        if remote_id and str(remote_id)!=self.pid:
            raise ValueError(f'Este perfil es de otro jugador: FotMob ID {remote_id}. Se esperaba {self.pid}.')
        if not bundle['season_options']:
            raise ValueError('El perfil no contiene statSeasons con temporadas y competiciones.')
        self.bundle=bundle
        self._set_options([{**o,'season':normalized_season(o['season'])} for o in bundle['season_options']])
        self.status_var.set(f"{len(self.options)} competiciones disponibles, {len(self.season_select['values'])} temporadas. Selecciona una y pulsa VER ESTADÍSTICAS.")
        if announce:self.tabs.select(self.stats_page)

    def load_profile_file(self):
        path=filedialog.askopenfilename(parent=self,title='Abrir perfil FotMob JSON',filetypes=[('JSON','*.json')])
        if not path:return
        try:
            self._set_profile(path)
            # Copiar a la caché local para mostrar opciones incluso sin conexión.
            save_json(player_cache_path(ROOT,self.pid),read_json(path))
        except Exception as err:
            messagebox.showerror('Perfil no compatible',str(err),parent=self)

    def consult_profile(self):
        if self._busy:return
        self._remote_job(lambda:fetch_profile(self.pid),self._on_profile,'Consultando temporadas en FotMob...')

    def _on_profile(self,payload):
        from .profile import find_block
        if not isinstance(find_block(payload,'statSeasons'),list):
            raise ValueError('La respuesta no contiene statSeasons reconocible. No se guardó en caché.')
        cache=player_cache_path(ROOT,self.pid)
        save_json(cache,payload)
        self._set_profile(cache)

    def show_stats(self):
        option=self._selected_option()
        if option is None:
            messagebox.showinfo('Selecciona una competición','Primero carga el perfil de temporadas y selecciona una competición.',parent=self)
            return
        if not option.get('season_id'):
            messagebox.showinfo('Necesitas el perfil de temporadas','Pulsa «Consultar temporadas FotMob» o «Abrir perfil JSON guardado» para identificar esta competición, o importa manualmente sus estadísticas JSON.',parent=self)
            return
        path=stat_cache_path(ROOT,self.pid,option['season_id'])
        if path.exists():
            try:self._present_stats_file(path,option)
            except Exception as err:messagebox.showerror('Caché dañada',str(err),parent=self)
            return
        self._fetch_option(option)

    def refresh_stats(self):
        option=self._selected_option()
        if option is None or not option.get('season_id'):
            messagebox.showinfo('Faltan opciones','Primero consulta o importa el perfil de temporadas FotMob.',parent=self)
            return
        self._fetch_option(option)

    def _fetch_option(self,option):
        if self._busy:return
        def fetch():
            try:return fetch_stats(self.pid,option['season_id'],option.get('is_first',False))
            except Exception:
                if option.get('is_first',False):return fetch_stats(self.pid,option['season_id'],False)
                raise
        self._remote_job(fetch,lambda payload:self._on_stats(option,payload),
                         f"Consultando {option['competition']} · {option['season']}...")

    def stop_full_export(self):
        if self._busy:
            self._batch_cancel.set()
            self.status_var.set('Deteniendo después de la consulta actual. Los datos ya guardados se conservan.')

    def prepare_full_export(self, export_dir=None):
        """Solo para este jugador y tras una confirmación explícita."""
        if self._busy:return
        if not any(o.get('season_id') for o in self.options):
            messagebox.showinfo('Primero el perfil de temporadas',
                'Pulsa «Consultar temporadas FotMob» para identificar las competiciones del jugador y vuelve a preparar la exportación.',parent=self)
            return
        options=options_for_export(self.options)
        if not options:return
        total=len(options)
        if not messagebox.askyesno('Preparar exportación detallada',
            f'Se revisarán {total} combinaciones de temporada y competición SOLO de {self.selected["player_name"]}.\n\n'
            'Las respuestas válidas que ya estén en caché se reutilizarán. Las que falten requerirán una consulta en línea por competición, con pausas entre solicitudes.\n\n'
            'La descarga puede tardar varios minutos; puedes detenerla. ¿Continuar?',parent=self):return
        self._busy=True
        self._batch_cancel.clear()
        self.tabs.select(self.stats_page)
        self.batch_progress.configure(maximum=total,value=0)
        self.batch_label.set(f'0 / {total} competiciones')
        failures=[]
        def report(i,label):
            def apply():
                if not self.winfo_exists():return
                self.batch_progress.configure(value=i)
                self.batch_label.set(f'{i} / {total} competiciones')
                self.status_var.set(label)
            try:self.after(0,apply)
            except (RuntimeError,tk.TclError):pass
        def worker():
            done=0
            loaded=0
            queried=0
            try:
                for option in options:
                    if self._batch_cancel.is_set():break
                    label=f'{option["season"]} · {option["competition"]}'
                    path=stat_cache_path(ROOT,self.pid,option['season_id'])
                    rec=None
                    if path.exists():
                        try:
                            raw=read_json(path)
                            meta=raw.get('_mf_legacy_meta')
                            if meta and (str(meta.get('player_id'))!=self.pid or meta.get('season')!=option['season'] or
                                meta.get('competition')!=option['competition'] or meta.get('season_id')!=option['season_id']):
                                raise ValueError('Identificadores de caché no coinciden')
                            payload=raw.get('payload') if meta else raw
                            tid,tname=self._club_from_cache(option['season'],option['competition'], option.get('tournament_id',''))
                            rec=extract_stat_details(payload,player_id=self.pid,season=option['season'],
                                competition=option['competition'],team_id=tid,team_name=tname,
                                tournament_id=option.get('tournament_id',''),profile_season_id=option['season_id'])
                            if not rec['metrics']:raise ValueError('Sin métricas')
                            rec['source']='FotMob · caché local'
                            rec['local_source_file']=str(path)
                        except Exception:
                            rec=None
                    if rec is None:
                        if queried and self._batch_cancel.wait(1.8):break
                        try:
                            try:payload=fetch_stats(self.pid,option['season_id'],option.get('is_first',False))
                            except Exception:
                                if not option.get('is_first',False):raise
                                payload=fetch_stats(self.pid,option['season_id'],False)
                            queried+=1
                            tid,tname=self._club_from_cache(option['season'],option['competition'], option.get('tournament_id',''))
                            rec=extract_stat_details(payload,player_id=self.pid,season=option['season'],
                                competition=option['competition'],team_id=tid,team_name=tname,
                                tournament_id=option.get('tournament_id',''),profile_season_id=option['season_id'])
                            if not rec['metrics']:raise ValueError('No hay métricas reconocibles')
                            save_json(path,{'_mf_legacy_meta':{'player_id':self.pid,'season':option['season'],
                                'competition':option['competition'],'season_id':option['season_id']},'payload':payload})
                            rec['source']='FotMob · consulta individual'
                            rec['local_source_file']=str(path)
                        except Exception as exc:failures.append({'season':option['season'],'competition':option['competition'],'error':str(exc)[:300]})
                    if rec:
                        self.detail_records[rec['external_record_id']]=rec
                        loaded+=1
                    done+=1
                    report(done,f'{label} · {"Guardada" if rec else "No disponible"}. {loaded} correctas, {len(failures)} incidencias.')
            finally:
                def finish():
                    if not self.winfo_exists():return
                    self._busy=False
                    self.batch_progress.configure(value=done)
                    self.batch_label.set(f'{done} / {total} competiciones')
                    if self.detail_records:
                        try:
                            current=self._selected_option()
                            if current:
                                path=stat_cache_path(ROOT,self.pid,current['season_id'])
                                if path.exists():self._present_stats_file(path,current)
                        except Exception:pass
                    prefix='Proceso detenido' if self._batch_cancel.is_set() else 'Preparación terminada'
                    self.status_var.set(f'{prefix}: {loaded} competiciones disponibles, {len(failures)} incidencias. Pulsa Exportar estadísticas JSON + CSV.')
                    if export_dir and self.detail_records:
                        self._write_stats_exports(export_dir)
                    if failures:
                        lines='\n'.join(f'{x["season"]} · {x["competition"]}: {x["error"]}' for x in failures[:10])
                        messagebox.showwarning('Consultas incompletas',f'{loaded} / {total} competiciones preparadas.\n\n'+lines,parent=self)
                    elif loaded:
                        messagebox.showinfo('Listo para exportar',f'{loaded} competiciones preparadas. Ya puedes pulsar «Exportar estadísticas JSON + CSV».',parent=self)
                try:self.after(0,finish)
                except (RuntimeError,tk.TclError):pass
        threading.Thread(target=worker,daemon=True).start()

    def _remote_job(self,action,done,label):
        self._busy=True
        self.status_var.set(label+'  (una sola consulta solicitada por ti)')
        def task():
            try:result=(True,action())
            except Exception as err:result=(False,str(err))
            def finish():
                if not self.winfo_exists():return
                self._busy=False
                if result[0]:
                    try:done(result[1])
                    except Exception as err:
                        self.status_var.set('Error procesando la respuesta.')
                        messagebox.showerror('Respuesta no compatible',str(err),parent=self)
                else:
                    self.status_var.set('La consulta en línea ha fallado. También puedes importar archivos JSON locales.')
                    messagebox.showwarning('No se pudo consultar FotMob',result[1]+\
                        '\n\nFotMob usa interfaces no oficiales que pueden cambiar o limitar el acceso.',parent=self)
            try:self.after(0,finish)
            except (RuntimeError,tk.TclError):pass
        threading.Thread(target=task,daemon=True).start()

    def _on_stats(self,option,payload):
        check=extract_stat_details(payload,player_id=self.pid,season=option['season'],competition=option['competition'])
        if not check['metrics']:
            raise ValueError('La respuesta no contiene estadísticas reconocibles. No se guardó una caché vacía.')
        path=stat_cache_path(ROOT,self.pid,option['season_id'])
        save_json(path,{'_mf_legacy_meta':{'player_id':self.pid,'season':option['season'],
                          'competition':option['competition'],'season_id':option['season_id']},
                        'payload':payload})
        self._present_stats_file(path,option)

    def _club_from_cache(self,season,competition,tournament_id=""):
        # Solo cuando existe una coincidencia EXACTA de temporada y liga.
        matching=[r for r in self.records if normalized_season(r.get('season'))==normalized_season(season)
                  and r.get('league')==competition]
        same_options=[o for o in self.options if normalized_season(o.get('season'))==normalized_season(season)
                      and o.get('competition')==competition]
        # Never infer Borussia Dortmund for Austrian Bundesliga (same name).
        if len(same_options)>1:
            if not tournament_id:return ('','')
            matching=[r for r in matching if str(r.get('fotmob_tournament_id') or '')==tournament_id]
        candidates={(str(r.get('fotmob_team_id') or ''),str(r.get('team_name') or ''))
                    for r in matching if r.get('fotmob_team_id') or r.get('team_name')}
        return next(iter(candidates)) if len(candidates)==1 else ('','')

    def _present_stats_file(self,path,option):
        payload=read_json(path)
        meta=payload.get('_mf_legacy_meta')
        if meta is not None:
            if (str(meta.get('player_id'))!=self.pid or normalized_season(meta.get('season'))!=normalized_season(option['season']) or
                meta.get('competition')!=option['competition'] or meta.get('season_id')!=option['season_id']):
                raise ValueError('El archivo de caché pertenece a otra temporada o competición. Actualiza el perfil y vuelve a consultar.')
            payload=payload.get('payload')
            if not isinstance(payload,dict):raise ValueError('Respuesta almacenada no válida.')
        team_id,team_name=self._club_from_cache(option['season'],option['competition'], option.get('tournament_id',''))
        rec=extract_stat_details(payload,player_id=self.pid,season=option['season'],
                                 competition=option['competition'],team_id=team_id,team_name=team_name,
                                 tournament_id=option.get('tournament_id',''),profile_season_id=option['season_id'])
        rec['source']='FotMob · JSON local / consulta individual'
        rec['local_source_file']=str(path)
        self.detail_records[rec['external_record_id']]=rec
        self._fill_metrics(rec['metrics'])
        self.status_var.set(f"{option['season']} · {option['competition']}  |  {len(rec['metrics'])} métricas disponibles"
                            f"  |  {len(rec['conflicts'])} discrepancias  |  {len(self.detail_records)} competiciones cargadas."
                            + (' REVISAR discrepancias antes de exportar.' if rec['conflicts'] else ''))

    def _fill_metrics(self,metrics,total=False):
        self.stats_tree.delete(*self.stats_tree.get_children())
        for heading, rows in sections(metrics):
            parent=self.stats_tree.insert('','end',text=heading,values=('', '', '', ''),open=True)
            for item in rows:
                label=item['label']
                value=fmt(item.get('value'),item.get('unit',''))
                self.stats_tree.insert(parent,'end',text='',values=(label,value,
                    ('—' if total or item.get('per90') is None else fmt(item['per90'])),
                    ('—' if total or item.get('percentile') is None else fmt(item['percentile']))))

    def import_stats_file(self):
        season=self.season_var.get();comp=self.competition_var.get()
        if not season or not comp:
            messagebox.showwarning('Selecciona temporada y competición','Carga un perfil para seleccionar la temporada y competición correctas antes de importar sus estadísticas.',parent=self)
            return
        path=filedialog.askopenfilename(parent=self,title='Importar estadísticas de la competición seleccionada',filetypes=[('JSON','*.json')])
        if not path:return
        option=self._selected_option()
        if option is None:return
        try:
            team_id,team_name=self._club_from_cache(season,comp, option.get('tournament_id','') if option else '')
            rec=extract_stat_details(read_json(path),player_id=self.pid,season=season,
                                     competition=comp,team_id=team_id,team_name=team_name)
            rec['source']='FotMob · JSON aportado por el usuario'
            rec['local_source_file']=str(path)
            self.detail_records[rec['external_record_id']]=rec
            self._fill_metrics(rec['metrics'])
            self.status_var.set(f'{season} · {comp} | {len(rec["metrics"])} estadísticas leídas de archivo local.'
                                + (' Hay métricas contradictorias que revisar.' if rec['conflicts'] else ''))
        except Exception as err:messagebox.showerror('Error leyendo estadísticas',str(err),parent=self)

    def show_season_total(self):
        season=self.season_var.get()
        details=[r for r in self.detail_records.values() if r['season']==season]
        if not details:
            messagebox.showinfo('No hay estadísticas detalladas','Consulta o importa al menos una competición de esta temporada antes de calcular el subtotal.',parent=self)
            return
        try:
            totals=aggregate_stats_seasons(details)
            if len(totals)!=1:raise ValueError('No hay un único jugador y temporada seleccionados.')
            data=totals[0]
            self._fill_metrics([{'name':v['name'],'value':v['value'],'per90':None,'percentile':None} for v in data['totals']],total=True)
            listed={o['competition'] for o in self.options if o['season']==season}
            missing=listed-set(data['competitions_included'])
            self.status_var.set(f"SUBTOTAL {season}: {len(data['competitions_included'])} competiciones incluidas."
                                + (f" Faltan {len(missing)} para un total completo." if missing else ' Cobertura según la lista conocida, sin garantía de exhaustividad.')
                                + ' No se suman notas, porcentajes ni velocidades máximas.')
        except Exception as err:messagebox.showerror('No se pudo agregar',str(err),parent=self)

    def export_for_base44(self):
        """Exporta todas las temporadas; identifica equipos antes de importar."""
        try:
            from .base44_export import create_player_batch, export_player_batch
            from .team_review_dialog import review_pending_teams
            from .team_resolution import load_assignments, save_assignments
            preview=create_player_batch(ROOT,self.pid,self.records)
            pending=preview['pending_team_review']
            if pending:
                updates=review_pending_teams(self,pending)
                if updates is None:return
                if updates:
                    assignments=load_assignments(ROOT)
                    assignments.update(updates)
                    save_assignments(ROOT,assignments)
        except Exception as exc:
            messagebox.showerror('No se pudo preparar exportación Base44',str(exc),parent=self)
            return
        folder=filedialog.askdirectory(parent=self,title='Guardar lote FotMob + CraftedFC para Base44',
                                         initialdir=str(ROOT/'EXPORTACIONES'))
        if not folder:return
        try:
            result=export_player_batch(ROOT,self.pid,self.records,Path(folder))
        except Exception as exc:
            messagebox.showerror('No se pudo exportar para Base44',str(exc),parent=self)
            return
        info=result['summary']
        remaining=info.get('seasons_pending_entirely') or []
        messagebox.showinfo('Exportación Base44 preparada',
            'Archivo: '+str(result['path'])+'\n\n'
            'Temporadas FotMob detectadas: '+str(info['fotmob_seasons_detected'])+'\n'
            'Temporadas con al menos una fila importable: '+str(info['fotmob_seasons_exportable'])+'\n'
            'Competiciones detalladas conservadas: '+str(info['fotmob_with_details'])+'\n'
            'Competiciones con equipo confirmado: '+str(info['fotmob_exportable'])+'\n'
            'Competiciones pendientes de equipo o conflicto: '+str(info['fotmob_pending_review'])+'\n'
            'Snapshot CraftedFC: '+('sí' if info['craftedfc_included'] else 'no')+'\n'
            'Métricas FotMob: '+str(info['fotmob_metrics'])+'\n'
            + ('\nTemporadas aún sin ninguna fila importable: '+', '.join(remaining)+'\n' if remaining else '\n')
            + '\nLos detalles de las temporadas pendientes NO se pierden: están en '
            'all_season_records y pending_team_review. Base44 debe importar solo records '
            'hasta que se resuelvan sus clubes. Revisa el lote en FUENTES antes de confirmarlo.',parent=self)

    def export_stats(self):
        if self._busy:return
        folder=filedialog.askdirectory(parent=self,title='Guardar estadísticas completas del jugador')
        if not folder:return
        if any(o.get('season_id') for o in self.options):
            self.prepare_full_export(export_dir=folder)
            return
        if self.detail_records:
            self._write_stats_exports(folder)
        else:
            self._remote_job(
                lambda:fetch_profile(self.pid),
                lambda payload:(self._on_profile(payload),self.prepare_full_export(export_dir=folder)),
                'Identificando automáticamente las temporadas del jugador...')

    def _write_stats_exports(self,folder):
        path=Path(folder)/f'ESTADISTICAS_FOTMOB_{self.pid}_REVISION.json'
        try:
            records=list(self.detail_records.values())
            export_stats_bundle(records,path)
            export_stats_csv(records,path.with_suffix('.csv'))
            report=coverage_report(options_for_export(self.options),records)
            coverage=path.with_name(f'COBERTURA_FOTMOB_{self.pid}_REVISION.json')
            coverage.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        except Exception as err:
            messagebox.showerror('No se pudo exportar',str(err),parent=self)
            return
        messagebox.showinfo('Exportado',f'{len(self.detail_records)} competiciones guardadas en JSON, CSV e informe de cobertura:\n{path.parent}\n\nComprueba las competiciones no disponibles.',parent=self)

    def open_local_profile(self):
        path=filedialog.askopenfilename(parent=self,title='Ficha JSON individual guardada',filetypes=[('JSON','*.json')])
        if not path:return
        try:
            bundle=load_profile_bundle(path)
            ident=bundle['player']['fotmob_player_id']
            if ident and str(ident)!=self.pid:
                messagebox.showerror('Jugador distinto','El JSON pertenece al ID FotMob '+str(ident)+' y no a '+self.pid,parent=self)
                return
            from .profile_gui import ProfileWindow
            ProfileWindow(self,path)
        except Exception as err:messagebox.showerror('JSON inválido',str(err),parent=self)

    def export_player(self):
        folder=filedialog.askdirectory(parent=self,title='Carpeta para exportar el historial del jugador')
        if not folder:return
        dest=Path(folder)
        try:
            export_json(self.records,dest/'JUGADOR_ESTADISTICAS_BASE44_REVISION.json')
            export_csv(self.records,dest/'JUGADOR_TEMPORADAS.csv')
            export_report(self.records,dest/'JUGADOR_RESUMEN.json')
        except Exception as err:messagebox.showerror('Error al exportar',str(err),parent=self);return
        messagebox.showinfo('Exportación completada',f'{len(self.records)} registros exportados a:\n{dest}\n\nSolo para revisión; no importación automática.',parent=self)
