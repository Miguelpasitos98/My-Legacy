"""Exportación de un futbolista a un único lote revisable Base44.

Solo usa cachés locales: FotMob por temporada y CraftedFC global. Nunca
infiere clubes a partir de nombres, ni convierte un rating global en nota.
Las filas sin equipo se conservan en all_season_records y pending_team_review.
El historial seguro para importar sigue en records.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json
import os

from .core import load_cache, to_records
from .team_matches import read_team_matches
from .history_sync import merged_records, read_overlay, normalized_season
from .detailed_cache_export import cached_detail_records
from .profile import slug
from .team_resolution import (load_bundle_if_available, load_assignments,
                              resolve_career_team, multiple_clubs_in_international_cup)

BATCH_SCHEMA = 'mf_legacy_external_batch_v1'


def _number(value):
    if value is None or value == '': return None
    try:
        n = float(value)
        return n if n == n and abs(n) != float('inf') else None
    except (ValueError, TypeError): return None


def _metric(detail, name):
    return next((_number(m.get('value')) for m in detail.get('metrics', [])
                 if slug(m.get('name')) == slug(name)), None)


def _snapshot(root, pid):
    folder = Path(root) / 'FUENTES' / 'CRAFTEDFC'
    files = list((folder/'datos_completos').glob('jugadores_*.json'))
    if len(files) != 1: return None, None
    data = json.loads(files[0].read_text(encoding='utf-8-sig'))
    found = next((v for v in data if str(v.get('player_id')) == str(pid)), None)
    manifest=folder / 'MANIFIESTO.json'
    stamp=None
    if manifest.is_file():
        try: stamp=json.loads(manifest.read_text(encoding='utf-8-sig')).get('snapshot')
        except (ValueError, OSError): pass
    return found, stamp


def _read_rows(root, pid, player_rows=None):
    root=Path(root)
    # Load independent source on demand; no state mutation.
    if player_rows is None:
        basics=to_records(load_cache(root/'datos/fotmob_bigfive_cache.json'),{},read_team_matches(root))
        all_rows=merged_records(basics,read_overlay(root))
    else:
        all_rows=player_rows
    return [r for r in all_rows if str(r.get('fotmob_player_id') or '') == str(pid)]


def _find_rank(detail, player_rows):
    candidates=[r for r in player_rows if
                normalized_season(r.get('season'))==normalized_season(detail['season']) and
                slug(r.get('league'))==slug(detail['competition']) and
                r.get('fotmob_team_id')]
    tid=str(detail.get('fotmob_tournament_id') or '')
    candidates=[r for r in candidates if not tid or
                not r.get('fotmob_tournament_id') or str(r.get('fotmob_tournament_id')) == tid]
    return candidates[0] if len(candidates)==1 else None


def create_player_batch(root, player_id, player_rows=None):
    root=Path(root); pid=str(player_id).strip()
    if not pid.isdigit(): raise ValueError('Se requiere un ID numérico FotMob comprobado.')
    basics=_read_rows(root,pid,player_rows)
    details,options,errors=cached_detail_records(root,basics,[pid])
    if not details and not basics: raise ValueError('No hay datos locales de este jugador. Abre su perfil antes.')
    crafted,cfc_date=_snapshot(root,pid)
    bundle=load_bundle_if_available(root,pid)
    assignments=load_assignments(root)
    batch=[];pending=[];conflicts=[];verified=0
    stat_count=0
    seen=set()
    all_season_records=[]
    all_details=list(details)
    # El perfil FotMob acredita la existencia de combinaciones temporada/torneo
    # incluso si su detalle no se descargó o no contiene métricas reconocibles.
    detailed_ids={str(d.get('profile_season_id') or '') for d in details}
    for option in options:
        sid=str(option.get('season_id') or '')
        if not sid or sid in detailed_ids:continue
        all_details.append({
            'fotmob_player_id':pid,'season':option['season'],
            'competition':option['competition'],
            'fotmob_tournament_id':option.get('tournament_id') or '',
            'profile_season_id':sid,
            'external_record_id':f"fotmob-profile:{pid}:{sid}",
            'metrics':[],
            'source':'FotMob · competición confirmada en perfil; sin detalle estadístico',
        })
        detailed_ids.add(sid)
    for detail in all_details:
        unique=detail['external_record_id']
        if unique in seen:
            raise ValueError('Dos respuestas de FotMob tienen la misma clave: '+unique)
        seen.add(unique)
        stat_count+=len(detail.get('metrics') or [])
        basic=_find_rank(detail,basics)
        # Preferir el ID de equipo explícito de la competición. La trayectoria
        # permite completar algunas identidades inequívocas, nunca fabricar IDs.
        team_id=str(detail.get('fotmob_team_id') or (basic or {}).get('fotmob_team_id') or '')
        team_name=str(detail.get('team_name') or (basic or {}).get('team_name') or '')
        source='competicion_con_equipo_confirmado' if team_id and team_id!='0' else ''
        candidates=[]
        if not source:
            team_id,team_name,source,candidates=resolve_career_team(
                detail,bundle,basics,assignments)
        matches=_metric(detail,'Matches')
        mins=_metric(detail,'Minutes')
        rating=_metric(detail,'Rating')
        base_apps=_number((basic or {}).get('appearances'))
        base_mins=_number((basic or {}).get('minutes'))
        base_rating=_number((basic or {}).get('rating'))
        mismatch=(base_apps is not None and matches is not None and base_apps!=matches) or \
                 (base_mins is not None and mins is not None and base_mins!=mins)
        if base_rating is not None and rating is not None and abs(base_rating-rating)>0.005:
            conflicts.append({'season':detail['season'],'competition':detail['competition'],
                              'metric':'Rating','ranking':base_rating,'stats_detail':rating,
                              'rule':'Se conserva la nota del ranking; no se sobreescribe.'})
        record={
          'fotmob_player_id':pid,'fotmob_team_id':team_id or None,'team_name':team_name or None,
          'season':normalized_season(detail['season']),'competition':detail['competition'],
          'fotmob_tournament_id':detail.get('fotmob_tournament_id') or None,
          'profile_season_id':detail.get('profile_season_id') or None,
          'matches':base_apps if base_apps is not None else matches,
          'minutes':base_mins if base_mins is not None else mins,
          'rating':base_rating if base_rating is not None else rating,
          'team_matches':(basic or {}).get('team_matches',detail.get('team_matches')),
          'metrics':detail['metrics'],
          'detailed_metrics_available':bool(detail.get('metrics')),
          'team_assignment_source':source or None,
          'verification_status':'fotmob_cobertura_con_equipo_confirmado' if source=='competicion_con_equipo_confirmado'
              else ('fotmob_equipo_resuelto_con_evidencia' if source else 'fotmob_equipo_pendiente'),
          'review_status':'pending','source':'FotMob · historial + estadísticas individuales',
        }
        # Conservar TODAS las combinaciones originales, incluso las pendientes.
        # Base44 puede usarlo para informar sobre la cobertura, pero nunca debe
        # tratar los registros sin equipo como atribuciones verificadas.
        all_season_records.append(record)
        if mismatch or not team_id or team_id=='0':
            reason=('Conflicto de PJ/minutos entre ranking y detalles: revisar coberturas antes de mezclar.'
                    if mismatch else 'Falta asignar un club/selección FotMob a esta competición.')
            pending.append({**record,
                            'external_record_id':detail['external_record_id'],
                            'needs_review':reason,
                            'team_candidates':candidates,
                            'multi_club_competition':multiple_clubs_in_international_cup(detail,bundle,basics)})
            continue
        batch.append({'kind':'season','fotmob_id':pid,'data':record})
        verified+=1
    if crafted:
        batch.insert(0,{'kind':'player','fotmob_id':pid,'snapshot_date':cfc_date,
                        'data':{'ids':{'fotmob_player_id':pid},
                                'identity':{'name':crafted.get('player_name') or ''},
                                'craftedfc_snapshot':crafted}})
    if not batch:
        raise ValueError('No hay registros importables con club confirmado, ni snapshot CraftedFC. Datos solo para revisión.')
    all_seasons=sorted({r['season'] for r in all_season_records})
    exported_seasons=sorted({r['data']['season'] for r in batch if r['kind']=='season'})
    summary={
      'fotmob_id':pid,'fotmob_options':len(options),'fotmob_with_details':len(details),
      'fotmob_metrics':stat_count,'fotmob_exportable':verified,
      'fotmob_records_preserved':len(all_season_records),
      'fotmob_without_detail':len(all_season_records)-len(details),
      'fotmob_pending_review':len(pending), 'craftedfc_included':bool(crafted),
      'fotmob_seasons_detected':len(all_seasons),
      'fotmob_seasons_exportable':len(exported_seasons),
      'all_seasons':all_seasons,
      'seasons_pending_entirely':sorted(set(all_seasons)-set(exported_seasons)),
      'extraction_errors':errors,'conflicts_kept':conflicts,
      'note':'Se preservan todos los detalles locales en all_season_records. Solo registros con equipo identificado y sin conflictos graves se colocan en records; el resto requiere revisión.',
    }
    return {'schema':BATCH_SCHEMA,'batch':f'jugador_{pid}',
            'snapshot_date':cfc_date or '',
            'created_utc':datetime.now(timezone.utc).isoformat(),
            'records':batch,'all_season_records':all_season_records,
            'pending_team_review':pending,'summary':summary,
            'sources':{'fotmob':'cachés locales por competición','craftedfc':'snapshot global independiente'},
            'validated_for_direct_bulk_import':False}


def export_player_batch(root,player_id,player_rows,folder):
    out=create_player_batch(root,player_id,player_rows)
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    path=folder / f'MF_LEGACY_BASE44_JUGADOR_{player_id}.json'
    tmp=path.with_suffix('.json.tmp')
    try:
        with tmp.open('w',encoding='utf-8') as f:
            json.dump(out,f,ensure_ascii=False,indent=2,allow_nan=False)
            f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if tmp.exists():tmp.unlink()
    return {'path':path,'summary':out['summary']}
